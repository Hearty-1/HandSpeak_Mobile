# Lupang Hinirang: Flutter implementation files

Target app: `D:\HandSpeak_Mobile-rules-compat` (HEAD `104b909`). The app repo was **not modified**. Copy these files over the
same paths in the app.

The model itself runs on Cloud Run, so **no model file goes into the app**. The phone sends landmarks; the server does cleaning,
features, the ONNX model and the gates.

## Files (copy into the app at the same relative path)

| File | Action | What it is |
|---|---|---|
| `lib/services/handspeak_api_service.dart` | **replace** | Superset of the current service: the same `predict()` (Greetings and other screens keep working), plus `predictRawLupangHinirang` / `RawPredictResponse` / `CaptureFixer`. |
| `lib/module/civic/lupang_hinirang_practice.dart` | **add (new file)** | The Lupang Hinirang practice screen (`LupangHinirangPractice`). It records raw pose and hand landmarks, posts them to `/v1/predict_raw/lupang_hinirang`, and shows the result or rejection. |
| `lib/module/civic/civic_tutorial_detail.dart` | **replace** | Your current file with two changes: an extra import, and lessons whose title contains "lupang"/"hinirang" open `LupangHinirangPractice`. Panata and Panunumpa still open the existing `CivicTutorialPractice`. |
| `assets/civic/labels_lupang_hinirang.json` | **replace** | Merged manifest: 21 steps. Index 10 = "May dilag ang tula at awit sa paglayang minamahal"; index 11 is retired; the other indices are unchanged. It is already listed in `pubspec.yaml`. |
| `android/app/src/main/kotlin/com/example/flutter_application_1/MainActivity.kt` | **replace** | ⚠ **Draft, not built or run on a device.** The existing `fsl_holistic_channel` is kept unchanged. It adds `fsl_raw_landmarks_channel` (PoseLandmarker heavy + HandLandmarker, confidence 0.35, upright, not mirrored, hands assigned to the nearest pose wrist, processed off the UI thread). |
| `reference/lupang_hinirang_v4.json` | do not copy | Staged model metadata: class names, gate values, and `model_version` `palm_lupang_v9_switch`. |
| `reference/inference_api_main.py` | do not copy | Server API contract (`RawFrame`, `RawPredictRequest`). |

No `pubspec.yaml` or `build.gradle` change is needed. `camera`, `http`, `firebase_auth`, `firebase_storage` and
`com.google.mediapipe:tasks-vision:0.10.14` are already there. `pose_landmarker_heavy.task` and `hand_landmarker.task` are
already in `android/app/src/main/assets`.

The 41 MB legacy `assets/civic/fsl_lupang_hinirang.onnx` is no longer used by Lupang Hinirang. Remove it only after
everything below works.

## Is the model in GCP? (checked 2026-10-12)

Yes, it is deployed, but **it is not live**.

| Revision | Image | Traffic |
|---|---|---|
| `handspeak-inference-00016-yeb`, tag `lupang-v9` | `sha256:2517c9fb…` (current model) | 0 % |
| `handspeak-inference-00014-sxj` (Console, same image) | `sha256:2517c9fb…` | 0 % |
| `handspeak-inference-00014-yeh`, tag `letters-jz` | `sha256:d8df153a…` (old Lupang model) | **100 %** |

The app's `baseUrl` therefore still reaches the old model.

## Steps

1. Copy the files above and run `flutter pub get`, then `flutter run` on an Android phone.
2. **Test against the new model before making it live.** Temporarily set `baseUrl` in `handspeak_api_service.dart` to
   `https://lupang-v9---handspeak-inference-xo2j6ffgta-as.a.run.app`.
3. Check on the device:
   - The practice screen shows pose and hands detected.
   - A clearly signed line comes back with the right label.
   - A random movement is rejected.
   - Panata, Panunumpa and Greetings still behave as before.
4. **Parity check (recommended).** Sign the same line in the app and in `webcam_test_staging.py`, then compare confidence and
   rejection reasons. If the app often gets "pose/hands coverage" rejections, check the `rotation` (sensor orientation) and the
   hand assignment in `MainActivity.kt` first.
5. Set `baseUrl` back to `https://handspeak-inference-xo2j6ffgta-as.a.run.app`. Then make the model live (this is your step):
   ```
   gcloud run services update-traffic handspeak-inference --region asia-southeast1 --project handspeak-96d8d --to-revisions handspeak-inference-00016-yeb=100
   ```
   To roll back:
   ```
   gcloud run services update-traffic handspeak-inference --region asia-southeast1 --project handspeak-96d8d --to-revisions handspeak-inference-00014-yeh=100
   ```
   Revision 00016 was built from the current `inference-service`. Before switching, confirm it still serves the endpoints the
   live 00014-yeh serves for the other screens (letters, greetings, calendar).

## Limits and known issues

- `MainActivity.kt` is untested. Training used MediaPipe **Holistic** (Python); the phone uses the Tasks Pose and Hand
  landmarkers. These are close but not identical, which is why the parity check in step 4 matters.
- Request limits: ≤ 600 frames, ≤ 30 s, and `t` must increase. The server requires a pose in ≥ 80 % of frames and hands in
  ≥ 30 % of frames.
- Changes in `lupang_hinirang_practice.dart` compared with the training-repo original (`civic_tutorial_practice (2).dart`):
  - The class was renamed and the channel was changed to `fsl_raw_landmarks_channel`.
  - The fallback in `_expectedClassIndex` now uses the manifest `index` instead of the step number, because step ≥ 11 ≠ class index.
  - The fallback in `_indexOf` now accepts only indices present in the manifest.
- `MANIFEST.csv` lists every file's source path and sha256.
