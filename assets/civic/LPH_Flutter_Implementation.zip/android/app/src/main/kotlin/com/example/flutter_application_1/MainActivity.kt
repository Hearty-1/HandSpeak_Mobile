package com.example.flutter_application_1

// DRAFT - NOT YET BUILT OR TESTED ON A DEVICE.
// Existing channel "fsl_holistic_channel" (68-point HandLandmarker, used by
// Panata / Panunumpa) is kept byte-for-byte in behaviour. Added: channel
// "fsl_raw_landmarks_channel" for the Lupang Hinirang raw-landmark model
// (lib/module/civic/lupang_hinirang_practice.dart).

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val CHANNEL = "fsl_holistic_channel"
    private val RAW_CHANNEL = "fsl_raw_landmarks_channel"
    private var handLandmarker: HandLandmarker? = null

    // Raw-landmark pipeline (Lupang Hinirang). Separate landmarker instances so
    // the legacy channel's settings (0.5 confidences) stay untouched.
    private var rawPoseLandmarker: PoseLandmarker? = null
    private var rawHandLandmarker: HandLandmarker? = null
    private val rawExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // Initialize MediaPipe Hand / Holistic Detector
        initMediaPipe()

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "processFrame") {
                val yuvBytes = call.argument<ByteArray>("yuvBytes")
                val width = call.argument<Int>("width")
                val height = call.argument<Int>("height")

                if (yuvBytes == null || width == null || height == null) {
                    result.error("INVALID_ARGUMENTS", "Missing yuvBytes, width, or height", null)
                    return@setMethodCallHandler
                }

                try {
                    // 1. Convert YUV Camera Bytes to Bitmap
                    val bitmap = yuvToBitmap(yuvBytes, width, height)
                    if (bitmap == null) {
                        result.success(null)
                        return@setMethodCallHandler
                    }

                    // 2. Process Bitmap through MediaPipe
                    val landmarksList = processFrameWithMediaPipe(bitmap)

                    // 3. Return flattened 204 doubles (68 landmarks * 3) to Flutter
                    result.success(landmarksList)

                } catch (e: Exception) {
                    result.error("PROCESSING_ERROR", e.localizedMessage, null)
                }
            } else {
                result.notImplemented()
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, RAW_CHANNEL).setMethodCallHandler { call, result ->
            if (call.method != "processFrame") {
                result.notImplemented()
                return@setMethodCallHandler
            }
            val y = call.argument<ByteArray>("y")
            val u = call.argument<ByteArray>("u")
            val v = call.argument<ByteArray>("v")
            val yRowStride = call.argument<Int>("yRowStride")
            val uvRowStride = call.argument<Int>("uvRowStride")
            val uvPixelStride = call.argument<Int>("uvPixelStride") ?: 1
            val width = call.argument<Int>("width")
            val height = call.argument<Int>("height")
            val rotation = call.argument<Int>("rotation") ?: 0
            if (y == null || u == null || v == null || yRowStride == null || uvRowStride == null ||
                width == null || height == null) {
                result.error("INVALID_ARGUMENTS", "Missing camera planes, strides or size", null)
                return@setMethodCallHandler
            }
            // MediaPipe off the UI thread; reply on the UI thread.
            rawExecutor.execute {
                try {
                    val out = processRawFrame(y, u, v, yRowStride, uvRowStride, uvPixelStride, width, height, rotation)
                    mainHandler.post { result.success(out) }
                } catch (e: Exception) {
                    mainHandler.post { result.error("PROCESSING_ERROR", e.localizedMessage, null) }
                }
            }
        }
    }

    private fun initMediaPipe() {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .build()

            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setRunningMode(RunningMode.IMAGE)
                .build()

            handLandmarker = HandLandmarker.createFromOptions(this, options)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Created lazily on the worker thread the first time Lupang Hinirang is used.
    // 0.35 mirrors the training extractor (lupang_common.HOLISTIC_KWARGS).
    private fun ensureRawLandmarkers() {
        if (rawPoseLandmarker == null) {
            val poseOptions = PoseLandmarker.PoseLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("pose_landmarker_heavy.task").build())
                .setNumPoses(1)
                .setMinPoseDetectionConfidence(0.35f)
                .setMinPosePresenceConfidence(0.35f)
                .setMinTrackingConfidence(0.35f)
                .setRunningMode(RunningMode.IMAGE)
                .build()
            rawPoseLandmarker = PoseLandmarker.createFromOptions(this, poseOptions)
        }
        if (rawHandLandmarker == null) {
            val handOptions = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.35f)
                .setMinHandPresenceConfidence(0.35f)
                .setMinTrackingConfidence(0.35f)
                .setRunningMode(RunningMode.IMAGE)
                .build()
            rawHandLandmarker = HandLandmarker.createFromOptions(this, handOptions)
        }
    }

    /**
     * Returns the map lupang_hinirang_practice.dart expects:
     *   imageWidth, imageHeight (upright), engine, convertMs, processMs,
     *   pose33    = 33 x [x, y, visibility] or null,
     *   leftHand  = 21 x [x, y, z] or null  (the SIGNER's left hand),
     *   rightHand = 21 x [x, y, z] or null  (the SIGNER's right hand).
     * Coordinates are normalised on the upright, UN-mirrored image (no flip),
     * like the training data. Hands are assigned to the nearest pose wrist
     * (15 = signer's left, 16 = signer's right), not to the Tasks handedness label.
     */
    private fun processRawFrame(
        y: ByteArray, u: ByteArray, v: ByteArray,
        yRowStride: Int, uvRowStride: Int, uvPixelStride: Int,
        width: Int, height: Int, rotation: Int
    ): Map<String, Any?> {
        ensureRawLandmarkers()

        val t0 = SystemClock.elapsedRealtime()
        val nv21 = yuv420ToNv21(y, u, v, yRowStride, uvRowStride, uvPixelStride, width, height)
        val raw = yuvToBitmap(nv21, width, height) ?: throw IllegalStateException("YUV decode failed")
        val upright = rotateBitmap(raw, rotation)
        val convertMs = SystemClock.elapsedRealtime() - t0

        val t1 = SystemClock.elapsedRealtime()
        val mpImage = BitmapImageBuilder(upright).build()
        val poseResult = rawPoseLandmarker?.detect(mpImage)
        val handResult = rawHandLandmarker?.detect(mpImage)
        val processMs = SystemClock.elapsedRealtime() - t1

        var pose33: List<List<Double>>? = null
        if (poseResult != null && poseResult.landmarks().isNotEmpty()) {
            pose33 = poseResult.landmarks()[0].map { lm ->
                listOf(lm.x().toDouble(), lm.y().toDouble(), lm.visibility().orElse(0f).toDouble())
            }
        }

        val hands: List<List<List<Double>>> = handResult?.landmarks()?.map { hand ->
            hand.map { lm -> listOf(lm.x().toDouble(), lm.y().toDouble(), lm.z().toDouble()) }
        } ?: emptyList()

        var leftHand: List<List<Double>>? = null
        var rightHand: List<List<Double>>? = null
        if (hands.isNotEmpty()) {
            if (pose33 != null) {
                val lw = pose33[15]
                val rw = pose33[16]
                fun d2(h: List<List<Double>>, w: List<Double>): Double {
                    val dx = h[0][0] - w[0]; val dy = h[0][1] - w[1]; return dx * dx + dy * dy
                }
                if (hands.size >= 2) {
                    val a = hands[0]; val b = hands[1]
                    val straight = d2(a, lw) + d2(b, rw)
                    val swapped = d2(a, rw) + d2(b, lw)
                    leftHand = if (straight <= swapped) a else b
                    rightHand = if (straight <= swapped) b else a
                } else {
                    val h = hands[0]
                    if (d2(h, lw) <= d2(h, rw)) leftHand = h else rightHand = h
                }
            } else {
                // No pose: on an unmirrored image the signer's right hand is on
                // the image's left side (smaller x).
                val sorted = hands.take(2).sortedBy { it[0][0] }
                rightHand = sorted[0]
                if (sorted.size > 1) leftHand = sorted[1]
            }
        }

        return mapOf(
            "imageWidth" to upright.width,
            "imageHeight" to upright.height,
            "engine" to "tasks-pose-heavy+hands",
            "convertMs" to convertMs.toDouble(),
            "processMs" to processMs.toDouble(),
            "pose33" to pose33,
            "leftHand" to leftHand,
            "rightHand" to rightHand,
        )
    }

    /** YUV_420_888 planes (any row / pixel stride) -> tightly packed NV21. */
    private fun yuv420ToNv21(
        y: ByteArray, u: ByteArray, v: ByteArray,
        yRowStride: Int, uvRowStride: Int, uvPixelStride: Int,
        width: Int, height: Int
    ): ByteArray {
        val out = ByteArray(width * height * 3 / 2)
        var pos = 0
        for (row in 0 until height) {
            System.arraycopy(y, row * yRowStride, out, pos, width)
            pos += width
        }
        val chromaH = height / 2
        val chromaW = width / 2
        for (row in 0 until chromaH) {
            for (col in 0 until chromaW) {
                val idx = row * uvRowStride + col * uvPixelStride
                out[pos++] = v[idx]
                out[pos++] = u[idx]
            }
        }
        return out
    }

    private fun rotateBitmap(src: Bitmap, degrees: Int): Bitmap {
        val d = ((degrees % 360) + 360) % 360
        if (d == 0) return src
        val m = Matrix().apply { postRotate(d.toFloat()) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun yuvToBitmap(yuvBytes: ByteArray, width: Int, height: Int): Bitmap? {
        return try {
            val yuvImage = YuvImage(yuvBytes, ImageFormat.NV21, width, height, null)
            val out = ByteArrayOutputStream()
            yuvImage.compressToJpeg(Rect(0, 0, width, height), 90, out)
            val imageBytes = out.toByteArray()
            BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
        } catch (e: Exception) {
            null
        }
    }

    private fun processFrameWithMediaPipe(bitmap: Bitmap): List<Double> {
        val targetLandmarks = 68
        val outputFloats = ArrayList<Double>()

        val mpImage = BitmapImageBuilder(bitmap).build()
        val result: HandLandmarkerResult? = handLandmarker?.detect(mpImage)

        if (result != null && result.landmarks().isNotEmpty()) {
            for (hand in result.landmarks()) {
                for (landmark in hand) {
                    outputFloats.add(landmark.x().toDouble())
                    outputFloats.add(landmark.y().toDouble())
                    outputFloats.add(landmark.z().toDouble())
                }
            }
        }

        // Ensure total landmarks count strictly equals 68 (204 values) for ONNX input compatibility
        val requiredLength = targetLandmarks * 3
        while (outputFloats.size < requiredLength) {
            outputFloats.add(0.0)
        }

        return outputFloats.take(requiredLength)
    }

    override fun onDestroy() {
        rawExecutor.execute {
            rawPoseLandmarker?.close()
            rawHandLandmarker?.close()
        }
        rawExecutor.shutdown()
        handLandmarker?.close()
        super.onDestroy()
    }
}
