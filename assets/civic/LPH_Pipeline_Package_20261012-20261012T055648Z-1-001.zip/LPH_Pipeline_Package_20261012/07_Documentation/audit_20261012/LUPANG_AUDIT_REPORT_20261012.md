# Lupang Hinirang model audit and pipeline trace — 2026-10-12 (read-only)

Evidence files (all outside the project): `D:\tmp_lupang\audit\` — `hashes_before.json` / `hashes_after.json`
(integrity), `audit_eval.py` + `audit_results.json` + `attempt_rows.pkl` (evaluation), `prov*.txt` (provenance),
`flow.txt` (execution path), `summary.txt`, `bysess.txt`, `clean2.txt` (result breakdowns).
Labels used below: **[V]** verified by a check run in this audit · **[O]** observed result · **[I]** inference · **[U]** unknown.

## 1. Executive summary

* **[V] What is staged:** `inference-service/models_staging/fsl_lupang_hinirang_v4.onnx` (sha256 `763478f3…`, 32.5 MB) +
  `lupang_hinirang_v4.json` (`f0154e5c…`), `source_checkpoint = palm_lupang_v9_switch`. It is ONE ONNX graph composed of
  three ensembles: the original v5 ensemble, the user-adapted v9 B ensemble, and the Perlas patch v9p B ensemble,
  with a switch rule and a Perlas-only patch (details §8). Gate: min_conf 0.65, min_margin 0.65, entropy ≤ 0.50, stability,
  coverage, duration and kinematic checks; 23 outputs (class 11 retired, INVALID_GESTURE = 22).
* **[V] Production is untouched:** `inference-service/models/fsl_lupang_hinirang_v4.onnx` = `8208f496…` (the 2026-10-07 v4 model).
* **The evidence does NOT support "no false negatives" across the recorded attempts.** On 123 clean, labelled webcam
  attempts never used for training (replayed through the staged model with the service's own code): **52 correct,
  11 accepted as another line, 60 rejected** (precision of accepted answers 0.83, false-rejection rate 0.49). **[O]**
* **All 11 wrong acceptances are an adjacent anthem line** (9 × next line, 2 × previous line). This pattern matches the
  logs' target-switching slips (the target was changed after signing the next line) but cannot be proven without video **[I/U]**.
* **Invalid-gesture rejection is strong for fragments, idle, no-hands and out-of-frame input** (0–3 % accepted), **weak
  for two lines signed in one capture** (13–14 % accepted) and for **one hand never detected** (41 % accepted — these are
  real lines with a missing hand, so acceptance is partly correct) **[O]**.
* **Your observation ("all correct") is consistent with the most recent sessions only partially:** session 120644 (2/2
  correct) yes; session 120815 (Alab ng puso, 10 attempts) 4 accepted correctly, 6 rejected **[O]**. Most clean attempts
  were recorded on earlier staged models and replayed here; the live response and the replay agree where checked.
* **Independent held-out evidence is limited** and comes from experiment models trained with the same recipe, not the
  exact staged weights (§3.4). No held-out test exists for the exact staged model on other signers.

## 2. Audit environment and scope

* Repository: `D:\model2\fslr-transformer-vs-iv3gru`, branch `main`, HEAD `afe4158` (2026-09-26). **[V] No Lupang Hinirang
  file is tracked by git; the git log has no Lupang history** — history below is from file timestamps, metadata JSON,
  logs, and this session's work record.
* Python: system `Python311` (opencv 5.0.0, mediapipe 0.10.14, protobuf 3.20.3, onnxruntime 1.30.0, torch 2.14 cpu).
  All audit Python ran with `PYTHONDONTWRITEBYTECODE=1`; outputs only to `D:\tmp_lupang\audit`.
* Data available: 593 raw video files in 22 folders (327 reference clips + 266 user webcam takes); landmark cache
  `lupang_landmarks_cache.pkl`; 290 saved webcam tester attempts in `reports/lupang_retrain/webcam_sessions/`
  (sessions 2026-10-11 06:23 … 2026-10-12 12:09); earlier experiment outputs in `cv_runs/` and `reports/lupang_retrain/`.
* Limitations: no video of tester attempts (only landmarks) → labels cannot be verified visually; no independent
  signers recorded on the current model; the staging server was not running (evaluation used the service code
  in-process, `app.lupang_raw.RawSpecialistModel.predict`, which is what the server calls).

## 3. Performance results

Evaluation criteria (all through `RawSpecialistModel.predict` on `inference-service/models_staging`):
*correct* = accepted and predicted line == logged target; *wrong (false positive for the predicted line)* = accepted with
another line; *rejected* = "no prediction" (INVALID_GESTURE top-1 or any gate failure); *false rejection* = rejection of an
attempt whose target is a real line. Attempts are categorised by evidence in the logs (`audit_eval.py`):

| Category | n | Treatment |
|---|---|---|
| clean labelled (never trained on) | 142 → **123** after excluding run 111351 #006–020 (target fixed on line 3 while the predictions walk through lines 4…15) and 2 dark-camera sessions (104545, 105814: 0 hands, degenerate pose) | main webcam evaluation |
| TRAINED ON | 34 (session 090256 Bayang/Perlas; 111351 Perlas except #055) | training-set result only |
| fixed-target runs | 87 (075517 all target 5; 085620 all target 1) | labels unreliable — not scored as accuracy |
| no target | 27 (062318) | not scored |

### 3.1 Clean labelled webcam attempts (123) — "previously recorded, manually labelled" **[O]**

correct 52 · wrong 11 · rejected 60 · accuracy (rejections count as errors) **0.423** · precision of accepted **0.825** ·
false-rejection rate **0.488**. 34 of the 60 rejections had both hands tracked in < 30 % of frames. First rejection
reasons: LOW_CONFIDENCE 22, INVALID_CLASS 13, LOW_MOTION 8, NO_HANDS 6, others ≤ 2.
Confidence (all 142 clean): top-1 median 0.88 (p10 0.36), margin median 0.84, normalised entropy median 0.22.

Per line (n / correct / rejected / wrong; "acc-as" = other lines accepted as this one):

| Line | n | correct | rejected | wrong | acc-as | Precision | Recall |
|---|---|---|---|---|---|---|---|
| 01 Bayang magiliw | 15 | 6 | 5 | 4 (→ Perlas) | 1 | 0.86 | 0.40 |
| 02 Perlas ng Silanganan | 3 | 1 | 1 | 1 (→ Bayang) | 4 | 0.20 | 0.33 |
| 03 Alab ng puso | 15 | 6 | 9 | 0 | 0 | 1.00 | 0.40 |
| 04 Sa dibdib mo'y buhay | 3 | 2 | 1 | 0 | 0 | 1.00 | 0.67 |
| 05 Lupang hinirang | 4 | 2 | 0 | 2 (→ Duyan) | 0 | 1.00 | 0.50 |
| 06 Duyan ka ng magiting | 2 | 0 | 0 | 2 (→ Sa manlulupig) | 2 | 0.00 | 0.00 |
| 07 Sa manlulupig | 1 | 1 | 0 | 0 | 2 | 0.33 | 1.00 |
| 11 May dilag … minamahal | 2 | 2 | 0 | 0 | 1 | 0.67 | 1.00 |
| (12 retired: target "Sa paglayang") | 3 | – | 2 | 1 (→ merged 11) | – | – | – |
| 13 Ang kislap ng watawat mo'y | 8 | 1 | 7 | 0 | 0 | 1.00 | 0.12 |
| 14 Tagumpay na nagniningning | 1 | 1 | 0 | 0 | 0 | 1.00 | 1.00 |
| 15 Ang bituin at araw niya | 7 | 5 | 2 | 0 | 0 | 1.00 | 0.71 |
| 16 Kailan pa ma'y di magdidilim | 7 | 3 | 4 | 0 | 0 | 1.00 | 0.43 |
| 17 Lupa ng araw … | 3 | 2 | 1 | 0 | 0 | 1.00 | 0.67 |
| 18 Buhay ay langit … | 11 | 2 | 9 | 0 | 0 | 1.00 | 0.18 |
| 19 Aming ligaya | 14 | 9 | 5 | 0 | 0 | 1.00 | 0.64 |
| 20 Na pag may mang-aapi | 9 | 4 | 5 | 0 | 0 | 1.00 | 0.44 |
| 21 Ang mamatay | 10 | 4 | 5 | 1 (→ Nang dahil) | 0 | 1.00 | 0.40 |
| 22 Nang dahil sa 'yo | 5 | 1 | 4 | 0 | 1 | 0.50 | 0.20 |
| 08, 09, 10 | 0 | — no clean labelled attempts — | | | | | |

The 11 wrong acceptances (all adjacent lines): 090256 #026/#027 (5→6), #028/#029 (6→7), #035 (12→11),
111351 #038 (21→22), #043/#044/#060/#061 (1→2), #055 (2→1) **[O]**; label-slip explanation **[I]**.
Full confusion (incl. "NO PREDICTION" column): `audit_results.json → "webcam: clean labelled" → confusion`.

### 3.2 Attempts recorded live on the current model **[O]**
Recorded responses were matched to a model by replaying through both staged versions: the Perlas patch changed the output
only for attempts where its patched part ranks Perlas first, so most attempts are "both identical". Sessions 120644 and
120815 (after 11:56) and late 111351 attempts: 120644 2/2 correct; 120815 (target Alab) 4 correct / 6 rejected / 0 wrong.
Live response vs replay: identical decision wherever both exist.

### 3.3 Training-set results (not independent) **[O]**
585 dataset clips (all used to train components): 429 correct, **0 wrong**, 156 rejected (reference clips: 184/321 correct,
137 rejected — FRAGMENT_DURATION 65, LOW_CONFIDENCE 41, SMALL_MARGIN 21; user takes: 245/264 correct, 19 rejected).
34 trained-on attempts: 31 correct, 0 wrong, 3 rejected (2 no hands).

### 3.4 Held-out results from earlier experiments (same recipe, not the exact staged weights) **[O, cited]**
| Evidence file | Held-out set | Result |
|---|---|---|
| `cv_runs/v5_grouped/evaluation.json`, `reports/lupang_retrain/compare.json` | 356 clips, 5 source folds (unseen signers) | v5 single closed-set 0.556; v5 ens3 0.590, correct 20.2 % / wrong 1.7 % / false accept 1.4 % (LOFO thresholds) |
| `cv_runs/user_v7/report.json` | user's later 70 takes / older 35 / 3 unseen signers | with user takes: 91.4 % / 48.6 % / 19.4 % correct, 0 wrong |
| `cv_runs/fix_v9/report.json` | 3 unseen reference signers (62); user's later takes (70) | switch: 22.6 % correct, 0 wrong; 94.3 % correct, 0 wrong |
| `reports/lupang_retrain/fix_perlas_cv_gated.log` | 14 Perlas attempts, two folds | Perlas 2/14 → 9/14 correct, 0 wrong; other lines' correct unchanged; +1–2 "as Perlas" (111351 #043/#044) |

### 3.5 Invalid-gesture rejection **[O]**
Built from the 130 clean attempts with hands (real user webcam landmarks):

| Input | n | accepted (false accept) | Mostly rejected by |
|---|---|---|---|
| first half of an attempt | 130 | 4 (3.1 %) | LOW_CONFIDENCE, INVALID_CLASS, LOW_MOTION |
| second half | 130 | 2 (1.5 %) | LOW_MOTION, LOW_CONFIDENCE, INVALID_CLASS |
| first third | 130 | 0 | TOO_SHORT, LOW_MOTION, INVALID_CLASS |
| hands removed | 130 | 0 | NO_HANDS |
| two different lines in one capture | 108 | **14 (13.0 %)** | LOW_CONFIDENCE, INVALID_CLASS |

Synthetic scenarios from dataset clips (every 3rd clip; these clips are training data, so optimistic): idle 0/195,
no hands 0/195, incomplete first/second half/first third/middle 0–1/195, random movement 0/195, hands below image 0/195,
transition A→B 4/195 (2.1 %), **two lines 27/195 (13.8 %)**, hands in only 25 % of frames 14/195 (7.2 %),
less-active hand never detected 77/187 (41 %; real lines missing one hand — accepting them is partly correct).
**Model vs application rejection:** "INVALID_CLASS" = the model's own INVALID_GESTURE output is top-1; every other code is
application logic in `lupang_common` (pre-model gates: NO_HANDS, TOO_SHORT, LOW_LANDMARKS, OUT_OF_FRAME, LOW_MOTION,
PHASE_IMBALANCE, SINGLE_STROKE; post-model gates: LOW_CONFIDENCE, SMALL_MARGIN, HIGH_ENTROPY, FRAGMENT_DURATION, UNSTABLE).

## 4. Perlas ng Silanganan

* **[V]** The low confidence you reported (0.518, margin 0.37) was produced by the model **before** the Perlas patch: in
  session 111351, 23 attempts' recorded probabilities match only "v9 before Perlas patch".
* **[O]** Current model, Perlas attempts: trained-on 19 → 19 accepted (median confidence 0.91, margin 0.90, entropy 0.17 —
  not independent). Clean (never-trained) Perlas-targeted attempts: only **3** (1 correct, 1 rejected, 1 accepted as Bayang).
  Independent evidence = the two-fold test (9/14). **Insufficient independent Perlas data to call it verified.**
* **Ang kislap confusion [O]:** 8 clean Ang kislap attempts → 1 correct, 7 rejected, **0 accepted as Perlas**; no Ang kislap
  attempt or dataset clip is accepted as Perlas. Perlas is accepted for 4 Bayang-targeted attempts (111351 #043/#044/#060/#061)
  — each ranked Perlas first with Bayang ≈ 0.01 by every model version, and each sits inside a Perlas block of the session
  → likely label slips **[I]**, unverifiable without video **[U]**.
* Cause of the original uncertainty **[V, earlier work]**: few user Perlas samples vs 16 user Ang kislap takes; the patch
  added 14 labelled attempts. Not a preprocessing or threshold difference (thresholds are identical across versions).

## 5. Data integrity and evaluation risks

* **[V] Duplicates:** 593 raw files, 0 exact (sha256) duplicates, 0 near-duplicates (feature distance < 0.02). Clean webcam
  attempts vs dataset: nearest distance min 0.21, median 0.49 (dataset clip-to-clip median 0.49) → attempts are not copies of
  training clips.
* **[V] Leakage:** 34 attempts were used to train the staged model (separated above). The fix experiments kept test sources
  / attempts out of training (code: `fix_lupang_lines.split`, `fix_perlas.new_perlas(parity)`); final models were then trained
  on everything, so no held-out set exists for the exact staged weights.
* **[V] Class imbalance:** per-line clips 15–49 (user takes concentrated in 12 lines); merged line 11: 18 samples / 7 sources;
  clean labelled attempts per line 0–15; lines 08, 09, 10 have no clean labelled attempts.
* **[V] Label-reliability problems in the attempt logs:** three fixed-target runs (075517, 085620, 111351 #006–020) and
  repeated adjacent-line mismatches. The tester logs the *selected* target, not what was signed.
* **[V] Inconsistent derived label file:** `y_raw_lupang.npy` (modified 2026-10-11 03:01, `.bak` beside it) has 465 of 713
  labels shifted down from index 11 (11→10 … 22→21; a 22-class numbering) while `lupang_common.CLASS_NAMES` and the staged
  model use 23 classes (INVALID = 22). Who changed it is **[U]**. The staged model's training did not read it
  (`load_captures` builds labels from the folders + cache) **[V, code]**; scripts that do read it — `train_lupang_model.py`
  (main), `test_lupang_recognition.heldout_split` (default split) — now get mismatched labels.
* **[V] Provenance gap:** the original component (`models_staging_v5_ens3`) is NOT reproducible from `palm_lupang_v5.pt`
  + `_m1` + `_m2` (max prob diff 0.28): `palm_lupang_v5.pt` was overwritten 2026-10-11 05:25 by a retrain that held out all
  user takes; the original member-0 weights exist only inside the staged ONNX.
* **[V] Metadata:** staged JSON `ensemble_members` lists only `palm_lupang_v9_B_m0..2`; the real composition is under `switch`.
  `model_version` is identical before/after the Perlas patch (`lupang-v4/palm_lupang_v9_switch`).
* **[V] Training vs webcam preprocessing:** same functions (`lupang_common` byte-identical in repo and service,
  `885b30ca…`), same MediaPipe settings (`HOLISTIC_KWARGS`), unmirrored frames, aspect handling (`raw_from_results` ≡
  `raw_from_arrays`, checked by `self_test`). Differences that remain: webcam ~20 fps at 640×480 vs reference 30 fps up to
  1920×1080; timestamps from `perf_counter` (live) vs decoder `POS_MSEC` (files); hand detection on the user's webcam is much
  sparser (both hands 18 % median in the 2026-10-04 takes vs 73 % in reference clips).
* Repeated testing on the same samples: the user's attempts were replayed many times during development; threshold choices
  for the staged model were made on CV data, not on these attempts **[V, logs]**.

## 6. Historical development timeline (earliest available → current)

| Date (local) | Evidence | Event |
|---|---|---|
| ≤ 2026-09-13 | raw files' creation time 09-13 05:39 / 06:04 | reference videos exist on disk **[O]**; origin before this **[U]** |
| 2026-09-28 08:27–08:28 | empty folder `D:\lupang hinirang-20260928T002750Z-1-001` (Google-Drive export name, 00:27:50 UTC) created 08:28; all 327 reference videos mtime 08:28 | videos extracted into `specialists/civic_observances/raw/lupang_hinirang/<22 folders>` **[I]** (archive itself missing **[U]**) |
| 09-28 08:30–08:51 | `extract_lupang_hinirang.py`, `train_lupang_hinirang.py`, `landmarks_lupang_hinirang/` (327 .npy), `lupang_hinirang_holistic.joblib`, `fsl_lupang_hinirang.onnx` (41 MB), `labels_lupang_hinirang.json` | first pipeline: holistic features → tree/joblib model → ONNX (818-dim input); **legacy, still served by production endpoint `/v1/predict/lupang_hinirang`** |
| 09-29 | `demo_cam_lupang_hinirang*.py` | early webcam demos (inactive) |
| 10-03 12:30–19:06 | `prepare_lupang_*`, `X_palm/holistic/fresh128_lupang.npy`, `palm_lupang_23class/holistic/robust/fresh128.pt`, `live_lupang_*` | several 23-class experiments (inactive) |
| 10-04 13:56–14:40 | 36 `webcam_take_*` (old), `lupang_landmarks_cache.pkl`, `X/y_raw_lupang.npy`, `palm_lupang_best.json` | user's first takes; raw-landmark v4 dataset (backup copies in `backups/lupang_v4_pre_retrain_20261010/root`) |
| 10-07 15:38–15:40 | `palm_lupang_best.pt`, `inference-service/models/fsl_lupang_hinirang_v4.onnx` | **production v4 model** (still in production) |
| 10-08 22:04–22:30 | `lupang_common.py`, `train_lupang_model.py`, `cv_lupang.py`, `live_lupang_engine.py`, `lupang_hinirang_v4.json` | shared pipeline module + export metadata |
| 10-10 (this work) | `audit_lupang_dataset.py`, `retrain_lupang_grouped.py`, `models_staging_v5_single`, `palm_lupang_v5_m1/m2.pt`, `models_staging_v5_ens3` (23:48) | re-extraction with decoder timestamps, grouped CV, v5 ensemble = **current "original" component** |
| 10-11 01:14–03:01 | `record_lupang_samples.py` (fixed), 230 new takes 02:23–02:47, cache/X re-extracted 02:59; `y_raw_lupang.npy` relabelled 03:01 (by **[U]**) | user's own takes |
| 10-11 05:25 | `palm_lupang_v5.pt` overwritten (303 train clips, user takes held out) | provenance gap (§5) |
| 10-11 06:58–07:30 | `retrain_lupang_user.py`, `palm_lupang_v7_user_m*`, `models_staging_v7_user` | user-adapted v7 (superseded) |
| 10-12 07:52–08:42 | `merge_lupang_user.py`, `build_lupang_switch.py`, `models_staging_v8_switch` | switch v8 (superseded) |
| 10-12 09:23–10:32 | `lupang_common.py` (merged line 11), `extract_lupang_dataset.merge_split_line`, `fix_lupang_lines.py`, `palm_lupang_v9_A/B_m*`, `models_staging_v9_A/B`, switch (backup `models_staging_v9_switch_before_perlas`) | merged line + Bayang/Perlas attempts in user part = **current user component v9 B** |
| 10-12 11:00 | `webcam_test_staging.py` (backend option), `check_cameras.py` | current tester |
| 10-12 11:45–11:56 | `fix_perlas.py`, `palm_lupang_v9p_B_m*`, `models_staging_v9p_B`, staged ONNX `763478f3…` | Perlas patch → **current staged model** |

## 7. File inventory (Lupang Hinirang, current pipeline)

| Path | Type / purpose | Origin | Used now? | sha256 (prefix) |
|---|---|---|---|---|
| `specialists/civic_observances/raw/lupang_hinirang/NN_*/*.mp4` (593) | source videos: 327 reference + 266 user takes (+230 `.timestamps.json`) | extracted (09-28) / recorded (`record_lupang_samples.py`) | yes (training data) | — |
| `lupang_landmarks_cache.pkl` | MediaPipe raw landmarks + timestamps per video | generated by `extract_lupang_dataset.extract_all` (10-11 02:59) | yes (via `test_lupang_recognition.load_captures`) | `702849cc` |
| `lupang_dataset_manifest.json` | per-clip validity (excluded clips) | `audit_lupang_dataset` via extraction / fix round | yes (`excluded_paths`) | `2fcf73a7` |
| `X_raw_lupang.npy`, `y_raw_lupang.npy`, `groups/kind/dur_raw_lupang.npy`, `lupang_meta.json` | fixed-length feature dataset | generated 10-11 02:59; **y/meta relabelled 03:01** | not by the staged model's training; `X_raw` used for ONNX parity checks | `4e6ac64d` (y) |
| `lupang_common.py` (= `inference-service/app/lupang_common.py`) | features, cleaning, gates, model class, `evaluate_capture` | manual | **yes (training + service)** | `885b30ca` |
| `extract_lupang_dataset.py`, `audit_lupang_dataset.py` | extraction, validation, merged-line joining | manual | yes (data loading) | `3b63df2b`, `2449ce85` |
| `test_lupang_recognition.py` | `load_captures`, scenario builders | manual | yes (training/eval loader) | `a523d3e4` |
| `train_lupang_model.py`, `cv_lupang.py` | training loop (`train_model`, `augment`, pool), recipes | manual | yes (imported) | `324e720c`, `999f9fe9` |
| `retrain_lupang_grouped.py` | `inner_split`, `train_one`, `Scorer`, `decide` | manual | yes (imported) | `17c71b56` |
| `fix_lupang_lines.py` | v9 A/B training (`cmd_final`) incl. Bayang/Perlas attempts | manual | produced v9 B | `b656d59f` |
| `fix_perlas.py` | Perlas patch (`finetune`, scope head) | manual | produced v9p B | `7b7a42c6` |
| `export_lupang_onnx.py` | `.pt` ensemble → ONNX + JSON | manual | produced component ONNX | `e8bfadba` |
| `build_lupang_switch.py` | composes staged ONNX (fold, arbitrate, patch) | manual | produced staged ONNX | `b571d062` |
| `palm_lupang_v5_m1.pt`, `palm_lupang_v5_m2.pt` | original-component members 1–2 | trained 10-10 | inside staged ONNX | `e951506c`, `2533f715` |
| `palm_lupang_v5.pt` | **overwritten**; not the staged member 0 | retrained 10-11 05:25 | no | `66605537` |
| `palm_lupang_v9_B_m0..2.pt` | user-adapted members | trained 10-12 10:14–10:16 | inside staged ONNX | `45b018e6`, `5e668a41`, `641c9de0` |
| `palm_lupang_v9p_B_m0..2.pt` | Perlas patch members | fine-tuned 10-12 11:53–11:55 | inside staged ONNX | `552e07f1`, `6db6dba3`, `c1ce2dce` |
| `cv_runs/fix_v9/final_gate_B.json` | gate calibration used for v9 B / v9p B exports | generated | values in staged JSON | `dde30570` |
| `inference-service/models_staging_v5_ens3/`, `_v9_B/`, `_v9p_B/` | component ONNX + JSON | exported | build inputs | `51d8e1ea`, `9537c97e`, `d79b8b09` |
| **`inference-service/models_staging/fsl_lupang_hinirang_v4.onnx` + `lupang_hinirang_v4.json`** | **authoritative staged model** | built 10-12 11:56 | **yes** | `763478f3`, `f0154e5c` |
| `inference-service/models_staging/` other files (greetings, letters, calendar, legacy lupang ONNX) | copies of production models so the app can boot | copied | loaded by server, not Lupang raw path | — |
| `inference-service/app/main.py`, `app/lupang_raw.py` | API + raw specialist inference | manual | **yes** | `73aeb75d`, `d78326d3` |
| `inference-service/local_staging_server.py` | local server (staging dir, auth override, `/local/staging_info`) | manual | **yes** | `5143b14e` |
| `webcam_test_staging.py` | webcam tester | manual | **yes** | `5a91052e` |
| `live_lupang_engine.py` | provides `open_camera` (shared) | manual | **yes (one function)** | `c84bd6c8` |
| `inspect_lupang_captures.py`, `check_cameras.py` | diagnostics | manual | optional tools | — |
| Superseded: `models_staging_v5_single/`, `_v7_user/`, `_v8_switch/`, `_v9_A/`, `_v9_switch_before_perlas/`, `palm_lupang_v7_user_*`, `palm_lupang_v9_A_*`, `cv_runs/*`, `compare_lupang_variants.py`, `evaluate_lupang_lines.py`, `merge_lupang_user.py`, `retrain_lupang_user.py`, `lupang_degrade.py`, all `demo_cam_lupang*`, `live_lupang_*` (except `open_camera`), `palm_lupang_23class/holistic/robust/fresh128.pt`, `X_palm/holistic/fresh128` | experiments / backups | — | no | — |
| Production: `inference-service/models/fsl_lupang_hinirang_v4.onnx` (+json), legacy `fsl_lupang_hinirang.onnx` | deployed models | 10-07 / 09-28 | production only | `8208f496` |

## 8. Webcam-to-prediction execution flow (current, verified in code)

1. `webcam_test_staging.main` → `StagingClient.__init__` → `GET /local/staging_info` (`local_staging_server.staging_info`):
   refuses unless `loaded_source_checkpoint == palm_lupang_v9_switch` and ONNX ≠ production.
2. `run_live`: camera `live_lupang_engine.open_camera(index)` (OpenCV `CAP_DSHOW`, fallback default) or `cv2.VideoCapture(index, CAP_MSMF)` with `--backend msmf`. Windows camera permission is handled by the OS (no app code).
3. Per frame: `lc.prepare_frame` (≤ 960 px, BGR→RGB, unflipped) → MediaPipe `Holistic(**lc.HOLISTIC_KWARGS)` → `frame_dict` (pose 33×[x, y, visibility], hands 21×[x, y, z], t = `perf_counter` − start); display: landmarks drawn, `display_frame` mirrors / upscales only the display.
4. SPACE…SPACE (or 12 s): `StagingClient.predict` → `POST /v1/predict_raw/lupang_hinirang` (JSON).
5. Server (`app/main.py`): `RawPredictRequest` validation (33/21 points, ≤ 600 frames, increasing t, ≤ 30 s) → `predict_raw` → `RawSpecialistModel.predict` (`app/lupang_raw.py`), model loaded once in `lifespan` → `load_raw_specialists` from `MODELS_DIR = models_staging`.
6. `RawSpecialistModel.to_raw` → `lc.raw_from_arrays` (aspect = w/h) → `lc.evaluate_capture`:
   `build_sequence_with_info` (`clean_sequence`: trim to hand frames, `capture_quality`, resting hand, pose repair, gap filling, `_trim_still_edges`; `static_features` (mid-shoulder anchor, shoulder-span scale); `resample` to 32; `add_velocity` → (32, 181)) →
   pre-model gates `duration_gate`, `coverage_gate`, `kinematic_gate` →
   ONNX on [sequence, mirror, 2 trimmed views] (`_batch_probs`, softmax of the graph's log-probs) →
   in-graph: original v5 ensemble (classes 12→11 folded) | user v9 B ensemble, replaced by v9p B where v9p B's top-1 is Perlas | switch: user part used if its top-1 ∈ recorded lines {1,2,5,6,8,10,11,13–17,19–22} and it is ≥ as confident as the original →
   `gate_decision` (`probability_gate`: INVALID top-1, conf ≥ 0.65, margin ≥ 0.65, entropy ≤ 0.50; `class_duration_check`) + `stability_check`.
7. Response JSON (`accepted`, `prediction`, `rejection`, `checks`, `top_k`, `capture`, `model_version`) → tester `summarize` / `draw` (verdict, confidence, margin, duration, check list) → `SessionLog.add` (CSV + `attempt_NNN.json`).
Shared with other tasks: `app/main.py`, `local_staging_server.py`, `lupang_common.py` (also used by Calendar), MediaPipe/OpenCV. Lupang-specific: model files, `RAW_SPECIALISTS["lupang_hinirang"]`, gate JSON, tester.

## 9. Dependency and provenance map

| Stage | Input files | Script / function | Output files | Purpose | Status |
|---|---|---|---|---|---|
| 0 Source | Drive export `lupang hinirang-20260928T002750Z…` (missing) | manual extraction **[I]** | `raw/lupang_hinirang/NN_*/*.mp4` (327) | reference videos | earliest available = videos |
| 0b User takes | webcam | `record_lupang_samples.main/save_take` | `webcam_take_*.mp4` (+ `.timestamps.json`) | user's versions | used |
| 1 Landmarks | videos | `extract_lupang_dataset.extract_all` → `lc.extract_raw_from_video(with_meta)` | `lupang_landmarks_cache.pkl` | raw MediaPipe landmarks + decoder timestamps | used |
| 2 Validation | cache, videos | `audit_lupang_dataset.audit/clip_issues` | `lupang_dataset_manifest.json` | exclude invalid clips | used |
| 3 Capture list | cache, folders, manifest | `test_lupang_recognition.load_captures` + `extract_lupang_dataset.merge_split_line` | in-memory captures (585) | labels from folders; merged line 11 | used |
| 4 Features + negatives | captures | `cv_lupang.build_training_set` → `make_clip` (`lc.clean_sequence`, `static_features`, `resample`, `add_velocity`), `make_negatives` (v5 mix) | in-memory X, y | training tensors | used |
| 5a Original component | captures (Oct 10 data) | `retrain_lupang_grouped.cmd_final` + member runs | `palm_lupang_v5.pt` (lost) / `_m1` / `_m2` | reference-only ensemble | inside staged ONNX |
| 5b User component | captures + 090256 Bayang/Perlas attempts | `fix_lupang_lines.cmd_final` → `R.inner_split`, `R.train_one` → `train_lupang_model.train_model` | `palm_lupang_v9_B_m0..2.pt`, `cv_runs/fix_v9/final_gate_B.json` | user-adapted ensemble | inside staged ONNX |
| 5c Perlas patch | v9 B members + 111351 Perlas attempts | `fix_perlas.finetune` (head only) | `palm_lupang_v9p_B_m0..2.pt` | Perlas-only fix | inside staged ONNX |
| 6 Export | `.pt` members, gate JSON | `export_lupang_onnx.main` (`MeanProbEnsemble`) | `models_staging_v5_ens3/`, `_v9_B/`, `_v9p_B/` | ONNX components | build inputs |
| 7 Compose / stage | 3 component dirs | `build_lupang_switch.build` (`--fold 12:11 --arbitrate --patch … --patch-class 2`) | `models_staging/fsl_lupang_hinirang_v4.onnx` + JSON | **staged model** | **active** |
| 8 Serve | staged dir | `local_staging_server.main` → `app.main` | HTTP API on 127.0.0.1:8765 | local inference | active when started |
| 9 Webcam | camera | `webcam_test_staging.run_live` (§8) | display, CSV, attempt JSON | testing | active |

Dependency chain: Drive export (missing) → raw videos (+ user takes) → `lupang_landmarks_cache.pkl` (+ manifest) →
`load_captures` / `merge_split_line` → training tensors → {v5 ensemble, v9 B ensemble, v9p B patch} → component ONNX →
`build_lupang_switch` → **staged ONNX + JSON** → `RawSpecialistModel` (server) ← HTTP ← `webcam_test_staging.py` ← camera.

## 10. Commands and tests executed (all read-only)

| Command | Result |
|---|---|
| `python D:/tmp_lupang/audit/hashsnap.py …hashes_before.json` / `…hashes_after.json` | 16 332 files hashed twice; 0 added / 0 removed / 0 changed |
| `git ls-files`, `git log` | no Lupang files tracked; last commit 2026-09-26 |
| timestamp listing of raw videos and Lupang artifacts (`prov2.txt`) | timeline §6 |
| `y_raw_lupang.npy` vs `.bak`, `lupang_meta.json` vs `.bak` (numpy/json compare) | 465 labels shifted (§5) |
| metadata + reproducibility check (`prov3.txt`; torch + onnxruntime inference only) | v9 B and v9p B reproduce (≤ 2.7e-7); v5 ens3 does not (0.28) |
| `grep` of execution path (`flow.txt`) | §8 |
| `python D:/tmp_lupang/audit/audit_eval.py` (in-process `RawSpecialistModel.predict`, `audit_lupang_dataset.audit` without `--json`) | §3, §5 |
Not run: the inference-service pytest suite and `python lupang_common.py` self-test (both passed in the previous session
after the last code change; not repeated to keep the run strictly read-only); no live webcam capture (would create new
session files in the project); no retraining / CV re-runs.

## 11. Reliability assessment

Verified strengths: identical preprocessing code in training and service; deterministic, reproducible component exports
(except original member 0); strong rejection of fragments, idle, no-hands, out-of-frame input; no dataset clip and no
trained-on attempt is ever accepted as a wrong line; Ang kislap is never accepted as Perlas in available data.
Remaining risks: (1) ~49 % of clean labelled attempts are rejected — largely low hand-tracking / low confidence;
(2) 11 adjacent-line acceptances whose labels cannot be verified; (3) two-lines-in-one-capture accepted 13–14 %;
(4) no held-out evaluation of the exact staged weights, and none on new signers for lines the user recorded;
(5) the original component cannot be retrained/reproduced from disk; (6) `y_raw_lupang.npy` label shift; (7) metadata does
not name all components and the version string does not change with patches.
Evidence needed: a fresh labelled session with the target set before every attempt and a short screen/video note of what
was signed (≥ 5 attempts per line, all 22 lines incl. 08, 09, 10); recordings from at least 2–3 other signers; a restored
copy of the original member-0 checkpoint or an accepted rebuild of the original component.

## 12. Integrity confirmation

**[V]** No project file was created, modified or deleted: SHA-256 snapshot of all 16 332 files under
`D:\model2\fslr-transformer-vs-iv3gru` (excluding `.git`, `__pycache__`, `fslr_env`) taken before and after the audit is
identical. Production model files are unchanged (`8208f496…`, `1f0423ff…`). All audit outputs are in `D:\tmp_lupang\audit\`.
