#!/bin/sh
cd /d/model2/fslr-transformer-vs-iv3gru || exit 1
export TMP=D:/tmp_lupang TEMP=D:/tmp_lupang PYTHONUNBUFFERED=1
for m in 0 1 2; do
  python retrain_lupang_user.py experiment --with-user 0 --member $m > reports/lupang_retrain/user_A_m$m.log 2>&1 &
  python retrain_lupang_user.py experiment --with-user 1 --member $m > reports/lupang_retrain/user_B_m$m.log 2>&1 &
  python retrain_lupang_user.py final --member $m > reports/lupang_retrain/user_final_m$m.log 2>&1 &
done
wait
python retrain_lupang_user.py report > reports/lupang_retrain/user_report.log 2>&1
echo "user v7 done"
