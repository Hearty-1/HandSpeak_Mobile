#!/bin/sh
cd /d/model2/fslr-transformer-vs-iv3gru || exit 1
export TMP=D:/tmp_lupang TEMP=D:/tmp_lupang PYTHONUNBUFFERED=1
for f in 0 1 2 3 4; do
  python retrain_lupang_grouped.py cv --recipe v4 --only-fold $f --threads 1 > reports/lupang_retrain/cv_v4_fold$f.log 2>&1 &
done
python retrain_lupang_grouped.py final --threads 2 > reports/lupang_retrain/final.log 2>&1 &
wait
python retrain_lupang_grouped.py calibrate --recipe v4 > reports/lupang_retrain/calibrate_v4.log 2>&1
python retrain_lupang_grouped.py evaluate --recipe v4 > reports/lupang_retrain/evaluate_v4.log 2>&1
echo "all done"
