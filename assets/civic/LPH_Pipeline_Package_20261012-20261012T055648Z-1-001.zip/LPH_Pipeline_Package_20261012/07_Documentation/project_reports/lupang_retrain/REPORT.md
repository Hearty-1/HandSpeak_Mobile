# Lupang Hinirang retrain — 2026-10-10

**Outcome: the new model was trained, validated, exported to staging and verified end to end, but it was NOT promoted.**
On unseen signers it reaches 55.6 % closed-set accuracy. At thresholds that keep wrong and false accepts near 2 %,
only 16.6 % of complete lines are accepted. The deployed model (`inference-service/models/fsl_lupang_hinirang_v4.onnx`
+ `lupang_hinirang_v4.json`) is unchanged.

## 1. Pipeline actually in use
`lupang_common.py` (feature set `lupang-v4`, verbatim copy in `inference-service/app/`) → `extract_lupang_dataset.py`
→ `train_lupang_model.py` → `export_lupang_onnx.py` → `inference-service/app/lupang_raw.py`
(`POST /v1/predict_raw/lupang_hinirang`). Model: FullSequenceConvBiLSTM, input (32, 181), 23 outputs (22 lines + INVALID_GESTURE at 22).
- Normalisation: mid-shoulder anchor, shoulder-span scale (static_features); hand shape / palm span. Self-test: mirror err 6e-6, scale/translation invariant.
- Missing landmarks: explicit present-flags + zeroed channels; bounded gap filling (≤0.5 s pose, ≤1 s hand); coverage gates reject low-evidence captures.
- Pose: MediaPipe 33×(x,y,z,vis) is captured; the features use 7 points (nose, shoulders, elbows, wrists) x/y + visibility. Hands 21×3.
- None of these Lupang files are tracked by git.

## 2. Clip counts (363 source videos, 17 sources)
| # | line | files | valid before | valid after |
|---|---|---|---|---|
| 0 | Bayang magiliw | 16 | 15 | 15 |
| 1 | Perlas ng Silanganan | 16 | 16 | 16 |
| 2 | Alab ng puso | 16 | 16 | 16 |
| 3 | Sa dibdib mo'y buhay | 16 | 16 | 16 |
| 4 | Lupang hinirang | 16 | 16 | 16 |
| 5 | Duyan ka ng magiting | 16 | 15 | 15 |
| 6 | Sa manlulupig | 16 | 16 | 16 |
| 7 | Di ka pasisiil | 25 | 24 | 24 |
| 8 | Sa dagat at bundok | 16 | 16 | 16 |
| 9 | Sa simoy at sa langit | 16 | 16 | 16 |
| 10 | May dilag ang tula at awit | 6 | 3 | 3 |
| 11 | Sa paglayang minamahal | 3 | 3 | 3 |
| 12 | Ang kislap ng watawat mo'y | 16 | 16 | 16 |
| 13 | Tagumpay na nagniningning | 16 | 16 | 16 |
| 14 | Ang bituin at araw niya | 24 | 24 | 24 |
| 15 | Kailan pa ma'y di magdidilim | 27 | 27 | 27 |
| 16 | Lupa ng araw ng luwalhati't pagsinta | 16 | 16 | 16 |
| 17 | Buhay ay langit sa piling mo | 16 | 16 | 16 |
| 18 | Aming ligaya | 24 | 23 | 23 |
| 19 | Na pag may mang-aapi | 15 | 15 | 15 |
| 20 | Ang mamatay | 16 | 16 | 16 |
| 21 | Nang dahil sa 'yo | 15 | 15 | 15 |
| | **total** | **363** | **356** | **356** |

"Before" = the same validity rules applied to the old cache (the old pipeline itself trained on 362 clips, incl. the invalid ones below).
Invalid (excluded): 4 two-line clips (3× line 11 containing 11+12, 1× line 19 containing 19+20), `cJb_34tWMWc_Bayang_magiliw` (0.50 s active),
`cJb_34tWMWc_Duyan_ka_ng_magiting` (hands in 28 % of frames), `webcam_take_1791093374` (no hands). Exact / near duplicates: none.
27 file names are spelling variants of their line (kept). Lines 11 and 12 have only 3 clips, all from the same 3 sources.

## 3. Extraction / validation results
- 363/363 decoded; pose frames with exactly 33 landmarks 28,838/28,838; hands with 21: 21,212/21,212 (L), 21,091/21,091 (R).
- Timestamps: decoder presentation times (CAP_PROP_POS_MSEC), strictly increasing for all 363. Old index/fps timing was off by up to 0.126 s on SRC10 (variable frame rate).
- Upright: 100 % of pose frames in every clip; unmirrored (left shoulder on image right): ≥ 98.3 % in every clip.
- Landmarks are identical to the old cache (MediaPipe is deterministic); only timestamps changed.
- Class mapping identical across folders, `lupang_common.CLASS_NAMES`, exported `class_names`, `labels_lupang_hinirang.json`,
  the Flutter manifest (`D:\HandSpeak_Mobile-rules-compat\assets\civic\labels_lupang_hinirang.json`) and the client's `_invalidIndex = 22`. No change needed.

## 4. Training / split methodology
Recipe v5 (still-edge trim in training AND inference, plus transition/two-line negatives; 160 synthetic negatives). Same architecture and
hyper-parameters as before, without the hand-picked confusable-pair penalty (it had been chosen from leaky validation results).
- Outer: 5 folds by source (sources of rare lines spread first). Inner: whole held-out sources (~15 %) used for early stopping and threshold calibration. Test folds were never used for any choice.
- Per fold train / val / test clips: 235/59/62, 235/60/61, 218/60/78, 203/58/95, 222/74/60 (per-line counts in `cv_runs/v5_grouped/fold*.json`).
- Final model: 281 train / 75 val clips (val sources bE63aZBXC_g, cJb_34tWMWc, webcam_take) → `palm_lupang_v5.pt`.

## 5. Held-out test results (356 clips, each from a source its model never saw)
Closed-set accuracy **0.556**, macro F1 0.517. Gated (conf 0.90 / margin 0.20): correct 16.6 %, wrong 2.5 %, no prediction 80.9 %, gated macro F1 0.263. ECE 0.128.
Per-line P/R/F1 and the 22×23 confusion matrix: `cv_runs/v5_grouped/evaluation.json`.
Weakest: lines 11 and 12 (F1 0.00, never recognised), Ang bituin at araw niya (0.21, confused with Tagumpay na nagniningning 11/24),
Ang mamatay (0.39), Aming ligaya (0.40). Best: Nang dahil sa 'yo (0.85), Buhay ay langit (0.81), Alab ng puso (0.74).

Same protocol, deployed v4 recipe: closed-set 0.508; gated correct 14.3 %, wrong 1.1 %; validation ECE 0.065.

## 6. Thresholds
- Floor 0.65 / 0.20 on inner validation: wrong accepts 6.3 %, false accepts on negatives 6.0 % → too permissive.
- Calibrated (lowest setting with wrong ≤ 2 % and false ≤ 2 % on inner validation): **min_conf 0.90, min_margin 0.20**, max_entropy 0.50.
- Per-line minimum duration = 75 % of the median training duration (s): 1.74, 1.70, 1.55, 1.47, 1.89, 1.76, 1.62, 1.40, 1.63, 2.14, 1.36, 1.74, 1.89, 1.75, 1.63, 1.62, 3.12, 3.46, 1.65, 2.00, 1.38, 2.46 (index 0–21).
  On inner validation this rejects 4.2 % of complete lines and lets through 1.3 % of fragments.
- Kinematic: min_energy 1.32, min_phase_frac 0.041, min_tortuosity 1.68; coverage pose ≥ 0.80, hands ≥ 0.30, out-of-frame ≤ 0.50; stability check on.

## 7. Incomplete / unsupported gestures (test folds, calibrated gate)
Accepted as some line: first half ~1.2 %, second half 0.6 %, first third 0.3 %, middle 40 % 0 %, idle 0 %, no hands 0 %,
hands below image 0 %, hands in 25 % of frames 3.6 %, transition A→B 4.0 %, **two lines in one capture 5.4 %**, **random movement 4.8 %**.
Calendar signs through the service with the staged model: 0/83 accepted.

## 8. Files
Created: `audit_lupang_dataset.py`, `retrain_lupang_grouped.py`, `lupang_dataset_manifest.json`, `palm_lupang_v5.pt`, `cv_runs/v5_grouped/`, `cv_runs/v4_grouped/`,
`inference-service/models_staging/` (staged ONNX + JSON + app copy), `reports/lupang_retrain/`, backup `backups/lupang_v4_pre_retrain_20261010/` (25 files + SHA256SUMS).
Modified: `lupang_common.py` (`extract_raw_from_video`: decoder timestamps, landmark-count meta via `with_meta=True`; default behaviour unchanged),
`extract_lupang_dataset.py` (stores meta, excludes invalid clips, writes manifest), `test_lupang_recognition.py` (load_captures honours the manifest),
`inference-service/app/lupang_common.py` (re-synced copy; the service never calls the changed function).
Regenerated (old versions in backup): `lupang_landmarks_cache.pkl`, `X/y/groups/kind/dur_raw_lupang.npy`, `lupang_meta.json`.
Preserved: raw videos, `palm_lupang_best.pt`, all of `inference-service/models/`, `mobile_deployment/`, other datasets/models.

## 9. Tests
- `python lupang_common.py` self-test: OK.
- ONNX export (staging) vs PyTorch: max |Δlogit| 9.5e-7, top-1 agreement 100 %.
- Service path (`test_lupang_recognition.py --model service --models-dir models_staging`) on the final model's held-out sources: identical to offline replay (complete-line correct 9.3 %, wrong 1.3 %; negatives accepted 0.8 %).
- `inference-service` pytest against production models: 29 passed.
- Against staged models: fixture tests fail by design (fixtures hold the old model's probabilities; regenerate with `tests/make_lupang_fixture.py` after promotion).

## 10. Blockers / remaining
1. **Data:** ~16 clips per line from ~16 signers is not enough for signer-independent recognition. Lines 11/12 need ≥ 10 clips each from distinct signers; the 3 two-line clips could be re-cut into 11 and 12.
2. Promotion decision (thresholds 0.90/0.20 make the app reject ~80 % of correct lines from new signers).
3. Environment: C: drive is full (0 GB), which breaks tool output and pip caches; `onnx` is broken in the system Python (protobuf 3.20.3 pinned by mediapipe). Exports/tests used `D:\venv_lupang_export`.
4. Not deployed to Cloud Run.

---
# Addendum (2026-10-10, later): live_lupang_engine2.py analysis and ensemble improvement

## What engine2 actually is
`live_lupang_engine2.py` = `live_lupang_engine.py` with a different gate construction. Its effective gate (verified by
instantiating both) differs in ONE key: `trim_still` (engine/production True, engine2 off). Model (`palm_lupang_best.pt`,
deployed v4), preprocessing, features, min_conf 0.65 / margin 0.20, coverage and stability checks are identical.

## Root causes (signer-independent evidence, compare_lupang_variants.py, 356 held-out clips + 7,800 scenario captures)
1. Trim mismatch is real (v4 trained without trim, production infers with trim) but costs nothing measurable:
   closed-set 0.508 (off) vs 0.506 (on); identical accept / false-accept rates.
2. The v4 checkpoint trained on all 17 sources incl. 29 of the user's own webcam takes; the staged v5 final model
   excluded webcam_take (inner validation). On the user's clips held out, v4 gets 5.7 % right vs v5 17.1 % (at 0.65).
   engine2's live advantage for this user = it has seen this user, plus the looser 0.65 threshold.
3. On unseen signers v4 at 0.65 gives 9.0 % wrong answers, 5.0 % false accepts, 21.6 % of two-line captures accepted.
4. v4 IS better calibrated than single v5: at matched safety (LOFO thresholds, <=2 % wrong / <=2 % false) v4 accepts
   14.3 % of complete lines correctly vs v5 8.4 % (+5.9 pts, 95 % CI +1.7..+11.0).

## Fix: 3-model v5 ensemble (mean probabilities), members early-stopped on different held-out sources
| held-out signers | closed acc | rule | correct | wrong | false accept |
|---|---|---|---|---|---|
| v4 (prod model) | 0.508 | 0.65/0.20 | 0.281 | 0.090 | 0.050 |
| v4 | | LOFO (0.90) | 0.143 | 0.011 | 0.013 |
| v5 single (old staging) | 0.556 | LOFO (0.90-0.95) | 0.084 | 0.011 | 0.006 |
| **v5 ens3** | **0.590** | LOFO (0.65-0.75) | **0.202** | 0.017 | 0.014 |
Bootstrap over sources: ens3 - v4 closed-set +8.1 pts (CI +3.9..+12.4); at matched safety +5.9 (CI +0.9..+10.2);
ens3 - v5 single at matched safety +11.8 (CI +3.8..+19.4). Versus v4 at its deployed 0.65: -7.9 pts correct
(CI -13.0..-3.2) but wrong answers 1.7 % vs 9.0 % and false accepts 1.4 % vs 5.0 % -> a trade-off, not a dominance.
Per-line precision of ens3 is ~1.0; recall 0 on lines 8, 15, 19 (their extra clips are the user's webcam takes,
held out together) and 11, 12 (3 clips each). Details: reports/lupang_retrain/compare.json.

## Deployable candidate (staged, NOT promoted)
`palm_lupang_v5.pt` + `palm_lupang_v5_m1.pt` + `palm_lupang_v5_m2.pt` -> `inference-service/models_staging/`
(`source_checkpoint` palm_lupang_v5_ens3; 2 of 3 members trained on the user's webcam takes).
Gate: min_conf 0.65, min_margin 0.65 (chosen on all folds' held-out captures with the same targets; pooled:
correct 19.7 %, wrong 2.0 %, false accept 1.3 %, two lines 4.8 %); kinematics / per-line durations recalibrated on all clips.
Checks: ONNX vs PyTorch 1.9e-6 / 100 % top-1; service path vs PyTorch ensemble 80/80 identical decisions;
production pytest 29 passed; webcam tester verifies palm_lupang_v5_ens3 (sha 51d8e1ea...).
Previous single-model staging kept in `inference-service/models_staging_v5_single/`.

---
# Addendum 2 (2026-10-11): affected-line investigation

Evidence: user's webcam session logs (61 targeted attempts on v5 single, 126 untargeted on v5 ens3; no landmarks were
saved), user's 35 webcam takes, held-out CV of all variants (evaluate_lupang_lines.py -> lines_baselines.json, lines_v6.json).

Root causes
1. Hand detection on the user's webcam: both hands detected in 18 % of active frames (reference 73 %), any hand 78 % (98 %),
   20 fps (30). Frames show hands in view but motion-blurred; MediaPipe settings (complexity 2, lower thresholds) do not help
   (both-hands 0.18 -> 0.20 / 0.18). 41 of 126 live attempts had INVALID_GESTURE as top-1.
2. Cross-signer inconsistency (model-free leave-one-signer-out 1-NN): Lupa ng araw 0.00, Aming ligaya 0.09, Tagumpay 0.19,
   Ang kislap 0.25, Sa simoy / Sa dagat / Ang mamatay 0.31, Di ka / Ang bituin / Na pag 0.33 vs Alab 0.94.
3. User's own signing in training only for lines 8, 15, 16, 19, because record_lupang_samples.py offered only those 4 lines
   (its option 3 also pointed to a non-existent folder name, and it wrote every take at a fixed 20 fps without measuring).
4. Lines 11 / 12: 3 clips each (all from 3 sources).
5. Ang bituin -> Tagumpay: 11-12 of 24 held-out clips; also seen live (13 / 14 swap as top-2).
Held-out failure mode on affected lines is "no prediction", not wrong answers (confidently wrong <= 0.06 except May dilag 1/3).

Tried and REJECTED: v6 / v6p (training on webcam-degraded copies calibrated to the user's takes; v6p + pair penalty 14:13).
Closed-set accuracy fell (clean 0.556 -> 0.492 / 0.483; user's takes 0.371 -> 0.200 / 0.171) and v6 gave 11.4 % confidently
wrong answers on the user's takes. Not deployed; staged model remains v5 ens3.

Fixed: record_lupang_samples.py (all 22 lines, real folders, measured fps + timestamp sidecar), webcam_test_staging.py
(saves landmarks + response per attempt, live hand-detection display), inspect_lupang_captures.py (per-line capture vs model
diagnosis, replay through any models dir). Production unchanged (sha256 identical to backup), 29 service tests pass.

---
# Addendum 3 (2026-10-11): model trained with the user's own takes (palm_lupang_v7_user_ens3, STAGED)

The user recorded 229 new takes (12 lines, labels confirmed by the user). Their own versions of several lines differ from
the reference signers'. Bug fixed: retrain_lupang_grouped.inner_split moved the whole webcam_take source (264 clips) into
validation, so a retrain trained on none of the user's data; a source larger than the validation share now stays in training.

Controlled experiment (retrain_lupang_user.py; 3-member ensembles; staged thresholds 0.65/0.65; cv_runs/user_v7/report.json):
| held-out set | A: reference only | B: + user's takes |
|---|---|---|
| user's later takes (70, not trained on): correct / wrong / top-1 right | 4.3 % / 0 / 55.7 % | 91.4 % / 0 / 100 % |
| user's older-session takes (35): correct | 11.4 % | 48.6 % |
| 3 unseen reference signers (62): correct / top-1 right / negatives accepted | 27.4 % / 59.7 % / 2.1 % | 19.4 % / 67.7 % / 0.9 % |
User's negatives (fragments, two lines, ...) accepted: 1.4 % -> 1.3 %.
Duration floors: pooled median kept (signer-balanced floors: other signers +4.8 pts correct but the user's incomplete
signs accepted 0 % -> 1.8 %); alternative in cv_runs/user_v7/balanced_floors_B.json.

Final ensemble on all 585 clips (264 user) -> inference-service/models_staging (previous staging kept in models_staging_v5_ens3).
Replay of the user's real 06:23 tester attempts: Lupang hinirang 0/6 -> 6/6 (0.91-0.93), Duyan 0/4 -> 3/4, but lines WITHOUT
user takes regressed (Bayang magiliw 2/6 -> 0/6, Alab and Sa dibdib accepted -> rejected); no wrong accepts either way.
Cause: user takes exist for only 12 of 22 lines (none for Perlas, Bayang, Alab, Sa dibdib, Sa manlulupig, Sa dagat,
Sa paglayang, Buhay; only old takes for Kailan, Aming ligaya). Fix = user takes for all 22 lines, then retrain_lupang_user.py.
Production unchanged (sha256 8208f496...), 29 service tests pass.

---
# Addendum 4 (2026-10-12): merging the user's takes without losing the other lines (palm_lupang_v8_switch, STAGED on :8765)

Regression reproduced (merge_lupang_user.py, cv_runs/merge_v8): user takes of 5 lines withheld as stand-ins for lines the
user has not recorded. User's Tagumpay: original-style model 11/21 accepted -> retrain with user takes 0/21.
Approaches on held-out data (thresholds 0.65/0.65; correct / wrong):
| | user's unrecorded lines (114) | user's recorded lines, later takes (38) | 3 unseen reference signers (62) |
|---|---|---|---|
| A original-style | 14.9 % / 3.5 % | 2.6 % / 0 | 25.8 % / 0 |
| B + user takes (v7) | 3.5 % / 1.8 % | 100 % / 0 | 21.0 % / 1.6 % |
| C + webcam copies of reference | 1.8 % / 0.9 % | 100 % / 0 | 12.9 % / 0 |
| A+B average | 5.3 % / 2.6 % | 15.8 % / 0 | 16.1 % / 0 |
| routing (B mass split, A ranks rest) | 4.4 % / 3.5 % | 100 % / 0 | 25.8 % / 0 |
| SWITCH (B if its top-1 is a recorded line, else A) | 6.1 % / 3.5 % | 100 % / 0 | 25.8 % / 0 (= A) |
Chosen: SWITCH. Remaining loss: the user's version of an unrecorded line can resemble the user's version of a recorded
line (Tagumpay vs Ang kislap); only takes for those lines fix that.
Deployed to staging: original = models_staging_v5_ens3, user-adapted = models_staging_v7_user, combined by
build_lupang_switch.py into one ONNX (parity 0.0); recorded lines 5,6,8,10,11,13,14,15,16,17,19,20,21,22.
User's real 06:23 attempts: original 4 accepted, user-adapted 9, switch 13 (Bayang 2, Alab, Sa dibdib, Lupang hinirang 6,
Duyan 3); 0 wrong in all. Production unchanged (8208f496...), 29 service tests pass.

---
# Addendum 5 (2026-10-12): targeted fixes - Bayang magiliw, Perlas vs Ang kislap, merged line 11 (palm_lupang_v9_switch, STAGED)

Root causes
* Bayang magiliw / Perlas: no user takes. Bayang: right line usually top-1 but low confidence (user's version differs from the
  references). Perlas: the user-adapted model knew the user's Ang kislap (recorded) and the user's Perlas resembles it, so the
  switch passed "Ang kislap" through (session 085620 attempt accepted as Ang kislap).
* Line 11: the data already held the full line - 3 reference clips (cJb, fZh, SRC3) excluded as "two lines", 3 sources split
  it over folders 11/12, the user's 12 takes are the full line (~7 s). The pooled duration floor would have become 5.37 s
  (user-dominated) and blocked every other signer.
Changes
* lupang_common: class 10 = "May dilag ang tula at awit sa paglayang minamahal", class 11 retired (never trained / targeted),
  INVALID stays 22, 23 outputs (no index shift for service / Flutter). MERGED_LINE / RETIRED_CLASSES constants.
* extract_lupang_dataset.merge_split_line (+ test_lupang_recognition.load_captures): same-source halves joined; folder-12
  clips never used alone. audit: full 11+12 clips are valid. Merged line: 18 samples / 7 sources; class 11: 0.
* Merged-line duration floor signer-balanced (2.75 s; other lines unchanged) - user fragments still 0/16 rejected.
* User-adapted model retrained (v9 B) with the merged class + the user's LABELLED tester attempts of Bayang (9) / Perlas (6)
  from session 090256; lines 1, 2 added to the recorded set.
* Original model kept UNCHANGED (v5 ens3) - a retrained original (v9 A) lost the user's Alab ng puso (2/5 -> 0/5); its two
  half-line outputs are folded into class 10 inside the graph; switch now uses the user-adapted model only when it names a
  recorded line AND is at least as confident as the original (build_lupang_switch.py --fold 12:11 --arbitrate).
Results (thresholds 0.65 / 0.65)
* Held-out user sessions (order-inferred, never trained): Bayang 2/11 -> 6/11, Perlas 0/12 -> 3/12, Perlas accepted as
  Ang kislap 1 -> 0, Ang kislap top-1 on Perlas 7 -> 0.
* Labelled other-line attempts (090256, never trained): 30/74 -> 32/74 correct, wrong 4 -> 4 (pre-existing), no line worse.
* Signer-independent (3 unseen reference signers, analog models): correct 24.2 % (original) -> 27.4 %, 0 wrong; negatives
  accepted 1.2 % -> 2.2 % (mostly "two lines in one capture" on other lines); merged-line fragments accepted 0/8.
* User's held-out recorded takes: 94.3 % correct, 0 wrong; merged line 4/4. Merged line for unseen signers 0/2 (top-1 right,
  low confidence: only 5 training sources) - data-limited.
Flutter: proposed manifest reports/lupang_retrain/flutter_labels_lupang_hinirang_MERGED_proposed.json (21 steps, index 10
merged, 11 removed) - apply only together with promotion; NOT applied.

---
# Addendum 6 (2026-10-12): Perlas ng Silanganan low confidence (palm_lupang_v9_switch + Perlas patch, STAGED)

Cause: the user-adapted part had 6 of the user's Perlas attempts vs 16 Ang kislap takes; Perlas probability was spread over
Perlas / Ang kislap / INVALID (top-1 Perlas 0.15-0.69); the original part ranks INVALID first for the user's Perlas.
Tried: (1) whole-head fine-tune: held-out Perlas 2/14 -> 9/14 but other lines 50 -> 43 correct (rejected);
(2) Perlas-row-only fine-tune: 2/14 -> 3/14 (too weak, rejected);
(3) chosen: head fine-tune used ONLY where it ranks Perlas first (class-local patch), everything else unchanged.
Two-fold held-out (fix_perlas.py cv): Perlas 2/14 -> 9/14, 0 wrong; Ang kislap / Lupa ng araw: no false Perlas;
Perlas halves not more accepted; other lines' correct answers unchanged (50/108); +1-2 accepted as Perlas = attempts
043/044 of session 111351 (target Bayang, but movement ~2x closer to the user's Perlas than Bayang; every model gives Bayang 0.01).
Final (all 14 attempts, build_lupang_switch.py --patch models_staging_v9p_B --patch-class 2): service path before -> after:
Perlas attempts 7/19 -> 19/19 (trained on; conf median 0.58 -> 0.91, margin 0.44 -> 0.90, entropy 0.53 -> 0.17);
585 dataset clips: 2 decisions changed (reference Perlas rejected -> correct); other lines 53 correct unchanged, wrong 15 -> 17 (043/044).
Gate / thresholds identical; name kept (tester unchanged); previous staging in models_staging_v9_switch_before_perlas.
