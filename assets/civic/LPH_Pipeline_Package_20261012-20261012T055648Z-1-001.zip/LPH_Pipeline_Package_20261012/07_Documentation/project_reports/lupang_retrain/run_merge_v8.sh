#!/bin/sh
cd /d/model2/fslr-transformer-vs-iv3gru || exit 1
export TMP=D:/tmp_lupang TEMP=D:/tmp_lupang PYTHONUNBUFFERED=1
for ap in A B C; do
  for m in 0 1 2; do
    python merge_lupang_user.py train --approach $ap --member $m > reports/lupang_retrain/merge_${ap}_m$m.log 2>&1 &
  done
done
wait
python merge_lupang_user.py report > reports/lupang_retrain/merge_report.log 2>&1
echo "merge v8 done"
