#!/bin/sh
cd /d/model2/fslr-transformer-vs-iv3gru || exit 1
export TMP=D:/tmp_lupang TEMP=D:/tmp_lupang PYTHONUNBUFFERED=1
run() { python fix_lupang_lines.py "$@" > reports/lupang_retrain/fix_$1_$3_m$5.log 2>&1; }
# 4 at a time (memory was short earlier)
for m in 0 1 2; do run experiment --model A --member $m & done; run experiment --model B --member 0 & wait
for m in 1 2; do run experiment --model B --member $m & done; run final --model A --member 0 & run final --model A --member 1 & wait
run final --model A --member 2 & for m in 0 1 2; do run final --model B --member $m & done; wait
python fix_lupang_lines.py report --all > reports/lupang_retrain/fix_report.log 2>&1
echo "fix v9 done"
