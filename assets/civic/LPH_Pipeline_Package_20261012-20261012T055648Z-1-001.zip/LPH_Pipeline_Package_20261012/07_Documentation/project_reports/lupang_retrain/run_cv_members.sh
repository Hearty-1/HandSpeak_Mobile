#!/bin/sh
cd /d/model2/fslr-transformer-vs-iv3gru || exit 1
export TMP=D:/tmp_lupang TEMP=D:/tmp_lupang PYTHONUNBUFFERED=1
for m in 1 2; do
  for f in 0 1 2 3 4; do
    python retrain_lupang_grouped.py cv --member $m --only-fold $f --threads 1 > reports/lupang_retrain/cv_m${m}_fold$f.log 2>&1 &
  done
done
wait
echo "members done"
