#!/bin/sh
# Runs the 5 outer folds of retrain_lupang_grouped.py in parallel (logs on D:).
cd /d/model2/fslr-transformer-vs-iv3gru || exit 1
export TMP=D:/tmp_lupang TEMP=D:/tmp_lupang PYTHONUNBUFFERED=1
for f in 0 1 2 3 4; do
  python retrain_lupang_grouped.py cv --only-fold $f --threads 1 > reports/lupang_retrain/cv_fold$f.log 2>&1 &
done
wait
echo "cv done"
