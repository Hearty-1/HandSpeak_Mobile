#!/bin/sh
cd /d/model2/fslr-transformer-vs-iv3gru || exit 1
export TMP=D:/tmp_lupang TEMP=D:/tmp_lupang PYTHONUNBUFFERED=1
python retrain_lupang_grouped.py final --seed 1042 --out palm_lupang_v5_m1.pt --threads 4 > reports/lupang_retrain/final_m1.log 2>&1 &
python retrain_lupang_grouped.py final --seed 2042 --out palm_lupang_v5_m2.pt --threads 4 > reports/lupang_retrain/final_m2.log 2>&1 &
wait
echo "final members done"
