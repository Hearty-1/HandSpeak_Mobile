"""Mag-record ng sariling webcam takes para sa Lupang Hinirang dataset.

    python record_lupang_samples.py [--camera 0]

* Lahat ng 22 linya (dati 4 lang). Ang folder ay kinukuha mismo sa dataset
  (specialists/civic_observances/raw/lupang_hinirang/NN_*), kaya hindi na
  nagkakaroon ng maling / ika-23 folder (ang lumang option 3 ay
  "16_Kailan_pa_may_di_magdidilim" - mali, dapat "..._ma_y_...").
* Tamang timing: bawat frame ay may orasan (perf_counter) habang nagre-record;
  ang video ay isinusulat sa AKTUWAL na sukat na fps (dati laging 20.0 kahit
  ano ang tunay na bilis ng camera), at may kasamang <video>.timestamps.json.
* Ang mga file ay "webcam_take_<time>.mp4" (source id "webcam_take"), kaya sa
  signer-independent na pagsusuri ay nasa iisang grupo pa rin ang lahat ng takes.

Pagkatapos mag-record: python extract_lupang_dataset.py --neg-mix v5 --neg-count 160
(re-extract: ang bagong takes lang ang ipoproseso dahil naka-cache ang iba).

SPACE: simulan / itigil   N / P: susunod / naunang linya   Q: lumabas
"""
import argparse
import json
import time
from pathlib import Path

import cv2

BASE_DIR = Path(__file__).resolve().parent / "specialists" / "civic_observances" / "raw" / "lupang_hinirang"


def class_folders():
    folders = sorted(d for d in BASE_DIR.iterdir() if d.is_dir())
    if len(folders) != 22:
        raise SystemExit(f"Inaasahan ang 22 folder sa {BASE_DIR}, nakita {len(folders)}: ayusin muna ang dataset")
    return folders


def save_take(folder, frames, stamps):
    """Write the buffered frames at their measured frame rate + a timestamp sidecar."""
    if len(frames) < 2:
        print("-> Masyadong maikli, hindi naitabi.")
        return
    dur = stamps[-1] - stamps[0]
    fps = (len(frames) - 1) / dur if dur > 0 else 20.0
    h, w = frames[0].shape[:2]
    path = folder / f"webcam_take_{int(time.time())}.mp4"
    out = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    for f in frames:
        out.write(f)
    out.release()
    path.with_suffix(".timestamps.json").write_text(json.dumps(
        {"fps_measured": fps, "t": [round(t - stamps[0], 4) for t in stamps]}), encoding="utf-8")
    print(f"-> Naitabi: {path.name}  ({len(frames)} frames, {dur:.2f}s, {fps:.1f} fps)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--camera", type=int, default=0)
    args = ap.parse_args()
    folders = class_folders()
    for i, f in enumerate(folders):
        n = len([p for p in f.glob("webcam_take_*.mp4")])
        print(f"[{i + 1:2d}] {f.name}  (sariling takes: {n})")
    choice = input("Pumili ng numero (1-22): ").strip()
    if not choice.isdigit() or not 1 <= int(choice) <= 22:
        raise SystemExit("Invalid choice.")
    k = int(choice) - 1

    cap = cv2.VideoCapture(args.camera, cv2.CAP_DSHOW)
    if not cap.isOpened():
        cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        raise SystemExit(f"Hindi mabuksan ang camera {args.camera}")
    recording, frames, stamps = False, [], []
    print("\nSPACE: simulan / itigil   N / P: susunod / naunang linya   Q: lumabas\n")
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            now = time.perf_counter()
            if recording:
                frames.append(frame)
                stamps.append(now)
            disp = frame.copy()
            name = folders[k].name
            if recording:
                cv2.circle(disp, (30, 30), 12, (0, 0, 255), -1)
                cv2.putText(disp, f"RECORDING: {name}  {now - stamps[0]:.1f}s", (50, 35),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
            else:
                cv2.putText(disp, f"STANDBY: {name}", (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                cv2.putText(disp, "SPACE record  N/P line  Q quit", (20, 58), cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                            (0, 255, 0), 1)
            cv2.imshow("Record FSL Clips", disp)
            key = cv2.waitKey(1) & 0xFF
            if key == 32:
                if not recording:
                    frames, stamps, recording = [], [], True
                    print(f"-> Nagsimula mag-record: {name}")
                else:
                    recording = False
                    save_take(folders[k], frames, stamps)
            elif not recording and key in (ord("n"), ord("N")):
                k = (k + 1) % 22
            elif not recording and key in (ord("p"), ord("P")):
                k = (k - 1) % 22
            elif key in (ord("q"), ord("Q"), 27):
                break
    finally:
        if recording:
            save_take(folders[k], frames, stamps)
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
