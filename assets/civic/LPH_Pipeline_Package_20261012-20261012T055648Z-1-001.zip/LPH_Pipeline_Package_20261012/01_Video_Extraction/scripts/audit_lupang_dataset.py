"""Audit the Lupang Hinirang source clips and their extracted landmarks.

    python audit_lupang_dataset.py [--cache lupang_landmarks_cache.pkl] [--json audit.json]

For every clip under lupang_common.RAW_DIR this checks, without modifying
anything:

  file      decodable by OpenCV, frame count, fps, size, SHA-256 (exact duplicates)
  label     the phrase in the file name matches its class folder; clips whose
            name continues into the NEXT line (e.g. "May dilag ... sa paglayang
            minamahal" filed under line 11) contain two lines and are flagged
  landmarks (from the cache) frames == decoded frames, timestamps strictly
            increasing, pose / hand coverage of the active segment, upright
            (nose above the shoulders) and unmirrored (signer's left shoulder,
            MediaPipe 11, on the image right) camera view, active duration,
            clean_sequence() succeeds
  near-dup  pairs of clips whose (32, 181) feature sequences are nearly
            identical (same recording filed twice)

A clip is VALID only if every check passes. The validity rules are
VALIDITY below; the extraction script uses the same function (clip_issues)
to exclude invalid clips from the training set.
"""
import argparse
import hashlib
import json
import pickle
import re
from pathlib import Path

import numpy as np

import lupang_common as lc

VALIDITY = dict(
    min_pose_coverage=lc.LUPANG_RELIABILITY["min_pose_coverage"],   # same floor as the live gate
    min_hand_coverage=lc.LUPANG_RELIABILITY["min_hand_coverage"],
    min_upright=0.90,          # share of pose frames with the nose above the shoulder line
    min_unmirrored=0.90,       # share of pose frames with x(L shoulder) > x(R shoulder)
    min_active_s=lc.GATE_DEFAULTS["min_duration_s"],
    near_dup_dist=0.02,        # mean |feature diff| (standardised) below this = same recording
)


def _norm(s):
    return re.sub(r"[^a-z]", "", s.lower())


def phrase_from_filename(path):
    """'SRC2_LUPANGHINIRANG__Di_ka_pasisiil_001.mp4' -> 'dikapasisiil'
    ('4X8GdF4u9so_Bayang_magiliw_001.mp4' -> 'bayangmagiliw'); None for
    names without a phrase (webcam_take_*)."""
    stem = Path(path).stem
    if stem.startswith("webcam_take"):
        return None
    stem = re.sub(r"_\d+$", "", stem)
    m = re.match(r"^SRC\d+_LUPANGHINIRANG_+(.*)$", stem)
    body = m.group(1) if m else stem[12:]          # YouTube id (11 chars) + "_"
    return _norm(body)


def folder_phrase(folder):
    return _norm(folder.split("_", 1)[1])


def label_issue(path, folder, next_folder):
    """(issue, warning). issue: the clip is not a sample of this line (it
    continues into the next line, or names a different phrase). warning:
    spelling variant of the same line ('nang dahil sa iyo' for 'sayo',
    'Sa simoy at sa langit mong bughaw' = the full lyric of line 10)."""
    from difflib import SequenceMatcher
    phrase = phrase_from_filename(path)
    if phrase is None:
        return None, None
    want = folder_phrase(folder)
    if phrase == want:
        return None, None
    if next_folder:
        nxt = folder_phrase(next_folder)
        k = phrase.find(nxt[:8])
        if k > 0 and SequenceMatcher(None, phrase[:k], want).ratio() >= 0.8 \
                and SequenceMatcher(None, phrase[k:], nxt).ratio() >= 0.8:
            if int(folder.split("_", 1)[0]) - 1 == lc.MERGED_LINE:
                # 'May dilag ... sa paglayang minamahal' IS the merged line 11 (lupang_common.MERGED_LINE)
                return None, f"full merged line ({folder} + {next_folder})"
            return f"contains two lines ({folder} + {next_folder})", None
    if SequenceMatcher(None, phrase[:len(want) + 2], want).ratio() >= 0.75:
        return None, f"spelling variant {phrase!r} of {want!r}"
    return f"file name phrase {phrase!r} does not match folder {folder}", None


def video_info(path):
    import cv2
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        return {"ok": False}
    info = {"ok": True, "fps": float(cap.get(cv2.CAP_PROP_FPS) or 0.0),
            "frames_meta": int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0),
            "width": int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), "height": int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))}
    try:
        info["rotation_meta"] = int(cap.get(cv2.CAP_PROP_ORIENTATION_META))
    except Exception:
        info["rotation_meta"] = None
    cap.release()
    return info


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def landmark_checks(raw, ts):
    """Geometry / timing / coverage of one extracted clip (raw (N, RAW_DIM))."""
    out = {"frames": int(len(raw))}
    ts = np.asarray(ts, dtype=np.float64)
    out["ts_monotonic"] = bool(len(ts) < 2 or np.all(np.diff(ts) > 0))
    out["ts_span_s"] = float(ts[-1] - ts[0]) if len(ts) > 1 else 0.0
    pose_ok = raw[:, lc.RAW_FLAG_POSE] > 0.5
    if pose_ok.any():
        p = raw[pose_ok][:, lc.RAW_POSE].reshape(-1, 7, 2)
        mid_y = (p[:, lc.P_LSH, 1] + p[:, lc.P_RSH, 1]) / 2
        out["upright"] = float(np.mean(p[:, lc.P_NOSE, 1] < mid_y))
        out["unmirrored"] = float(np.mean(p[:, lc.P_LSH, 0] > p[:, lc.P_RSH, 0]))
        out["shoulder_span"] = float(np.median(np.linalg.norm(p[:, lc.P_LSH] - p[:, lc.P_RSH], axis=1)))
    else:
        out.update(upright=0.0, unmirrored=0.0, shoulder_span=0.0)
    stats = {}
    seq, info = lc.build_sequence_with_info(raw, ts)
    q = info.get("repairs") or {}
    out["clean_ok"] = seq is not None
    out["active_s"] = float(info.get("duration_s", 0.0))
    out["active_frames"] = int(info.get("active_frames", 0))
    out["pose_coverage"] = float(q.get("pose_coverage", 0.0))
    out["hand_coverage"] = float(q.get("hand_coverage", 0.0))
    out["out_of_frame"] = float(q.get("out_of_frame", 0.0))
    out["finite"] = bool(seq is None or np.isfinite(seq).all())
    return out, seq


def clip_issues(rec):
    """List of reasons a clip is not a valid training sample (empty = valid)."""
    v = VALIDITY
    issues = []
    if not rec.get("decodable", True):
        return ["video cannot be decoded"]
    if rec.get("label_issue"):
        issues.append(rec["label_issue"])
    if rec.get("duplicate_of"):
        issues.append(f"exact duplicate of {rec['duplicate_of']}")
    lm = rec.get("landmarks")
    if lm is None:
        issues.append("no landmarks extracted")
        return issues
    lc_counts = rec.get("landmark_counts")
    if lc_counts:
        for key, n in (("pose", 33), ("lh", 21), ("rh", 21)):
            if lc_counts[f"{key}_{n}"] != lc_counts[f"{key}_detected"]:
                issues.append(f"{key}: {lc_counts[f'{key}_detected'] - lc_counts[f'{key}_{n}']} frames "
                              f"without exactly {n} landmarks")
    if not lm["ts_monotonic"]:
        issues.append("timestamps not strictly increasing")
    if not lm["clean_ok"]:
        issues.append("no usable hand signal")
        return issues
    if not lm["finite"]:
        issues.append("non-finite features")
    if lm["pose_coverage"] < v["min_pose_coverage"]:
        issues.append(f"pose tracked in {lm['pose_coverage']:.0%} of active frames (< {v['min_pose_coverage']:.0%})")
    if lm["hand_coverage"] < v["min_hand_coverage"]:
        issues.append(f"hands tracked in {lm['hand_coverage']:.0%} of active frames (< {v['min_hand_coverage']:.0%})")
    if lm["upright"] < v["min_upright"]:
        issues.append(f"not upright ({lm['upright']:.0%} of frames)")
    if lm["unmirrored"] < v["min_unmirrored"]:
        issues.append(f"mirrored view ({lm['unmirrored']:.0%} of frames unmirrored)")
    if lm["active_s"] < v["min_active_s"]:
        issues.append(f"active segment {lm['active_s']:.2f}s < {v['min_active_s']:.2f}s")
    if rec.get("near_duplicate_of"):
        issues.append(f"near-duplicate of {rec['near_duplicate_of']}")
    return issues


def audit(cache_path, decode=True, verbose=True):
    from extract_lupang_dataset import list_videos
    folders, items = list_videos(lc.RAW_DIR)
    names = [f.name for f in folders]
    cache = {}
    if cache_path and Path(cache_path).exists():
        with open(cache_path, "rb") as f:
            cache = pickle.load(f)
    recs, seqs, hashes = [], {}, {}
    for path, label in items:
        folder = names[label]
        rec = {"path": path, "file": Path(path).name, "label": label, "folder": folder,
               "source": lc.source_id(path)}
        rec["label_issue"], rec["label_warning"] = label_issue(
            path, folder, names[label + 1] if label + 1 < len(names) else None)
        h = sha256(path)
        rec["sha256"] = h
        if h in hashes:
            rec["duplicate_of"] = hashes[h]
        else:
            hashes[h] = rec["file"]
        if decode:
            vi = video_info(path)
            rec["decodable"] = vi["ok"]
            rec["video"] = vi
        e = cache.get(path)
        if e is not None:
            rec["frames_decoded"] = e.get("frames_decoded")
            rec["ts_source"] = e.get("ts_source", "index/fps")
            rec["landmark_counts"] = e.get("landmark_counts")
            lm, seq = landmark_checks(e["raw"], e["ts"])
            rec["landmarks"] = lm
            meta_frames = (rec.get("video") or {}).get("frames_meta")
            if meta_frames and meta_frames != lm["frames"]:   # container counts are approximate for VFR
                rec["frame_count_warning"] = f"{lm['frames']} frames decoded, container says {meta_frames}"
            if seq is not None:
                seqs[len(recs)] = seq
        recs.append(rec)

    # Near-duplicates: standardised feature sequences almost identical.
    idx = sorted(seqs)
    if len(idx) > 1:
        X = np.stack([seqs[i] for i in idx]).reshape(len(idx), -1)
        sd = np.maximum(X.std(0), 1e-3)
        Z = X / sd
        for a in range(len(idx)):
            d = np.abs(Z[a + 1:] - Z[a]).mean(axis=1)
            for b in np.flatnonzero(d < VALIDITY["near_dup_dist"]):
                j = idx[a + 1 + b]
                if not recs[j].get("near_duplicate_of"):
                    recs[j]["near_duplicate_of"] = recs[idx[a]]["file"]
    for r in recs:
        r["issues"] = clip_issues(r)
        r["valid"] = not r["issues"]
    return names, recs


def summarize(names, recs):
    rows = []
    for c, name in enumerate(names):
        rs = [r for r in recs if r["label"] == c]
        rows.append({"index": c, "folder": name, "files": len(rs),
                     "valid": sum(r["valid"] for r in rs),
                     "invalid": sum(not r["valid"] for r in rs),
                     "duplicates": sum(bool(r.get("duplicate_of") or r.get("near_duplicate_of")) for r in rs),
                     "sources": len({r["source"] for r in rs if r["valid"]})})
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--cache", default="lupang_landmarks_cache.pkl")
    ap.add_argument("--json", help="write the full per-clip audit here")
    ap.add_argument("--no-decode", action="store_true", help="skip opening the videos")
    args = ap.parse_args()
    names, recs = audit(args.cache, decode=not args.no_decode)
    rows = summarize(names, recs)
    print(f"{'idx':>3} {'line':<42} files valid invalid dup sources")
    for r in rows:
        print(f"{r['index']:3d} {r['folder']:<42} {r['files']:5d} {r['valid']:5d} {r['invalid']:7d} "
              f"{r['duplicates']:3d} {r['sources']:7d}")
    print(f"TOTAL {sum(r['files'] for r in rows)} files, {sum(r['valid'] for r in rows)} valid")
    print("\nInvalid clips:")
    for r in recs:
        if not r["valid"]:
            print(f"  [{r['label']:02d}] {r['file']}: " + "; ".join(r["issues"]))
    if args.json:
        Path(args.json).write_text(json.dumps({"validity": VALIDITY, "lines": rows, "clips": recs},
                                              indent=2, default=str), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
