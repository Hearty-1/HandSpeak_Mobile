﻿import os
import glob
from pathlib import Path
import cv2
import numpy as np
import mediapipe as mp
from scipy.interpolate import interp1d

RAW_DIR = Path("specialists/civic_observances/raw/lupang_hinirang")
if not RAW_DIR.exists():
    print(f"ERROR: Hindi mahanap ang {RAW_DIR}")
    exit(1)

FOLDERS = sorted([d for d in RAW_DIR.iterdir() if d.is_dir()])
print(f"Natagpuang {len(FOLDERS)} raw video folders ng Lupang Hinirang.")

mp_holistic = mp.solutions.holistic
holistic = mp_holistic.Holistic(
    static_image_mode=False,
    model_complexity=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

def resample_temporal(seq, target_len=32):
    arr = np.array(seq, dtype=np.float32)
    cur_len = len(arr)
    if cur_len == target_len:
        return arr
    x_old = np.linspace(0, 1, cur_len)
    x_new = np.linspace(0, 1, target_len)
    f = interp1d(x_old, arr, axis=0, kind='linear')
    return f(x_new).astype(np.float32)

def extract_features_from_video(video_path):
    cap = cv2.VideoCapture(str(video_path))
    raw_frames = []

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        res = holistic.process(rgb)

        # 1. Pose Torso Center & Scale Normalization
        if res.pose_landmarks:
            plm = res.pose_landmarks.landmark
            nose = np.array([plm[0].x, plm[0].y, plm[0].z], dtype=np.float32)
            l_sh = np.array([plm[11].x, plm[11].y, plm[11].z], dtype=np.float32)
            r_sh = np.array([plm[12].x, plm[12].y, plm[12].z], dtype=np.float32)
            chest = (l_sh + r_sh) / 2.0
            torso_scale = np.linalg.norm(l_sh - r_sh) + 1e-6
        else:
            nose = np.array([0.5, 0.2, 0.0], dtype=np.float32)
            chest = np.array([0.5, 0.5, 0.0], dtype=np.float32)
            l_sh = np.array([0.6, 0.4, 0.0], dtype=np.float32)
            r_sh = np.array([0.4, 0.4, 0.0], dtype=np.float32)
            torso_scale = 0.25

        # 2. Left Hand Processing
        if res.left_hand_landmarks:
            lh = np.array([[p.x, p.y, p.z] for p in res.left_hand_landmarks.landmark], dtype=np.float32)
            lh_wrist = lh[0]
            lh_scale = np.linalg.norm(lh[9] - lh_wrist) + 1e-6
            lh_rel = ((lh - lh_wrist) / lh_scale)[:, :2].flatten() # 42
        else:
            lh_wrist = chest.copy()
            lh_scale = 0.05
            lh_rel = np.zeros(42, dtype=np.float32)

        # 3. Right Hand Processing
        if res.right_hand_landmarks:
            rh = np.array([[p.x, p.y, p.z] for p in res.right_hand_landmarks.landmark], dtype=np.float32)
            rh_wrist = rh[0]
            rh_scale = np.linalg.norm(rh[9] - rh_wrist) + 1e-6
            rh_rel = ((rh - rh_wrist) / rh_scale)[:, :2].flatten() # 42
        else:
            rh_wrist = chest.copy()
            rh_scale = 0.05
            rh_rel = np.zeros(42, dtype=np.float32)

        # 4. Invariant Kinematics & Body Spatial Metrics (Torso-Normalized)
        spatial = []
        spatial.extend((lh_wrist - chest) / torso_scale) # 3
        spatial.extend((rh_wrist - chest) / torso_scale) # 3
        spatial.extend((lh_wrist - nose) / torso_scale)  # 3
        spatial.extend((rh_wrist - nose) / torso_scale)  # 3
        spatial.extend((lh_wrist - l_sh) / torso_scale)  # 3
        spatial.extend((rh_wrist - r_sh) / torso_scale)  # 3
        spatial.extend((rh_wrist - lh_wrist) / torso_scale) # 3
        spatial.append(lh_scale / torso_scale) # 1
        spatial.append(rh_scale / torso_scale) # 1

        # Frame Vector: 42 (LH) + 42 (RH) + 23 (Spatial) = 107
        frame_vec = np.concatenate([lh_rel, rh_rel, np.array(spatial, dtype=np.float32)])
        raw_frames.append(frame_vec)

    cap.release()
    if len(raw_frames) < 8:
        return None

    # Resample sa 32 frames
    seq32 = resample_temporal(raw_frames, 32) # (32, 107)

    # 5. Idagdag ang Velocity First Derivative (d/dt) para sa buong sequence
    velocity = np.zeros_like(seq32)
    velocity[1:] = seq32[1:] - seq32[:-1]
    
    # Kumuha ng 21 key temporal velocities (pulso at kamay motion)
    v_features = velocity[:, 84:105] # (32, 21)

    # Final feature vector: 107 + 21 = 128 mathematically normalized dimensions
    final_seq = np.concatenate([seq32, v_features], axis=-1)
    return final_seq.astype(np.float32)

X_all, y_all = [], []

for cls_idx, folder in enumerate(FOLDERS):
    v_files = list(folder.glob("*.mp4")) + list(folder.glob("*.avi")) + list(folder.glob("*.mov"))
    print(f"[{cls_idx:02d}] {folder.name}: {len(v_files)} videos...")
    for vf in v_files:
        feats = extract_features_from_video(vf)
        if feats is not None:
            X_all.append(feats)
            y_all.append(cls_idx)

# Synthetic INVALID_GESTURE (Class 22)
print("Bumubuo ng 40 dynamic synthetic invalid samples...")
for _ in range(40):
    noise = np.random.normal(0.0, 0.08, size=(32, 128)).astype(np.float32)
    X_all.append(noise)
    y_all.append(len(FOLDERS))

X = np.array(X_all, dtype=np.float32)
y = np.array(y_all, dtype=np.int64)

np.save("X_lupang_fresh128.npy", X)
np.save("y_lupang_fresh128.npy", y)

print(f"\nMatagumpay na natapos ang fresh video extraction!")
print(f"X shape: {X.shape}, y shape: {y.shape}")
holistic.close()
