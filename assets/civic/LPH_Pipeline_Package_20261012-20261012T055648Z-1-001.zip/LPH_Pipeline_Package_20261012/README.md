# Lupang Hinirang (LPH) pipeline package — 2026-10-12

Copies (not moves) of every file used to build, serve and test the Lupang Hinirang gesture recognizer, from the
extracted source videos to the staged model, the inference API, the webcam tester and the Flutter app files.
Originals are untouched. Every copy was verified by SHA-256 against its original (`MANIFEST.csv`, column `copy_verified`).

| File | Content |
|---|---|
| `MANIFEST.csv` | one row per copied file: stage, package path, **original path**, size, modified time, SHA-256, purpose, dependencies / used by, status |
| `INVENTORY.md` | the same, readable, grouped by stage |
| `PIPELINE_TRACE.md` | stage-by-stage trace, dependency map, webcam-to-prediction flow |
| `GCP_STATUS.md` | what is deployed on Cloud Run (verified 2026-10-12) |
| `FLUTTER_INTEGRATION_REQUIREMENTS.md` | what the mobile app needs to use the staged model |
| `MISSING_AND_UNVERIFIED.md` | missing files, unverifiable history, known inconsistencies |
| `EXCLUDED_FILES.csv` | large experiment artefacts not copied (4.88 GB) with original paths |

Status values: CURRENT = on the path of the staged model / working webcam; CURRENT COMPONENT = inside the staged ONNX;
PRODUCTION FOLDER / PREVIOUS PRODUCTION / PRODUCTION LEGACY = deployment-related; SUPERSEDED / LEGACY = history;
EVIDENCE / EVALUATION = reports, logs, analysis; READY-MADE, NOT INTEGRATED / PROPOSED = Flutter files not yet in the app.

| Folder | Stage |
|---|---|
| `01_Video_Extraction` | source videos (327 reference + 266 user takes, 22 line folders, original sub-structure), recorder and extraction scripts |
| `02_Datasets` | landmark cache, validity manifest, feature dataset, label manifests, legacy datasets, v4 dataset backup |
| `03_Training` | pipeline core (`lupang_common.py` …), model-building scripts, evaluation tools, `cv_runs` results, legacy training |
| `04_Models` | staged model, component ONNX exports, checkpoints (current / superseded / legacy), previous production, build tools |
| `05_Inference_API` | inference-service app + Docker/Cloud Build config + tests, local staging server, webcam tester |
| `06_Flutter_Integration` | current app files (HandSpeak_Mobile-rules-compat), ready-made raw-endpoint client, proposed manifest |
| `07_Documentation` | project reports and logs, read-only audit of 2026-10-12, checksums |
| `08_Webcam_Test_Sessions` | saved webcam tester attempts (landmarks + target + server response), session CSVs |

Scope: Lupang Hinirang only. Shared components are included where the LPH path needs them (FastAPI app, `lupang_common.py`
— also imported by the Calendar specialist, `live_lupang_engine.open_camera`). Other specialists (Calendar, letters,
greetings, Panata, Panunumpa, numbers) are excluded.
