﻿import os
import glob
from pathlib import Path
import numpy as np

DATA_DIR = Path("specialists/civic_observances/landmarks_lupang_hinirang")
FOLDERS = sorted([d.name for d in DATA_DIR.iterdir() if d.is_dir()])

print(f"Natagpuang mga klase ({len(FOLDERS)}):")
for idx, name in enumerate(FOLDERS):
    print(f"  [{idx:02d}] {name}")

def extract_palm_relative_from_68(sample_68):
    """
    sample_68 shape: (32, 68, 3)
    Indices:
      Pose: 0 hanggang 25 (26 points)
      Left Hand: 26 hanggang 46 (21 points)
      Right Hand: 47 hanggang 67 (21 points)
    Kinukuha ang 96-dim palm-relative feature vector bawat frame (32, 96).
    """
    T = sample_68.shape[0]
    out_seq = []

    for t in range(T):
        frame = sample_68[t]
        lh = frame[26:47] # (21, 3)
        rh = frame[47:68] # (21, 3)

        features = []
        # Left Hand normalization
        lh_wrist = lh[0]
        lh_mcp = lh[9]
        lh_scale = np.linalg.norm(lh_mcp - lh_wrist) + 1e-6
        lh_rel = (lh - lh_wrist) / lh_scale
        features.extend(lh_rel.flatten()[:42]) # x, y para sa 21 points = 42

        # Right Hand normalization
        rh_wrist = rh[0]
        rh_mcp = rh[9]
        rh_scale = np.linalg.norm(rh_mcp - rh_wrist) + 1e-6
        rh_rel = (rh - rh_wrist) / rh_scale
        features.extend(rh_rel.flatten()[:42]) # x, y para sa 21 points = 42

        # Wrist-to-wrist and spatial relative distances (12 features = kabuuang 96)
        dist_wrists = (rh_wrist - lh_wrist) / (rh_scale + lh_scale)
        features.extend(dist_wrists) # 3
        features.extend(lh_wrist[:2]) # 2
        features.extend(rh_wrist[:2]) # 2
        features.append(lh_scale)     # 1
        features.append(rh_scale)     # 1
        features.extend([0.0, 0.0, 0.0]) # padding hanggang 96

        out_seq.append(features[:96])

    return np.array(out_seq, dtype=np.float32)

X_list, y_list = [], []

for cls_idx, folder_name in enumerate(FOLDERS):
    files = list((DATA_DIR / folder_name).glob("*.npy"))
    print(f"Pinoproseso [{cls_idx:02d}] {folder_name} ({len(files)} files)...")
    for f in files:
        raw_data = np.load(f)
        if raw_data.shape == (32, 68, 3):
            feat = extract_palm_relative_from_68(raw_data)
            X_list.append(feat)
            y_list.append(cls_idx)

# Pagbuo ng synthetic INVALID_GESTURE (Class 22)
num_invalid = 35
print(f"Bumubuo ng {num_invalid} synthetic samples para sa INVALID_GESTURE (Class {len(FOLDERS)})...")
for _ in range(num_invalid):
    noise_sample = np.random.normal(0.0, 0.05, size=(32, 96)).astype(np.float32)
    X_list.append(noise_sample)
    y_list.append(len(FOLDERS))

X = np.array(X_list, dtype=np.float32)
y = np.array(y_list, dtype=np.int64)

np.save("X_palm_lupang.npy", X)
np.save("y_palm_lupang.npy", y)

print("\nTapos na!")
print(f"X shape: {X.shape}, y shape: {y.shape}")
