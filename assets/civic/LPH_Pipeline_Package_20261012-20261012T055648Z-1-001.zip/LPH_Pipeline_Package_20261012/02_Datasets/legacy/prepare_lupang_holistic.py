﻿import os
import glob
from pathlib import Path
import numpy as np

DATA_DIR = Path("specialists/civic_observances/landmarks_lupang_hinirang")
FOLDERS = sorted([d.name for d in DATA_DIR.iterdir() if d.is_dir()])

print(f"Natagpuang mga klase ({len(FOLDERS)}):")
for idx, name in enumerate(FOLDERS):
    print(f"  [{idx:02d}] {name}")

def extract_holistic_features_from_68(sample_68):
    """
    sample_68 shape: (32, 68, 3)
    Pose: 0..25 (Nose=0, Left Shoulder=11, Right Shoulder=12)
    Left Hand: 26..46
    Right Hand: 47..67
    Total extracted features per frame: 128
    """
    T = sample_68.shape[0]
    out_seq = []

    for t in range(T):
        frame = sample_68[t]
        pose = frame[0:26]
        lh = frame[26:47]
        rh = frame[47:68]

        # 1. Pose Anchors (Chest & Face reference)
        nose = pose[0]
        l_shldr = pose[11]
        r_shldr = pose[12]
        chest = (l_shldr + r_shldr) / 2.0
        torso_scale = np.linalg.norm(l_shldr - r_shldr) + 1e-6

        features = []

        # 2. Left Hand Normalization (42 values)
        lh_wrist = lh[0]
        lh_mcp = lh[9]
        lh_scale = np.linalg.norm(lh_mcp - lh_wrist) + 1e-6
        lh_rel = (lh - lh_wrist) / lh_scale
        features.extend(lh_rel.flatten()[:42])

        # 3. Right Hand Normalization (42 values)
        rh_wrist = rh[0]
        rh_mcp = rh[9]
        rh_scale = np.linalg.norm(rh_mcp - rh_wrist) + 1e-6
        rh_rel = (rh - rh_wrist) / rh_scale
        features.extend(rh_rel.flatten()[:42])

        # 4. Face & Pose Spatial Connections (Hand-to-Body Anchors)
        # Distansya papunta sa Dibdib (Chest)
        lh_to_chest = (lh_wrist - chest) / torso_scale
        rh_to_chest = (rh_wrist - chest) / torso_scale
        features.extend(lh_to_chest) # 3
        features.extend(rh_to_chest) # 3

        # Distansya papunta sa Ilong / Mukha (Face Anchor)
        lh_to_face = (lh_wrist - nose) / torso_scale
        rh_to_face = (rh_wrist - nose) / torso_scale
        features.extend(lh_to_face)  # 3
        features.extend(rh_to_face)  # 3

        # Distansya papunta sa Balikat
        lh_to_shldr = (lh_wrist - l_shldr) / torso_scale
        rh_to_shldr = (rh_wrist - r_shldr) / torso_scale
        features.extend(lh_to_shldr) # 3
        features.extend(rh_to_shldr) # 3

        # Distansya ng dalawang pulso sa isa't isa
        wrist_dist = (rh_wrist - lh_wrist) / torso_scale
        features.extend(wrist_dist)  # 3

        # Orientation & Relative Heights
        features.append((lh_wrist[1] - chest[1]) / torso_scale) # Kaliwang kamay taas/baba sa dibdib
        features.append((rh_wrist[1] - chest[1]) / torso_scale) # Kanang kamay taas/baba sa dibdib
        features.append(lh_scale / torso_scale)
        features.append(rh_scale / torso_scale)

        # Padding para eksaktong 128 dimensions
        needed = 128 - len(features)
        if needed > 0:
            features.extend([0.0] * needed)

        out_seq.append(features[:128])

    return np.array(out_seq, dtype=np.float32)

X_list, y_list = [], []

for cls_idx, folder_name in enumerate(FOLDERS):
    files = list((DATA_DIR / folder_name).glob("*.npy"))
    print(f"Pinoproseso [{cls_idx:02d}] {folder_name} ({len(files)} files)...")
    for f in files:
        raw_data = np.load(f)
        if raw_data.shape == (32, 68, 3):
            feat = extract_holistic_features_from_68(raw_data)
            X_list.append(feat)
            y_list.append(cls_idx)

# Synthetic INVALID_GESTURE (Class 22)
num_invalid = 35
print(f"Bumubuo ng {num_invalid} samples para sa INVALID_GESTURE...")
for _ in range(num_invalid):
    noise_sample = np.random.normal(0.0, 0.05, size=(32, 128)).astype(np.float32)
    X_list.append(noise_sample)
    y_list.append(len(FOLDERS))

X = np.array(X_list, dtype=np.float32)
y = np.array(y_list, dtype=np.int64)

np.save("X_holistic_lupang.npy", X)
np.save("y_holistic_lupang.npy", y)

print("\nTapos na!")
print(f"X shape: {X.shape} (N, 32 frames, 128 holistic features), y shape: {y.shape}")
