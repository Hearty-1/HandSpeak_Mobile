# LPH pipeline trace (earliest available artefact → staged model → webcam)

Evidence: file timestamps and contents, model metadata JSON, logs in `07_Documentation`, code. Git holds no LPH history.
[V] verified · [I] inferred · [U] unknown.

## 1. Stages

| # | Stage | Input files | Script / function | Output files (package path) | Status |
|---|---|---|---|---|---|
| 0 | Source archive | Google-Drive export `D:\lupang hinirang-20260928T002750Z-1-001` — folder **empty** | manual extraction [I] | `01_Video_Extraction/source_videos/lupang_hinirang/NN_*/` 327 reference clips, all mtime 2026-09-28 08:28 [V] | archive missing [U] |
| 0b | User takes | webcam | `record_lupang_samples.py` (`save_take`) — original 4-line version in `scripts/original_versions` | `webcam_take_*.mp4` (36 on 10-04, 230 + `.timestamps.json` on 10-11) [V] | current |
| L | Legacy pipeline (09-28 … 10-03) | videos | `extract_lupang_hinirang.py`, `train_lupang_hinirang.py`, `prepare_lupang_*`, `train_lupang_*` | `02_Datasets/legacy`, `04_Models/legacy_818_feature_model`, `checkpoints/legacy` | legacy; the 818-feature ONNX is still what the Flutter app uses |
| 1 | Landmark extraction | videos | `extract_lupang_dataset.extract_all` → `lupang_common.extract_raw_from_video(with_meta=True)` (MediaPipe Holistic, `HOLISTIC_KWARGS`, decoder timestamps) | `02_Datasets/landmark_cache/lupang_landmarks_cache.pkl` (10-11 02:59) [V] | current |
| 2 | Clip validation | cache, videos | `audit_lupang_dataset.audit` / `clip_issues` | `lupang_dataset_manifest.json` (5 invalid of 593) [V] | current |
| 3 | Capture list + labels | cache, folders, manifest | `test_lupang_recognition.load_captures` + `extract_lupang_dataset.merge_split_line` | in-memory: 585 captures, labels = folder index, line 11 merged (18 samples / 7 sources), class 11 retired [V] | current |
| 3b | Feature dataset file | same | `extract_lupang_dataset.main` | `02_Datasets/feature_dataset/X/y/groups/kind/dur_raw_lupang.npy`, `lupang_meta.json` (y/meta later relabelled, see MISSING_AND_UNVERIFIED) | not used by the staged model's training [V] |
| 4 | Features + negatives | captures | `cv_lupang.build_training_set` → `make_clip` (`lc.clean_sequence`, `static_features`, `resample`, `add_velocity` → 32×181), `make_negatives` | tensors (in memory) | current |
| 5a | Original component | captures of 2026-10-10 | `retrain_lupang_grouped` (final + ensemble members) | `palm_lupang_v5_m1/m2.pt` (+ member 0 only inside ONNX) → `onnx_exports/models_staging_v5_ens3` | inside staged model |
| 5b | User component | captures + 13 labelled tester attempts (Bayang / Perlas, session 090256) | `fix_lupang_lines.cmd_final` → `inner_split`, `train_one`, `train_lupang_model.train_model` | `palm_lupang_v9_B_m0..2.pt`, `cv_runs/fix_v9/final_gate_B.json` → `onnx_exports/models_staging_v9_B` | inside staged model |
| 5c | Perlas patch | v9 B + 14 Perlas attempts (session 111351) | `fix_perlas.finetune` (output head only) | `palm_lupang_v9p_B_m0..2.pt` → `onnx_exports/models_staging_v9p_B` | inside staged model |
| 6 | Export | checkpoints + gate JSON | `export_lupang_onnx.main` (`MeanProbEnsemble`, onnx in `D:\venv_lupang_export`) | component `fsl_lupang_hinirang_v4.onnx` + `lupang_hinirang_v4.json` | current tool |
| 7 | Compose / stage | 3 component folders | `build_lupang_switch.build` (`--fold 12:11 --arbitrate --patch models_staging_v9p_B --patch-class 2`) | `04_Models/current_staged/` (sha256 `763478f3…`, `f0154e5c…`, 2026-10-12 11:56) | **current staged** |
| 8 | Production folder + deploy | staged files copied into `inference-service/models/` (by the user, backup in `previous_production_v4`) | `gcloud run deploy --source . --no-traffic --tag lupang-v9` [I from files + Cloud Run] | Cloud Run revision `handspeak-inference-00016-yeb`, tag `lupang-v9`, **0 % traffic** [V] | see GCP_STATUS.md |
| 9 | Local serving | staged folder | `local_staging_server.main` → `app.main` | API on 127.0.0.1:8765 | current |
| 10 | Webcam | camera | `webcam_test_staging.run_live` | display, `08_Webcam_Test_Sessions` | current |

Superseded intermediate models (history, not on the current path): v5 single (10-10), v7 user (10-11), v8 switch (10-12 08:42),
v9 A (10-12), v9 switch before the Perlas patch (10-12 10:32).

## 2. Dependency map

```
Drive export (missing) ──► 01 source_videos (327 reference) ─┐
record_lupang_samples.py ──► webcam takes (266) ─────────────┤
                                                             ▼
          extract_lupang_dataset.extract_all (lupang_common, MediaPipe Holistic)
                                                             ▼
          lupang_landmarks_cache.pkl ──► audit_lupang_dataset ──► lupang_dataset_manifest.json
                                                             ▼
          test_lupang_recognition.load_captures + merge_split_line  (labels = folders; line 11 merged)
                                                             ▼
          cv_lupang.build_training_set ──► train_lupang_model.train_model (via retrain_lupang_grouped / fix_lupang_lines / fix_perlas)
             │                     │                          │
       v5 ensemble (original)  v9 B (user part)        v9p B (Perlas patch)
             └──── export_lupang_onnx ────┴────────────────────┘
                                ▼
          build_lupang_switch ──► STAGED fsl_lupang_hinirang_v4.onnx + lupang_hinirang_v4.json
                                ▼                                   ▼
          local_staging_server ─► app.main ─► app.lupang_raw.RawSpecialistModel ─► app.lupang_common.evaluate_capture
                                ▲                                   ▲
          webcam_test_staging (HTTP POST /v1/predict_raw/lupang_hinirang)      Cloud Run revision 00016 'lupang-v9' (0 % traffic)
```

## 3. Webcam → prediction (current, code-verified)

1. `webcam_test_staging.main` → `StagingClient` checks `GET /local/staging_info` (must be `palm_lupang_v9_switch`, not production).
2. `run_live`: camera via `live_lupang_engine.open_camera` (DSHOW) or MSMF (`--backend msmf`); per frame `lc.prepare_frame` (unflipped)
   → MediaPipe `Holistic(**lc.HOLISTIC_KWARGS)` → `frame_dict` (pose 33×[x, y, visibility], hands 21×[x, y, z], `perf_counter` time).
3. SPACE … SPACE → `StagingClient.predict` → `POST /v1/predict_raw/lupang_hinirang`.
4. `app.main.predict_raw` (validation `RawPredictRequest`) → `RawSpecialistModel.predict` → `to_raw` (`lc.raw_from_arrays`) → `lc.evaluate_capture`:
   cleaning + features (32×181) → pre-gates (duration, coverage, kinematics) → ONNX (4 views) → in-graph switch → probability gates
   (conf ≥ 0.65, margin ≥ 0.65, entropy ≤ 0.50, INVALID top-1), phrase-duration floor, stability.
5. JSON response → `summarize` / `draw` (verdict, confidence, margin, duration, checks) → `SessionLog.add` (CSV + `attempt_NNN.json`).
