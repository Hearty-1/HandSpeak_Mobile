# Flutter integration requirements for the staged LPH model

App: `D:\HandSpeak_Mobile-rules-compat` (git HEAD `104b909`, 2026-10-02, working tree clean). Copies in `06_Flutter_Integration/current_app_HandSpeak_Mobile-rules-compat`.

## What the app does today [V, code]
* `lib/module/civic/civic_tutorial_practice.dart`: camera (`camera` plugin, front camera), landmarks from the native method channel
  `fsl_holistic_channel`, builds the **818-value legacy feature vector** (`_extractFeatures818`) and evaluates with the legacy model.
* `android/.../MainActivity.kt`: MediaPipe **HandLandmarker only** (`hand_landmarker.task`, 2 hands), returns **68 points × 3** padded,
  **no body pose, no left/right handedness**.
* `lib/services/handspeak_api_service.dart`: base URL `https://handspeak-inference-xo2j6ffgta-as.a.run.app`, only the legacy
  `predict()` (`POST /v1/predict/{model}`); no raw-landmark call.
* `assets/civic/fsl_lupang_hinirang.onnx` (41 MB, legacy 818-feature model) + `labels_lupang_hinirang.json` (22 steps) in `pubspec.yaml`.
→ The app does **not** use the new pipeline at all; it cannot use the staged model by swapping a model file.

## What the staged model needs from the app
`POST /v1/predict_raw/lupang_hinirang` with Firebase ID token and JSON
`{image_width, image_height, frames: [{t, pose: 33×[x, y, visibility] | null, left_hand: 21×[x, y, z] | null, right_hand: 21×[x, y, z] | null}], top_k}`
(contract: `05_Inference_API/inference-service/app/main.py` `RawFrame` / `RawPredictRequest`; ≤ 600 frames, ≤ 30 s, increasing `t`).
Coordinates must be MediaPipe-normalised on the **upright, unmirrored** camera image; `left_hand` / `right_hand` are the **signer's**
hands (Holistic convention). The server gates require a pose in ≥ 80 % of frames and hands in ≥ 30 %.

## Required changes (remaining work)
1. **Native landmarks (Android, `MainActivity.kt`)** — add MediaPipe **PoseLandmarker** (33 points + visibility) next to HandLandmarker
   (or a Holistic landmarker), return pose + two hands **labelled as the signer's left / right** (Tasks handedness assumes a mirrored
   selfie image — must be mapped and tested), on the upright, unmirrored frame (apply sensor rotation; do not mirror), plus a timestamp.
   Training used MediaPipe Holistic (`model_complexity=1`, detection/tracking 0.35); the Tasks landmarkers differ → validate parity
   with a few recorded clips (send the same clip from the app and from `webcam_test_staging.py --video`).
2. **API client** — replace / extend `handspeak_api_service.dart` with the ready-made version in
   `06_Flutter_Integration/raw_endpoint_client_from_training_repo/handspeak_api_service.dart` (`predictRawLupangHinirang`,
   `RawPredictResponse`, rejection codes).
3. **Practice screen** — adopt `raw_endpoint_client_from_training_repo/civic_tutorial_practice (2).dart` (buffers raw frames, sends them,
   maps the answer by name / index, treats INVALID index 22 or a rejection as "not accepted", shows rejection messages).
   Its frame source expects pose + hands per frame (item 1).
4. **Manifest for the merged line** — replace `assets/civic/labels_lupang_hinirang.json` with
   `06_Flutter_Integration/proposed/flutter_labels_lupang_hinirang_MERGED_proposed.json` (21 steps; index 10 = "May dilag ang tula at
   awit sa paglayang minamahal"; index 11 removed; all other indices unchanged). Fix the fallback `p.index < _phrases.length` in
   `_indexOf` (with 21 phrases it rejects index 21 when name matching fails).
5. **Backend** — route traffic to revision 00016 (`lupang-v9`) only after 1–4 are tested against the tagged URL
   (`https://lupang-v9---handspeak-inference-xo2j6ffgta-as.a.run.app`); the legacy `/v1/predict/lupang_hinirang` endpoint and the
   bundled 41 MB ONNX can then be removed from the app.
6. **Tests** — regenerate `inference-service/tests/fixtures/lupang_raw_*.json` for the v9 model (they hold v4 expectations).

Files needed for the integration (all in this package): `05_Inference_API/inference-service/app/main.py` (contract),
`06_Flutter_Integration/raw_endpoint_client_from_training_repo/*.dart`, `06_Flutter_Integration/proposed/*.json`,
`04_Models/current_staged/lupang_hinirang_v4.json` (class names, gate), and for parity testing `05_Inference_API/webcam/webcam_test_staging.py`.
