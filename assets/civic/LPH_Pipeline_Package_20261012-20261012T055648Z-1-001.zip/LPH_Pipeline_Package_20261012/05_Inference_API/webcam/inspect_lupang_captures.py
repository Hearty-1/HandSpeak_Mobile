"""Inspect (and replay) webcam attempts saved by webcam_test_staging.py.

    python inspect_lupang_captures.py reports/lupang_retrain/webcam_sessions/session_<time>
    python inspect_lupang_captures.py <session dir> --replay inference-service/models_staging [other models dir ...]

For every attempt_NNN.json: target line, server outcome, hand-detection quality
(left / right / both / any hand on the first..last hand frame) and the rejection
reason, then a per-line summary that keeps two failure kinds apart:
  * capture problems: both hands detected in < 40 % of frames (reference videos:
    median 73 %) or the server rejected for landmarks / framing (NO_HANDS,
    LOW_LANDMARKS, OUT_OF_FRAME) - the model never saw a usable sign;
  * model problems on usable captures: correct / wrong / no prediction, and for
    no prediction whether the TARGET line was top-1 (under the thresholds).

--replay runs each saved request through the inference service's own code
(app.lupang_raw.RawSpecialistModel) for each models directory, so different
models can be compared on exactly the same real attempts. Only attempts with a
target are scored.
"""
import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
CAPTURE_CODES = {"NO_HANDS", "LOW_LANDMARKS", "OUT_OF_FRAME"}
LOW_BOTH = 0.40


def load(dirs):
    out = []
    for d in dirs:
        for p in sorted(Path(d).glob("attempt_*.json")):
            a = json.loads(p.read_text(encoding="utf-8"))
            a["file"] = str(p)
            out.append(a)
    return out


def outcome(res, target):
    if res.get("accepted"):
        idx = res["prediction"]["index"]
        return "correct" if idx == target else ("accepted" if target is None else "WRONG"), idx
    top = res["top_k"][0]["index"] if res.get("top_k") else None
    return "no prediction", top


def describe(a, res, classes):
    t = a["target_index"]
    out, top = outcome(res, t)
    hq = a.get("hand_quality") or {}
    code = (res.get("rejection") or {}).get("code")
    capture_bad = hq.get("both", 1.0) < LOW_BOTH or code in CAPTURE_CODES
    return {"target": t, "outcome": out, "top": top, "code": code, "capture_bad": capture_bad, "hq": hq,
            "p1": res["top_k"][0]["confidence"] if res.get("top_k") else None}


def report(attempts, results, classes, title):
    print(f"\n=== {title} ===")
    per = defaultdict(lambda: defaultdict(int))
    for a, r in zip(attempts, results):
        d = describe(a, r, classes)
        hq = d["hq"]
        tname = "-" if d["target"] is None else f"[{d['target'] + 1:02d}] {classes[d['target']][:24]}"
        top = "-" if d["top"] is None else f"[{d['top'] + 1:02d}] {classes[d['top']][:20]}"
        print(f"  {Path(a['file']).name}  target {tname:<30} {d['outcome']:<13} top1 {top:<26} "
              f"p1 {d['p1'] if d['p1'] is None else round(d['p1'], 2)!s:<5} {d['code'] or '':<16} "
              f"hands both {hq.get('both', 0):.0%} any {hq.get('any', 0):.0%}{'  CAPTURE' if d['capture_bad'] else ''}")
        if d["target"] is None:
            continue
        p = per[d["target"]]
        p["n"] += 1
        if d["capture_bad"]:
            p["capture problem"] += 1
        elif d["outcome"] == "correct":
            p["correct"] += 1
        elif d["outcome"] == "WRONG":
            p["WRONG"] += 1
        elif d["top"] == d["target"]:
            p["no pred, target was top-1"] += 1
        elif d["top"] == len(classes) - 1:
            p["no pred, INVALID top-1"] += 1
        else:
            p["no pred, other/none top-1"] += 1
    if per:
        print("  per target line (usable captures only count toward model outcomes):")
        for t in sorted(per):
            p = per[t]
            print(f"    [{t + 1:02d}] {classes[t][:32]:<32} n={p['n']:3d}  " +
                  "  ".join(f"{k} {p[k]}" for k in ("correct", "WRONG", "no pred, target was top-1",
                                                     "no pred, INVALID top-1", "no pred, other/none top-1",
                                                     "capture problem") if p[k]))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("sessions", nargs="+", help="session directories with attempt_*.json")
    ap.add_argument("--replay", nargs="*", default=[], help="models directories to replay the attempts through")
    a = ap.parse_args()
    attempts = load(a.sessions)
    if not attempts:
        raise SystemExit("no attempt_*.json found (sessions recorded before captures were saved have only a CSV)")
    sys.path.insert(0, str(HERE / "inference-service"))
    from app.lupang_raw import LupangRawModel
    classes = None
    if not a.replay:
        import lupang_common as lc
        classes = lc.CLASS_NAMES
        report(attempts, [x["response"] for x in attempts], classes, "as recorded (server response at the time)")
    for d in a.replay:
        model = LupangRawModel(Path(d))
        classes = model.class_names
        res = [model.predict(x["frames"], x["image_width"], x["image_height"], top_k=3) for x in attempts]
        report(attempts, res, classes, f"replayed through {d} ({model.meta['source_checkpoint']})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
