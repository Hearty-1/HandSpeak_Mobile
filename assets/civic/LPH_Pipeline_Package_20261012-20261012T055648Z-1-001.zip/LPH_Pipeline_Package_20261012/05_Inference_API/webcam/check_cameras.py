"""Show every camera device so you can see which one is your real, bright webcam.

    python check_cameras.py            (close webcam_test_staging.py first - one app per camera)

Each camera index (0-3) is opened with both Windows capture methods (DSHOW = what
webcam_test_staging.py uses by default, MSMF = the alternative) and shown for a few
seconds with its brightness. SPACE / any key = next, Q = stop. At the end it prints
which combination gave the brightest picture, and the command to use it.
A black or very dark picture on every camera usually means the Huawei pop-up camera
is pushed down, the privacy shutter is closed, or the room is too dark.
"""
import time

import cv2
import numpy as np

SECONDS = 4.0
BACKENDS = (("dshow", cv2.CAP_DSHOW), ("msmf", cv2.CAP_MSMF))


def main():
    results = []
    stop = False
    for idx in range(4):
        for name, api in BACKENDS:
            cap = cv2.VideoCapture(idx, api)
            if not cap.isOpened():
                continue
            t0, shown, bright = time.time(), 0, []
            while time.time() - t0 < SECONDS:
                ok, frame = cap.read()
                if not ok:
                    break
                shown += 1
                b = float(frame.mean())
                bright.append(b)
                disp = cv2.flip(frame, 1)
                cv2.rectangle(disp, (0, 0), (disp.shape[1], 40), (20, 20, 20), -1)
                cv2.putText(disp, f"camera {idx} / {name}  brightness {b:.0f}  (SPACE next, Q stop)", (10, 27),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2, cv2.LINE_AA)
                cv2.imshow("Camera check", disp)
                k = cv2.waitKey(1) & 0xFF
                if k in (ord("q"), ord("Q"), 27):
                    stop = True
                    break
                if k != 255:
                    break
            cap.release()
            if shown:
                b = float(np.median(bright[-10:]))
                results.append((b, idx, name))
                print(f"camera {idx} {name:<5}: {frame.shape[1]}x{frame.shape[0]}  brightness {b:.0f} / 255")
            if stop:
                break
        if stop:
            break
    cv2.destroyAllWindows()
    if not results:
        print("No camera delivered frames. Is another app (Teams, browser, the tester) using it?")
        return
    b, idx, name = max(results)
    print(f"\nBrightest: camera {idx} with {name} (brightness {b:.0f}).")
    if b < 40:
        print("Every camera is dark: check the pop-up camera / privacy shutter and the room lighting.")
    print(f"Use it with:  python webcam_test_staging.py --camera {idx} --backend {name} --target 1")


if __name__ == "__main__":
    main()
