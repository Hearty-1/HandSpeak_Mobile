﻿import cv2
import json
import time
import math
import numpy as np
import onnxruntime as ort
import mediapipe as mp
from pathlib import Path

# Paths para sa modelo at labels
MODEL_PATH = "mobile_deployment/fsl_lupang_hinirang.onnx"
if not Path(MODEL_PATH).exists():
    MODEL_PATH = "assets/civic/fsl_lupang_hinirang.onnx"

LABEL_PATH = "mobile_deployment/labels_lupang_hinirang.json"
if not Path(LABEL_PATH).exists():
    LABEL_PATH = "assets/civic/labels_lupang_hinirang.json"

print(f"Kinakarga ang model: {MODEL_PATH}")
session = ort.InferenceSession(MODEL_PATH)
input_name = session.get_inputs()[0].name

with open(LABEL_PATH, "r", encoding="utf-8") as f:
    manifest = json.load(f)
phrases = manifest["phrases"]
print(f"Mga parirala sa modelo: {[p['label'] for p in phrases]}")

# MediaPipe Holistic Setup (Pose + Face + Hands)
mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils
holistic = mp_holistic.Holistic(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5,
    smooth_landmarks=True
)

TARGET_FRAMES = 32
TOTAL_LANDMARKS = 68

def dist_3d(a, b):
    return math.sqrt((a[0]-b[0])**2 + (a[1]-b[1])**2 + (a[2]-b[2])**2)

def extract_features_842(clip_32_68_3):
    """
    Eksaktong Dart/Python feature extraction para sa Lupang Hinirang (842 features)
    """
    seq = clip_32_68_3.copy()
    norm_seq = np.zeros_like(seq)

    # 1. Torso Normalization
    for t in range(TARGET_FRAMES):
        left_sh = seq[t, 0]
        right_sh = seq[t, 1]
        sh_dist = dist_3d(left_sh, right_sh) + 1e-6
        center = (left_sh + right_sh) / 2.0
        norm_seq[t] = (seq[t] - center) / sh_dist

    # 2. Trajectory Slices (4 slices x 68 landmarks x 3 coords = 816 features)
    slice_features = []
    slice_size = TARGET_FRAMES // 4
    for s in range(4):
        start = s * slice_size
        end = (s + 1) * slice_size
        sub = norm_seq[start:end]
        mean_xyz = np.mean(sub, axis=0) # (68, 3)
        slice_features.extend(mean_xyz.flatten())

    # 3. Dynamic Finger Curls (Fingertips: 4, 8, 12, 16, 20)
    fingertips = [4, 8, 12, 16, 20]
    rh_curls = []
    lh_curls = []

    for tip in fingertips:
        d_rh = [dist_3d(norm_seq[t, 35 + tip], norm_seq[t, 35]) for t in range(TARGET_FRAMES)]
        d_lh = [dist_3d(norm_seq[t, 14 + tip], norm_seq[t, 14]) for t in range(TARGET_FRAMES)]
        rh_curls.extend([np.mean(d_rh), np.max(d_rh) - np.min(d_rh)])
        lh_curls.extend([np.mean(d_lh), np.max(d_lh) - np.min(d_lh)])

    # 4. Elevation Dynamics (Right Hand to Nose and Chest)
    rh_to_nose = []
    rh_to_chest = []
    for t in range(TARGET_FRAMES):
        rh_wrist = norm_seq[t, 35]
        nose = norm_seq[t, 56]
        chest = (norm_seq[t, 0] + norm_seq[t, 1]) / 2.0
        rh_to_nose.append(dist_3d(rh_wrist, nose))
        rh_to_chest.append(dist_3d(rh_wrist, chest))

    rh_nose_mean = np.mean(rh_to_nose)
    rh_nose_min = np.min(rh_to_nose)
    rh_chest_mean = np.mean(rh_to_chest)
    rh_chest_min = np.min(rh_to_chest)

    # 5. Kinetic Speeds
    total_speed_rh = 0.0
    total_speed_lh = 0.0
    for t in range(1, TARGET_FRAMES):
        for i in range(21):
            total_speed_rh += dist_3d(norm_seq[t, 35 + i], norm_seq[t - 1, 35 + i])
            total_speed_lh += dist_3d(norm_seq[t, 14 + i], norm_seq[t - 1, 14 + i])

    final_feats = np.array(
        slice_features + rh_curls + lh_curls +
        [rh_nose_mean, rh_nose_min, rh_chest_mean, rh_chest_min, total_speed_rh, total_speed_lh],
        dtype=np.float32
    )
    return final_feats

cap = cv2.VideoCapture(0)
frame_buffer = []
display_sign = "---"
display_acc = 0.0
status_text = "Ihanda ang katawan at mga kamay..."
evaluating = False

print("\n=== Lupang Hinirang Live Cam Accuracy Verifier (Q para lumabas) ===")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret: break

    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    res = holistic.process(rgb)

    # Kumuha ng eksaktong 68 landmarks
    pts_68 = np.zeros((68, 3), dtype=np.float32)

    # 1. Pose: 14 landmarks
    if res.pose_landmarks:
        mp_drawing.draw_landmarks(frame, res.pose_landmarks, mp_holistic.POSE_CONNECTIONS)
        pose_lms = res.pose_landmarks.landmark
        pose_indices = [11, 12, 13, 14, 15, 16, 23, 24, 0, 2, 5, 7, 8, 9]
        for i, idx in enumerate(pose_indices):
            pts_68[i] = [pose_lms[idx].x, pose_lms[idx].y, pose_lms[idx].z]

    # 2. Left Hand: 21 landmarks (offset 14)
    if res.left_hand_landmarks:
        mp_drawing.draw_landmarks(frame, res.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS)
        for j, lm in enumerate(res.left_hand_landmarks.landmark):
            pts_68[14 + j] = [lm.x, lm.y, lm.z]

    # 3. Right Hand: 21 landmarks (offset 35)
    if res.right_hand_landmarks:
        mp_drawing.draw_landmarks(frame, res.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS)
        for j, lm in enumerate(res.right_hand_landmarks.landmark):
            pts_68[35 + j] = [lm.x, lm.y, lm.z]

    # 4. Face Anchors: 12 landmarks (offset 56)
    if res.face_landmarks:
        face_indices = [33, 133, 362, 263, 1, 61, 291, 199, 10, 152, 234, 454]
        for k, idx in enumerate(face_indices):
            lm = res.face_landmarks.landmark[idx]
            pts_68[56 + k] = [lm.x, lm.y, lm.z]
    elif res.pose_landmarks:
        for k, idx in enumerate([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]):
            lm = res.pose_landmarks.landmark[idx]
            pts_68[56 + k] = [lm.x, lm.y, lm.z]

    # Pag-ipon ng 32 frames (Sliding Window tulad ng nasa Flutter)
    frame_buffer.append(pts_68)
    if len(frame_buffer) > TARGET_FRAMES:
        frame_buffer.pop(0)

    # Pagsusuri kapag buo na ang 32 frames
    if len(frame_buffer) == TARGET_FRAMES:
        clip_32 = np.array(frame_buffer)
        
        # Suriin kung gumagalaw ang kamay (maiwasan ang false prediction kapag nakatigil)
        rh_motion = np.sum(np.linalg.norm(np.diff(clip_32[:, 35], axis=0), axis=1))
        lh_motion = np.sum(np.linalg.norm(np.diff(clip_32[:, 14], axis=0), axis=1))

        if (rh_motion + lh_motion) > 0.15: # May sadyang kumpas
            feats = extract_features_842(clip_32).reshape(1, -1)
            outs = session.run(None, {input_name: feats})
            pred_idx = int(outs[0][0])
            probs = outs[1][0] if len(outs) > 1 and outs[1] else {}
            conf = probs.get(pred_idx, 0.85)

            predicted_phrase = phrases[pred_idx]["label"]
            display_acc = conf * 100

            if conf >= 0.65:
                display_sign = predicted_phrase
                status_text = f"TAMA! Accurate kumpas ({display_acc:.1f}%)"
            else:
                status_text = f"MALI o Bitin: {predicted_phrase} ({display_acc:.1f}%)"
        else:
            status_text = "Nakatigil / Magkumpas para sumubok..."

    # UI Display
    cv2.rectangle(frame, (0, 0), (w, 80), (20, 20, 20), -1)
    color = (0, 255, 0) if display_acc >= 65 else (0, 165, 255)

    cv2.putText(frame, f"SIGN: {display_sign} | ACCURACY: {display_acc:.1f}%", (20, 38),
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
    cv2.putText(frame, f"Status: {status_text}", (20, 68),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (220, 220, 220), 1)

    cv2.imshow("Lupang Hinirang Cam Verifier", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
holistic.close()
