﻿import cv2
import time
import torch
import torch.nn as nn
import numpy as np
from scipy.interpolate import interp1d
import mediapipe as mp

CLASSES = [
    "01 Bayang magiliw", "02 Perlas ng Silanganan", "03 Alab ng puso",
    "04 Sa dibdib mo'y buhay", "05 Lupang hinirang", "06 Duyan ka ng magiting",
    "07 Sa manlulupig", "08 Di ka pasisiil", "09 Sa dagat at bundok",
    "10 Sa simoy at sa langit", "11 May dilag ang tula at awit",
    "12 Sa paglayang minamahal", "13 Ang kislap ng watawat mo'y",
    "14 Tagumpay na nagniningning", "15 Ang bituin at araw niya",
    "16 Kailan pa ma'y di magdidilim", "17 Lupa ng araw ng luwalhati't pagsinta",
    "18 Buhay ay langit sa piling mo", "19 Aming ligaya",
    "20 Na pag may mang-aapi", "21 Ang mamatay", "22 Nang dahil sayo",
    "INVALID_GESTURE"
]

class FullSequenceConvBiLSTM(nn.Module):
    def __init__(self, in_features=128, hidden_dim=128, num_classes=23):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(in_features, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.25)
        )
        self.lstm = nn.LSTM(
            input_size=64,
            hidden_size=hidden_dim,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.3
        )
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes)
        )

    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.conv(x)
        x = x.transpose(1, 2)
        out, _ = self.lstm(x)
        feat = torch.mean(out, dim=1)
        return self.fc(feat)

device = torch.device("cpu")
model = FullSequenceConvBiLSTM(in_features=128, hidden_dim=128, num_classes=23)
model.load_state_dict(torch.load("palm_lupang_fresh128.pt", map_location=device))
model.eval()

mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils
holistic = mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5)

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

def extract_live_frame_vec(res):
    if res.pose_landmarks:
        plm = res.pose_landmarks.landmark
        nose = np.array([plm[0].x, plm[0].y, plm[0].z], dtype=np.float32)
        l_sh = np.array([plm[11].x, plm[11].y, plm[11].z], dtype=np.float32)
        r_sh = np.array([plm[12].x, plm[12].y, plm[12].z], dtype=np.float32)
        chest = (l_sh + r_sh) / 2.0
        torso_scale = np.linalg.norm(l_sh - r_sh) + 1e-6
    else:
        nose = np.array([0.5, 0.2, 0.0], dtype=np.float32)
        chest = np.array([0.5, 0.5, 0.0], dtype=np.float32)
        l_sh = np.array([0.6, 0.4, 0.0], dtype=np.float32)
        r_sh = np.array([0.4, 0.4, 0.0], dtype=np.float32)
        torso_scale = 0.25

    if res.left_hand_landmarks:
        lh = np.array([[p.x, p.y, p.z] for p in res.left_hand_landmarks.landmark], dtype=np.float32)
        lh_wrist = lh[0]
        lh_scale = np.linalg.norm(lh[9] - lh_wrist) + 1e-6
        lh_rel = ((lh - lh_wrist) / lh_scale)[:, :2].flatten()
    else:
        lh_wrist = chest.copy()
        lh_scale = 0.05
        lh_rel = np.zeros(42, dtype=np.float32)

    if res.right_hand_landmarks:
        rh = np.array([[p.x, p.y, p.z] for p in res.right_hand_landmarks.landmark], dtype=np.float32)
        rh_wrist = rh[0]
        rh_scale = np.linalg.norm(rh[9] - rh_wrist) + 1e-6
        rh_rel = ((rh - rh_wrist) / rh_scale)[:, :2].flatten()
    else:
        rh_wrist = chest.copy()
        rh_scale = 0.05
        rh_rel = np.zeros(42, dtype=np.float32)

    spatial = []
    spatial.extend((lh_wrist - chest) / torso_scale)
    spatial.extend((rh_wrist - chest) / torso_scale)
    spatial.extend((lh_wrist - nose) / torso_scale)
    spatial.extend((rh_wrist - nose) / torso_scale)
    spatial.extend((lh_wrist - l_sh) / torso_scale)
    spatial.extend((rh_wrist - r_sh) / torso_scale)
    spatial.extend((rh_wrist - lh_wrist) / torso_scale)
    spatial.append(lh_scale / torso_scale)
    spatial.append(rh_scale / torso_scale)

    return np.concatenate([lh_rel, rh_rel, np.array(spatial, dtype=np.float32)])

def finalize_live_sequence(raw_frames):
    arr = np.array(raw_frames, dtype=np.float32)
    cur_len = len(arr)
    x_old = np.linspace(0, 1, cur_len)
    x_new = np.linspace(0, 1, 32)
    f = interp1d(x_old, arr, axis=0, kind='linear')
    seq32 = f(x_new).astype(np.float32)

    velocity = np.zeros_like(seq32)
    velocity[1:] = seq32[1:] - seq32[:-1]
    v_features = velocity[:, 84:105]

    return np.concatenate([seq32, v_features], axis=-1).astype(np.float32)

recording = False
buffer_frames = []
top_preds = []

print("\n=== LUPANG HINIRANG ENGINE FRESH 128 ===")
print("Pindutin ang [SPACEBAR] para mag-record.")
print("Pindutin muli ang [SPACEBAR] para mag-predict.")
print("Pindutin ang [Q] para lumabas.\n")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    h, w, _ = frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    res = holistic.process(rgb)

    display_frame = cv2.flip(frame, 1)

    if recording:
        vec107 = extract_live_frame_vec(res)
        buffer_frames.append(vec107)

    # UI Top-Bar
    cv2.rectangle(display_frame, (0, 0), (w, 100), (20, 20, 20), -1)
    if recording:
        cv2.circle(display_frame, (30, 45), 12, (0, 0, 255), -1)
        cv2.putText(display_frame, f"RECORDING ({len(buffer_frames)} frames)...", (55, 52),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2)
    else:
        if top_preds:
            for idx, (p_sign, p_conf) in enumerate(top_preds):
                col = (0, 255, 0) if idx == 0 and p_conf >= 35.0 else (0, 215, 255)
                cv2.putText(display_frame, f"#{idx+1}: {p_sign} ({p_conf:.1f}%)", (20, 30 + (idx * 25)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.60, col, 2)
        else:
            cv2.putText(display_frame, "Pindutin ang [SPACEBAR] para simulan ang kumpas.", (20, 55),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.60, (220, 220, 220), 2)

    cv2.imshow("Lupang Hinirang Fresh 128 Engine", display_frame)
    key = cv2.waitKey(1) & 0xFF

    if key == 32: # SPACEBAR
        if not recording:
            recording = True
            buffer_frames = []
            top_preds = []
        else:
            recording = False
            if len(buffer_frames) >= 12:
                final_feat = finalize_live_sequence(buffer_frames) # (32, 128)
                tensor_in = torch.tensor(final_feat, dtype=torch.float32).unsqueeze(0)
                with torch.no_grad():
                    logits = model(tensor_in)
                    probs = torch.softmax(logits, dim=1).numpy()[0]
                    top_idx = np.argsort(probs)[::-1][:3]
                    top_preds = [(CLASSES[i], float(probs[i] * 100.0)) for i in top_idx]
            else:
                top_preds = [("Masyadong Maikli (<12 frames)", 0.0)]

    elif key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
holistic.close()
