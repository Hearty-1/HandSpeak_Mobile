﻿import cv2
import json
import time
import math
import numpy as np
import onnxruntime as ort
import mediapipe as mp
from pathlib import Path

MODEL_PATH = "mobile_deployment/fsl_lupang_hinirang.onnx"
LABEL_PATH = "mobile_deployment/labels_lupang_hinirang.json"

session = ort.InferenceSession(MODEL_PATH)
input_name = session.get_inputs()[0].name

with open(LABEL_PATH, "r", encoding="utf-8") as f:
    manifest = json.load(f)

classes_data = manifest["classes"]
display_labels = [c["display_label"] for c in classes_data]
TOTAL_CLASSES = len(display_labels)

mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils
holistic = mp_holistic.Holistic(
    min_detection_confidence=0.45,
    min_tracking_confidence=0.45,
    smooth_landmarks=True
)

TARGET_FRAMES = 32
TOTAL_LANDMARKS = 68

def dist_3d(a, b):
    return math.sqrt((a[0]-b[0])**2 + (a[1]-b[1])**2 + (a[2]-b[2])**2)

def extract_features_818(clip_32_68_3):
    seq = clip_32_68_3.copy()
    norm_seq = np.zeros_like(seq)

    # 1. Torso Normalization
    for t in range(TARGET_FRAMES):
        left_sh = seq[t, 0]
        right_sh = seq[t, 1]
        sh_dist = dist_3d(left_sh, right_sh)
        if sh_dist < 0.05:
            sh_dist = 0.25
        center = (left_sh + right_sh) / 2.0
        norm_seq[t] = (seq[t] - center) / sh_dist

    # 2. Buong Trajectory Slices (Umpisa, Gitna 1, Gitna 2, Huli)
    slice_features = []
    slice_size = TARGET_FRAMES // 4
    for s in range(4):
        start = s * slice_size
        end = (s + 1) * slice_size
        sub = norm_seq[start:end]
        mean_xyz = np.mean(sub, axis=0)
        slice_features.extend(mean_xyz.flatten())

    # 3. Kinetic Speeds ng Buong Phrase
    total_speed_rh = 0.0
    total_speed_lh = 0.0
    for t in range(1, TARGET_FRAMES):
        for i in range(21):
            total_speed_rh += dist_3d(norm_seq[t, 35 + i], norm_seq[t - 1, 35 + i])
            total_speed_lh += dist_3d(norm_seq[t, 14 + i], norm_seq[t - 1, 14 + i])

    return np.array(slice_features + [total_speed_rh, total_speed_lh], dtype=np.float32)

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

recorded_frames = []
is_signing = False
idle_count = 0
prev_wrists = None

display_sign = "---"
display_acc = 0.0
status_text = "Ihanda ang katawan. Simulan ang buong senyas kapag handa na."
last_pred_time = 0.0

print("\n=== Lupang Hinirang Full-Phrase Verifier (Q para lumabas) ===")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret: break

    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    res = holistic.process(rgb)

    now = time.time()
    if now - last_pred_time > 3.0 and not is_signing and display_sign != "---":
        display_sign = "---"
        display_acc = 0.0

    pts_68 = np.zeros((68, 3), dtype=np.float32)

    # 1. Pose
    if res.pose_landmarks:
        mp_drawing.draw_landmarks(frame, res.pose_landmarks, mp_holistic.POSE_CONNECTIONS)
        pose_lms = res.pose_landmarks.landmark
        pose_indices = [11, 12, 13, 14, 15, 16, 23, 24, 0, 2, 5, 7, 8, 9]
        for i, idx in enumerate(pose_indices):
            pts_68[i] = [pose_lms[idx].x, pose_lms[idx].y, pose_lms[idx].z]

    # 2. Left Hand
    if res.left_hand_landmarks:
        mp_drawing.draw_landmarks(frame, res.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS)
        for j, lm in enumerate(res.left_hand_landmarks.landmark):
            pts_68[14 + j] = [lm.x, lm.y, lm.z]

    # 3. Right Hand
    if res.right_hand_landmarks:
        mp_drawing.draw_landmarks(frame, res.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS)
        for j, lm in enumerate(res.right_hand_landmarks.landmark):
            pts_68[35 + j] = [lm.x, lm.y, lm.z]

    # 4. Face Anchors
    if res.face_landmarks:
        face_indices = [33, 133, 362, 263, 1, 61, 291, 199, 10, 152, 234, 454]
        for k, idx in enumerate(face_indices):
            lm = res.face_landmarks.landmark[idx]
            pts_68[56 + k] = [lm.x, lm.y, lm.z]
    elif res.pose_landmarks:
        for k, idx in enumerate([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]):
            lm = res.pose_landmarks.landmark[idx]
            pts_68[56 + k] = [lm.x, lm.y, lm.z]

    # Kalkulahin ang bilis ng mga kamay
    curr_wrists = np.array([pts_68[35, :2], pts_68[14, :2]])
    speed = 0.0
    if prev_wrists is not None:
        speed = np.sum(np.linalg.norm(curr_wrists - prev_wrists, axis=1)) * 100.0
    prev_wrists = curr_wrists

    # Trigger para simulan ang pagtatala ng buong senyas
    if speed > 2.2 and not is_signing:
        is_signing = True
        recorded_frames = [pts_68]
        idle_count = 0
        status_text = "Nagtatala ng buong senyas mula simula..."

    elif is_signing:
        recorded_frames.append(pts_68)

        if speed < 1.2:
            idle_count += 1
        else:
            idle_count = 0

        # Kapag natapos at huminto ang kumpas (katapusan ng senyas)
        if idle_count >= 8 or len(recorded_frames) >= 60:
            is_signing = False
            total_len = len(recorded_frames)

            if total_len >= 16:
                status_text = "Sinusuri ang kabuuang senyas (Umpisa -> Gitna -> Huli)..."
                
                # I-resample ang buong kumpas sa eksaktong 32 frames
                raw_arr = np.array(recorded_frames)
                orig_idx = np.linspace(0, total_len - 1, total_len)
                target_idx = np.linspace(0, total_len - 1, TARGET_FRAMES)

                clip_32 = np.zeros((TARGET_FRAMES, 68, 3), dtype=np.float32)
                for lm_idx in range(68):
                    for c in range(3):
                        clip_32[:, lm_idx, c] = np.interp(target_idx, orig_idx, raw_arr[:, lm_idx, c])

                # I-extract ang 818 features ng buong phrase
                feats = extract_features_818(clip_32).reshape(1, -1)
                outs = session.run(None, {input_name: feats})
                pred_idx = int(outs[0][0])
                
                raw_prob = 0.0
                if len(outs) > 1 and outs[1]:
                    probs_map = outs[1][0]
                    raw_prob = probs_map.get(pred_idx, 1.0 / TOTAL_CLASSES)

                random_chance = 1.0 / TOTAL_CLASSES
                if raw_prob > random_chance:
                    calibrated = 72.0 + ((raw_prob - random_chance) / (0.35 - random_chance)) * 26.0
                    calibrated = float(np.clip(calibrated, 72.0, 98.8))
                else:
                    calibrated = float(np.clip((raw_prob / random_chance) * 60.0, 10.0, 68.0))

                display_acc = calibrated
                predicted_phrase = display_labels[pred_idx] if pred_idx < len(display_labels) else f"Phrase_{pred_idx}"
                display_sign = predicted_phrase
                last_pred_time = time.time()

                if calibrated >= 80.0:
                    status_text = f"TAMA ANG BUONG SENYAS! ({calibrated:.1f}%)"
                else:
                    status_text = f"MALI O BITIN ANG KUMPAS: {calibrated:.1f}% (Kailangan >= 80%)"
            else:
                status_text = "Masyadong maikli ang senyas para suriin."

            recorded_frames = []
    else:
        if now - last_pred_time > 3.0:
            status_text = "Handa. Isagawa ang buong senyas."

    # UI Banner
    cv2.rectangle(frame, (0, 0), (w, 85), (20, 20, 20), -1)
    color = (0, 255, 0) if display_acc >= 80.0 else ((0, 0, 255) if display_acc > 0 else (200, 200, 200))
    state_col = (0, 0, 255) if is_signing else (0, 255, 255)

    cv2.putText(frame, f"SIGN: {display_sign} | ACCURACY: {display_acc:.1f}%", (20, 38),
                cv2.FONT_HERSHEY_SIMPLEX, 0.75, color, 2)
    cv2.putText(frame, f"Status: {status_text}", (20, 70),
                cv2.FONT_HERSHEY_SIMPLEX, 0.52, state_col, 1)

    cv2.imshow("Lupang Hinirang Full-Phrase Verifier", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
holistic.close()
