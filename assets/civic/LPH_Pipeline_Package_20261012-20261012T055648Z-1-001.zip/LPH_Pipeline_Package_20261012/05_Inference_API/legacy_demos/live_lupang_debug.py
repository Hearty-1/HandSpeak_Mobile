﻿import cv2
import time
import torch
import torch.nn as nn
import numpy as np
from scipy.interpolate import interp1d
import mediapipe as mp

CLASSES = [
    "01 Bayang magiliw", "02 Perlas ng Silanganan", "03 Alab ng puso",
    "04 Sa dibdib mo'y buhay", "05 Lupang hinirang", "06 Duyan ka ng magiting",
    "07 Sa manlulupig", "08 Di ka pasisiil", "09 Sa dagat at bundok",
    "10 Sa simoy at sa langit", "11 May dilag ang tula at awit",
    "12 Sa paglayang minamahal", "13 Ang kislap ng watawat mo'y",
    "14 Tagumpay na nagniningning", "15 Ang bituin at araw niya",
    "16 Kailan pa ma'y di magdidilim", "17 Lupa ng araw ng luwalhati't pagsinta",
    "18 Buhay ay langit sa piling mo", "19 Aming ligaya",
    "20 Na pag may mang-aapi", "21 Ang mamatay", "22 Nang dahil sayo",
    "INVALID_GESTURE"
]

class FullSequenceConvBiLSTM(nn.Module):
    def __init__(self, in_features=128, hidden_dim=128, num_classes=23):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(in_features, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.2)
        )
        self.lstm = nn.LSTM(
            input_size=64,
            hidden_size=hidden_dim,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.3
        )
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes)
        )

    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.conv(x)
        x = x.transpose(1, 2)
        out, _ = self.lstm(x)
        feat = torch.mean(out, dim=1)
        return self.fc(feat)

device = torch.device("cpu")
model = FullSequenceConvBiLSTM(in_features=128, hidden_dim=128, num_classes=23)
model.load_state_dict(torch.load("palm_lupang_robust_23class.pt", map_location=device))
model.eval()

mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils
holistic = mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5)

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

def extract_holistic_frame(pose_lm, lh_lm, rh_lm):
    features = []

    if pose_lm:
        pose = np.array([[p.x, p.y, p.z] for p in pose_lm], dtype=np.float32)
        nose = pose[0]
        l_shldr = pose[11]
        r_shldr = pose[12]
        chest = (l_shldr + r_shldr) / 2.0
        torso_scale = np.linalg.norm(l_shldr - r_shldr) + 1e-6
    else:
        nose = np.array([0.5, 0.2, 0.0], dtype=np.float32)
        chest = np.array([0.5, 0.5, 0.0], dtype=np.float32)
        l_shldr = np.array([0.6, 0.4, 0.0], dtype=np.float32)
        r_shldr = np.array([0.4, 0.4, 0.0], dtype=np.float32)
        torso_scale = 0.25

    if lh_lm:
        lh = np.array([[p.x, p.y, p.z] for p in lh_lm], dtype=np.float32)
        lh_wrist = lh[0]
        lh_scale = np.linalg.norm(lh[9] - lh_wrist) + 1e-6
        lh_rel = (lh - lh_wrist) / lh_scale
        features.extend(lh_rel.flatten()[:42])
    else:
        features.extend([0.0] * 42)
        lh_wrist = np.array([0.0, 0.0, 0.0], dtype=np.float32)
        lh_scale = 0.1

    if rh_lm:
        rh = np.array([[p.x, p.y, p.z] for p in rh_lm], dtype=np.float32)
        rh_wrist = rh[0]
        rh_scale = np.linalg.norm(rh[9] - rh_wrist) + 1e-6
        rh_rel = (rh - rh_wrist) / rh_scale
        features.extend(rh_rel.flatten()[:42])
    else:
        features.extend([0.0] * 42)
        rh_wrist = np.array([0.0, 0.0, 0.0], dtype=np.float32)
        rh_scale = 0.1

    features.extend((lh_wrist - chest) / torso_scale)
    features.extend((rh_wrist - chest) / torso_scale)
    features.extend((lh_wrist - nose) / torso_scale)
    features.extend((rh_wrist - nose) / torso_scale)
    features.extend((lh_wrist - l_shldr) / torso_scale)
    features.extend((rh_wrist - r_shldr) / torso_scale)
    features.extend((rh_wrist - lh_wrist) / torso_scale)
    features.append((lh_wrist[1] - chest[1]) / torso_scale)
    features.append((rh_wrist[1] - chest[1]) / torso_scale)
    features.append(lh_scale / torso_scale)
    features.append(rh_scale / torso_scale)

    needed = 128 - len(features)
    if needed > 0:
        features.extend([0.0] * needed)

    return features[:128]

def resample_sequence(seq, target_len=32):
    current_len = len(seq)
    if current_len == target_len:
        return np.array(seq, dtype=np.float32)
    x_old = np.linspace(0, 1, current_len)
    x_new = np.linspace(0, 1, target_len)
    f = interp1d(x_old, np.array(seq), axis=0, kind='linear')
    return f(x_new).astype(np.float32)

recording = False
buffer_feats = []
top_predictions = []

print("\n=== LUPANG HINIRANG TOP-3 DIAGNOSTIC ENGINE ===")
print("Pindutin ang [SPACEBAR] para mag-record.")
print("Pindutin muli ang [SPACEBAR] para mag-predict.")
print("Pindutin ang [Q] para lumabas.\n")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Kinukuha ang features bago o pagkatapos ng flip upang maiwasan ang coordinate mismatch
    h, w, _ = frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    res = holistic.process(rgb)

    # I-flip ang frame para sa display lamang
    display_frame = cv2.flip(frame, 1)

    if recording:
        feat = extract_holistic_frame(
            res.pose_landmarks.landmark if res.pose_landmarks else None,
            res.left_hand_landmarks.landmark if res.left_hand_landmarks else None,
            res.right_hand_landmarks.landmark if res.right_hand_landmarks else None
        )
        buffer_feats.append(feat)

    # UI Banner
    cv2.rectangle(display_frame, (0, 0), (w, 110), (20, 20, 20), -1)
    if recording:
        cv2.circle(display_frame, (30, 45), 12, (0, 0, 255), -1)
        cv2.putText(display_frame, f"RECORDING ({len(buffer_feats)} frames)...", (55, 52),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2)
    else:
        if top_predictions:
            for idx, (sign, conf) in enumerate(top_predictions):
                color = (0, 255, 0) if idx == 0 and conf >= 35.0 else (0, 215, 255)
                cv2.putText(display_frame, f"#{idx+1}: {sign} ({conf:.1f}%)", (25, 30 + (idx * 26)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.60, color, 2)
        else:
            cv2.putText(display_frame, "Pindutin ang [SPACEBAR] para simulan ang senyas.", (25, 55),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, (220, 220, 220), 2)

    cv2.imshow("Lupang Hinirang Diagnostic Engine", display_frame)
    key = cv2.waitKey(1) & 0xFF

    if key == 32:  # SPACEBAR
        if not recording:
            recording = True
            buffer_feats = []
            top_predictions = []
        else:
            recording = False
            if len(buffer_feats) >= 12:
                seq32 = resample_sequence(buffer_feats, 32)
                tensor_in = torch.tensor(seq32, dtype=torch.float32).unsqueeze(0)
                with torch.no_grad():
                    logits = model(tensor_in)
                    probs = torch.softmax(logits, dim=1).numpy()[0]
                    # Kunin ang Top 3 highest confidence classes
                    top3_idx = np.argsort(probs)[::-1][:3]
                    top_predictions = [(CLASSES[i], float(probs[i] * 100.0)) for i in top3_idx]
            else:
                top_predictions = [("Masyadong Maikli (<12 frames)", 0.0)]

    elif key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
holistic.close()
