"""LOCAL-ONLY test server for the STAGED Lupang Hinirang model.

    D:\\venv_lupang_export\\Scripts\\python.exe local_staging_server.py [--port 8765]

Runs the unchanged inference service (app.main: same request validation,
feature pipeline, ONNX model and rejection gates as Cloud Run) with
MODELS_DIR = models_staging/. Differences from production, all local:
  * Firebase authentication is replaced by a fixed local user (the same
    dependency override the service's own tests use) - there is no Firebase
    token on this PC. Because of that the server only binds to 127.0.0.1.
  * GET /local/staging_info reports which model files were actually loaded
    (path, SHA-256, source checkpoint, gate thresholds) so the webcam client
    can verify it is talking to the staged model.
Nothing here is deployed; production (models/ and Cloud Run) is untouched.
"""
import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PRODUCTION_MODELS = (HERE / "models").resolve()


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--models-dir", type=Path, default=HERE / "models_staging")
    ap.add_argument("--port", type=int, default=8765)
    args = ap.parse_args()

    models_dir = args.models_dir.resolve()
    if models_dir == PRODUCTION_MODELS:
        raise SystemExit("Refusing to serve the PRODUCTION models directory; this server is for staging only.")
    meta_path = models_dir / "lupang_hinirang_v4.json"
    if not meta_path.exists():
        raise SystemExit(f"No staged Lupang model in {models_dir}")
    # MODELS_DIR is read when app.registry / app.lupang_raw are imported: set it first.
    os.environ["MODELS_DIR"] = str(models_dir)
    sys.path.insert(0, str(HERE))

    import uvicorn
    from fastapi import Request
    from app import auth, main as service

    service.init_firebase = lambda: None                      # no Firebase locally
    service.app.dependency_overrides[auth.require_user] = lambda: {"uid": "local-staging-test"}

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    onnx_path = models_dir / meta["onnx_file"]
    prod_onnx = PRODUCTION_MODELS / meta["onnx_file"]
    info = {
        "models_dir": str(models_dir),
        "onnx_file": str(onnx_path),
        "onnx_sha256": sha256(onnx_path),
        "production_onnx_sha256": sha256(prod_onnx) if prod_onnx.exists() else None,
        "source_checkpoint": meta["source_checkpoint"],
        "feature_version": meta["feature_version"],
        "class_names": meta["class_names"],
        "gate": {k: meta["gate"][k] for k in ("min_conf", "min_margin", "max_entropy", "min_duration_s",
                                              "min_raw_frames", "class_min_duration", "trim_still")},
    }
    info["is_production_model"] = info["onnx_sha256"] == info["production_onnx_sha256"]

    @service.app.get("/local/staging_info")
    def staging_info(request: Request):
        m = request.app.state.raw_models["lupang_hinirang"]
        # What the running model object actually holds, not just what is on disk.
        return {**info, "loaded_source_checkpoint": m.meta["source_checkpoint"],
                "loaded_gate_min_conf": m.gate["min_conf"], "loaded_gate_min_margin": m.gate["min_margin"]}

    print(f"Serving STAGED model {info['source_checkpoint']} ({onnx_path.name}, sha256 {info['onnx_sha256'][:12]}...)")
    print(f"  gate: min_conf {info['gate']['min_conf']}, min_margin {info['gate']['min_margin']}")
    if info["is_production_model"]:
        print("  WARNING: the staged ONNX is byte-identical to production")
    print(f"  http://127.0.0.1:{args.port}/local/staging_info")
    uvicorn.run(service.app, host="127.0.0.1", port=args.port, log_level="info")


if __name__ == "__main__":
    main()
