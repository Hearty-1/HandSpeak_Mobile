"""Targeted fix for Perlas ng Silanganan in the staged palm_lupang_v9_switch.

    python fix_perlas.py cv        # two-fold test on the new labelled Perlas attempts
    python fix_perlas.py final     # fine-tune with all of them -> palm_lupang_v9p_B_m*.pt

Cause: the user-adapted part (v9 B) learned the user's Perlas from 6 tester attempts but the
user's Ang kislap from 16 takes; the user's Perlas resembles it, so B spreads probability over
Perlas / Ang kislap / INVALID (top-1 Perlas at 0.15-0.69). The original part puts INVALID first.

Fix (smallest change): only the PERLAS ROW of the output layer of each v9 B member is fine-tuned
(64 weights + 1 bias; every other class's logit, the feature extractor, the original part, the
gate and all thresholds unchanged - a whole-head fine-tune was tested and rejected: it raised
Perlas 2/14 -> 9/14 but cost 7 correct answers on other lines), on B's own training data (rehearsal, every class) plus the user's labelled Perlas
attempts of session 20261012_111351 (attempt 055 excluded: both model parts read it as Bayang
magiliw at 0.93 / 0.77 - most likely signed with the target left on Perlas).

The decision is computed exactly as the service does (lupang_common.evaluate_capture) with the
switch rule of build_lupang_switch.py (--fold 12:11 --arbitrate) over the ONNX original part.
"""
import argparse
import glob
import json
import sys
from pathlib import Path

import numpy as np
import onnxruntime as ort
import torch
import torch.nn as nn

import lupang_common as lc
import retrain_lupang_grouped as R
import train_lupang_model as t
import fix_lupang_lines as F
from cv_lupang import build_training_set
from test_lupang_recognition import _cut, load_captures

HERE = Path(__file__).resolve().parent
SESSION = "session_20261012_111351"
EXCLUDE = {55}
PERLAS, KISLAP = 1, 12
BASE = [HERE / f"palm_lupang_v9_B_m{m}.pt" for m in range(3)]
OUT_NAME = "palm_lupang_v9p_B_m{m}.pt"
REC = [0, 1, 4, 5, 7, 9, 10, 12, 13, 14, 15, 16, 18, 19, 20, 21]
STAGING = HERE / "inference-service" / "models_staging"
ORIG_ONNX = HERE / "inference-service" / "models_staging_v5_ens3" / "fsl_lupang_hinirang_v4.onnx"
EPOCHS, LR = 15, 1e-3
SCOPE = "head"     # fine-tuned part of the user model: "head" (output head) or "row" (Perlas output row)


def new_perlas(parity=None):
    keep = lambda n, tgt: PERLAS if tgt == PERLAS and n not in EXCLUDE and (parity is None or n % 2 == parity) else None
    return F.attempt_captures(SESSION, keep)


def live(targets, sessions=("session_20261012_090256", SESSION)):
    out = []
    for s in sessions:
        out += F.attempt_captures(s, lambda n, tgt: tgt if tgt in targets else None)
    return out


def finetune(base, out, extra, seed):
    """Head-only fine-tune of one member on its training data + `extra` capture dicts."""
    caps = load_captures()
    allcaps = caps + F.labelled_bp() + extra
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    X, y, _ = build_training_set(allcaps, list(range(len(allcaps))), R.RECIPE, np.random.default_rng(seed))
    model, ckpt = lc.load_model(base)
    for p in model.parameters():
        p.requires_grad = False
    if SCOPE == "head":
        for p in model.head.parameters():
            p.requires_grad = True
        opt = torch.optim.AdamW(model.head.parameters(), lr=LR, weight_decay=1e-2)
    # Only the Perlas row of the output layer learns (64 weights + 1 bias): every other class's
    # logit is computed exactly as before, so other lines can only change where Perlas rises.
    if SCOPE == "row":
        last = model.head[-1]
        last.weight.requires_grad = True
        last.bias.requires_grad = True
        row = torch.zeros_like(last.weight)
        row[PERLAS] = 1.0
        last.weight.register_hook(lambda g: g * row)
        last.bias.register_hook(lambda g: g * row[:, 0])
        opt = torch.optim.Adam([last.weight, last.bias], lr=LR)    # no weight decay: frozen rows stay exact
    crit = nn.CrossEntropyLoss(label_smoothing=0.1)
    for ep in range(EPOCHS):
        if ep % 5 == 0:
            pool_X, pool_y = t.build_balanced_pool(X, y, 60, rng)
        model.train()
        model.conv.eval()
        model.lstm.eval()              # frozen feature extractor: keep BN / dropout in inference mode
        perm = rng.permutation(len(pool_X))
        for i in range(0, len(perm), 64):
            idx = perm[i:i + 64]
            xb, yb = torch.from_numpy(pool_X[idx]), torch.from_numpy(pool_y[idx])
            opt.zero_grad()
            loss = crit(model(xb), yb)
            loss.backward()
            opt.step()
    model.eval()
    ckpt["state_dict"] = model.state_dict()
    ckpt["metrics"] = {**ckpt.get("metrics", {}), "perlas_row_finetune": {
        "base": Path(base).name, "extra_perlas_attempts": len(extra), "epochs": EPOCHS, "lr": LR}}
    torch.save(ckpt, out)
    return out


class Switch:
    """Service decision of the staged switch with the user part replaced by given checkpoints.
    perlas_gate: user part = the fine-tuned members where THEY rank Perlas first, the current
    (unchanged) v9 B members everywhere else."""

    def __init__(self, b_ckpts, perlas_gate=False):
        self.sa = ort.InferenceSession(str(ORIG_ONNX), providers=["CPUExecutionProvider"])
        self.mb = [lc.load_model(p)[0] for p in b_ckpts]
        self.mb_old = [lc.load_model(p)[0] for p in BASE] if perlas_gate else None
        self.rec = np.zeros(lc.NUM_CLASSES, bool)
        self.rec[REC] = True
        self.gate = json.loads((STAGING / "lupang_hinirang_v4.json").read_text(encoding="utf-8"))["gate"]

    def probs(self, batch):
        batch = np.asarray(batch, np.float32)
        la = self.sa.run(["logits"], {"features": batch})[0]
        pa = np.exp(la - la.max(1, keepdims=True))
        pa /= pa.sum(1, keepdims=True)
        pa[:, 10] += pa[:, 11]
        pa[:, 11] = 0.0
        with torch.no_grad():
            x = torch.from_numpy(batch)
            pb = torch.stack([torch.softmax(m(x), 1) for m in self.mb]).mean(0).numpy()
            if self.mb_old is not None:
                old = torch.stack([torch.softmax(m(x), 1) for m in self.mb_old]).mean(0).numpy()
                pb = np.where((pb.argmax(1) == PERLAS)[:, None], pb, old)
        use_b = self.rec[pb.argmax(1)] & (pb.max(1) >= pa.max(1))
        return np.where(use_b[:, None], pb, pa)

    def decide(self, raw, ts):
        out = lc.evaluate_capture(raw, ts, self.probs, self.gate)
        p = out["probs"]
        return out["accepted"], (int(np.argmax(p)) if p is not None else None), p, out["failed"]


def report(name, decider, sets):
    res = {}
    for sname, caps in sets.items():
        rows = []
        for c in caps:
            acc, top, p, failed = decider(c["raw"], c["ts"])
            rows.append({"label": c["label"], "acc": acc, "top": top, "p": p, "failed": failed})
        res[sname] = rows
        n = len(rows)
        ok = sum(r["acc"] and r["top"] == r["label"] for r in rows)
        wrong = [r for r in rows if r["acc"] and r["top"] != r["label"]]
        as_perlas = sum(r["acc"] and r["top"] == PERLAS and r["label"] != PERLAS for r in rows)
        line = f"  {name:<22} {sname:<34} n={n:3d} correct {ok:3d} wrong {len(wrong)} (as Perlas {as_perlas})"
        if sname.startswith("Perlas") and n:
            P = np.array([r["p"] for r in rows if r["p"] is not None])
            srt = np.sort(P, 1)[:, ::-1]
            ent = [lc.normalized_entropy(p) for p in P]
            line += (f" | P(Perlas) median {np.median(P[:, PERLAS]):.3f} | margin median {np.median(srt[:, 0] - srt[:, 1]):.3f}"
                     f" | entropy median {np.median(ent):.3f} | P(Ang kislap) median {np.median(P[:, KISLAP]):.3f}")
        print(line, flush=True)
    return res


def fragments(caps):
    out = []
    for c in caps:
        for a, b in ((0.0, 0.5), (0.5, 1.0)):
            raw, ts = _cut(c["raw"], c["ts"], a, b)
            out.append({"label": -1, "raw": raw, "ts": ts})
    return out


def eval_sets(test_perlas):
    return {"Perlas (held-out attempts)": test_perlas,
            "Perlas halves (must be rejected)": fragments(test_perlas),
            "Ang kislap attempts (live, labelled)": live({KISLAP}),
            "Lupa ng araw attempts (live, labelled)": live({16}),
            "all other lines (live, labelled)": live(set(range(22)) - {PERLAS, KISLAP, 16, 11})}


def cmd_cv(a):
    sys.path.insert(0, str(HERE / "inference-service"))
    from app.lupang_raw import LupangRawModel
    from test_lupang_recognition import raw_to_frames
    current = Switch(BASE)
    # The offline switch must reproduce the staged service before it is used as the baseline.
    staged = LupangRawModel(STAGING)
    same = 0
    probe = new_perlas() + live({KISLAP})
    for c in probe:
        r = staged.predict(raw_to_frames(c["raw"], c["ts"]), 1000, 1000, top_k=3)
        acc, top, _, failed = current.decide(c["raw"], c["ts"])
        same += r["accepted"] == acc and r["failed_checks"] == failed
    print(f"offline switch vs staged service: {same}/{len(probe)} identical decisions", flush=True)
    if same != len(probe):
        raise SystemExit("offline switch does not reproduce the staged service")
    for parity in (1, 0):
        train, test = new_perlas(parity), new_perlas(1 - parity)
        tag = "odd" if parity == 1 else "even"
        print(f"\n=== fold: fine-tune on {tag} attempts ({len(train)}), test on the other {len(test)} ===", flush=True)
        outs = [finetune(BASE[m], HERE / "cv_runs" / "fix_v9" / f"perlas_{tag}_m{m}.pt", train, 42 + m)
                for m in range(3)]
        sets = eval_sets(test)
        report("current staged v9", current.decide, sets)
        report(f"{SCOPE} fine-tuned", Switch(outs).decide, sets)
        report(f"{SCOPE} FT, Perlas-gated", Switch(outs, perlas_gate=True).decide, sets)
    return 0


def cmd_final(a):
    extra = new_perlas()
    outs = [finetune(BASE[m], HERE / OUT_NAME.format(m=m), extra, 42 + m) for m in range(3)]
    print("wrote", [o.name for o in outs], f"(+{len(extra)} Perlas attempts)")
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["cv", "final"])
    ap.add_argument("--scope", choices=["head", "row"], default="head")
    a = ap.parse_args()
    global SCOPE
    SCOPE = a.scope
    torch.set_num_threads(4)
    return {"cv": cmd_cv, "final": cmd_final}[a.cmd](a)


if __name__ == "__main__":
    raise SystemExit(main())
