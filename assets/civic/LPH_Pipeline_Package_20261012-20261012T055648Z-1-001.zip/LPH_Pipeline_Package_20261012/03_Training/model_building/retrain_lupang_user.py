"""Retrain the Lupang Hinirang ensemble WITH the user's own webcam takes, and measure it.

    python retrain_lupang_user.py experiment --member M [--with-user 0|1]   # one ensemble member of model A or B
    python retrain_lupang_user.py report                                       # compare A vs B on held-out data
    python retrain_lupang_user.py final --member M                             # deployable member on ALL clips

The user's takes (source "webcam_take") are their own versions of the signs; for
several lines they differ from the reference signers', so a model trained on the
reference videos alone cannot recognise them however good the capture is.

Experiment split (fixed, no clip in two partitions):
    test_user_new   last 30 % (by recording time) of each line's NEW takes
                    (recorded with record_lupang_samples.py, *.timestamps.json sidecar) -
                    separate recordings made after the training takes
    test_user_old   the user's 35 OLDER takes (an earlier session; no sidecar)
    test_ref        3 reference signers held out completely (SRC3, SRC9, bE63aZBXC_g:
                    every line present) - checks that other signers do not get worse
    train           everything else; model A uses only its reference clips, model B
                    also the user's training takes (first 70 % of each line's new takes)
Each model is a 3-member ensemble (members early-stopped on different held-out
reference sources, retrain_lupang_grouped.inner_split). Decisions use the full
live gate (lupang_common.evaluate_capture logic) with the STAGED thresholds
(min_conf 0.65, min_margin 0.65); kinematic / duration calibration on each
model's own training clips.
"""
import argparse
import json
import os
import pickle
from collections import Counter
from pathlib import Path

import numpy as np
import torch

import lupang_common as lc
import retrain_lupang_grouped as R
from cv_lupang import build_training_set
from test_lupang_recognition import load_captures

HERE = Path(__file__).resolve().parent
OUT = HERE / "cv_runs" / "user_v7"
TEST_REF_SOURCES = ("SRC3", "SRC9", "bE63aZBXC_g")
USER_TEST_FRAC = 0.30
STAGED_GATE = {"min_conf": 0.65, "min_margin": 0.65, "min_margin_vs_invalid": 0.65}
FINAL_NAME = "palm_lupang_v7_user_m{m}.pt"


def is_new_take(c):
    return c["source"] == "webcam_take" and os.path.exists(c["path"][:-4] + ".timestamps.json")


def take_time(c):
    return int(Path(c["path"]).stem.split("_")[-1])


def split(caps):
    test_new, test_old, test_ref, train_ref, train_user = [], [], [], [], []
    by_line = {}
    for i, c in enumerate(caps):
        if is_new_take(c):
            by_line.setdefault(c["label"], []).append(i)
    for lab, idx in by_line.items():
        idx = sorted(idx, key=lambda i: take_time(caps[i]))
        k = max(1, int(round(USER_TEST_FRAC * len(idx))))
        train_user += idx[:-k]
        test_new += idx[-k:]
    for i, c in enumerate(caps):
        if c["source"] == "webcam_take" and not is_new_take(c):
            test_old.append(i)
        elif c["source"] in TEST_REF_SOURCES:
            test_ref.append(i)
        elif c["source"] != "webcam_take":
            train_ref.append(i)
    return {"test_user_new": sorted(test_new), "test_user_old": test_old, "test_ref": test_ref,
            "train_ref": train_ref, "train_user": sorted(train_user)}


def gate_for(caps, idx, seed):
    X, y, d = build_training_set(caps, idx, R.RECIPE, np.random.default_rng(seed))
    return {**R.fold_gate(X, y, d), **STAGED_GATE}


def cmd_experiment(a):
    caps = load_captures()
    sp = split(caps)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "split.json").write_text(json.dumps({k: [caps[i]["path"] for i in v] for k, v in sp.items()}, indent=1),
                                    encoding="utf-8")
    model = "B" if a.with_user else "A"
    train = sp["train_ref"] + (sp["train_user"] if a.with_user else [])
    seed = 42 + 1000 * a.member
    tr, va = R.inner_split(caps, train, np.random.default_rng(seed))
    ckpt = OUT / f"{model}_m{a.member}.pt"
    best, _, counts = R.train_one(caps, tr, va, ckpt, seed, a.verbose)
    gate = gate_for(caps, train, 7)
    scorer = R.Scorer(ckpt)
    recs = {}
    for name in ("test_user_new", "test_user_old", "test_ref"):
        recs[name] = R.score_set(scorer, gate, R.scenario_captures(caps, sp[name], 500))
    with open(OUT / f"{model}_m{a.member}_scored.pkl", "wb") as fh:
        pickle.dump({"gate": gate, "best": best, "val_sources": sorted({caps[i]["source"] for i in va}),
                     "n_train": len(tr), "user_in_train": sum(caps[i]["source"] == "webcam_take" for i in tr),
                     "recs": recs}, fh)
    print(f"[{model} m{a.member}] train {len(tr)} (user {sum(caps[i]['source'] == 'webcam_take' for i in tr)}) "
          f"val {len(va)} {sorted({caps[i]['source'] for i in va})} | bacc {best['bacc']:.3f} @ ep {best['epoch']}",
          flush=True)
    return 0


def _merge(parts, key):
    base = parts[0]["recs"][key]
    out = []
    for k, r in enumerate(base):
        m = dict(r)
        if r.get("probs") is not None:
            m["probs"] = np.mean([p["recs"][key][k]["probs"] for p in parts], axis=0)
            m["view_probs"] = np.mean([p["recs"][key][k]["view_probs"] for p in parts], axis=0)
        out.append(m)
    return out


def evaluate(recs, gate):
    """Per scenario kind / per line outcomes of an ensemble's records."""
    out = {"lines": {}, "neg_accepted": Counter(), "neg_n": Counter()}
    comp = [r for r in recs if r["scenario"] == "complete line"]
    for r in recs:
        if r["kind"] == "negative":
            acc, _, _ = R.decide(r, gate)
            g = r["scenario"].split(":")[0]
            out["neg_n"][g] += 1
            out["neg_accepted"][g] += int(acc)
    for r in comp:
        acc, top, failed = R.decide(r, gate)
        p = r.get("probs")
        top1 = int(np.argmax(p)) if p is not None else -1
        d = out["lines"].setdefault(r["label"], Counter())
        d["n"] += 1
        d["closed_ok"] += int(p is not None and int(np.argmax(p[:lc.INVALID_IDX])) == r["label"])
        d["p_true"] += float(p[r["label"]]) if p is not None else 0.0
        if acc and top == r["label"]:
            d["correct"] += 1
        elif acc:
            d["wrong"] += 1
        elif top1 == r["label"]:
            d["nopred_true_top1"] += 1
        elif top1 == lc.INVALID_IDX:
            d["nopred_invalid"] += 1
        else:
            d["nopred_other"] += 1
    return out


def summarize(ev):
    L = ev["lines"]
    n = sum(d["n"] for d in L.values())
    f = lambda k: sum(d[k] for d in L.values()) / max(n, 1)
    negn = sum(ev["neg_n"].values())
    return {"n": n, "correct": f("correct"), "wrong": f("wrong"),
            "no_pred": 1 - f("correct") - f("wrong"), "closed_acc": f("closed_ok"), "mean_p_true": f("p_true"),
            "false_accept": sum(ev["neg_accepted"].values()) / max(negn, 1), "n_neg": negn}


def cmd_report(a):
    res = {}
    for model in ("A", "B"):
        parts = []
        for m in range(3):
            p = OUT / f"{model}_m{m}_scored.pkl"
            if p.exists():
                with open(p, "rb") as fh:
                    parts.append(pickle.load(fh))
        if len(parts) < 3:
            print(f"model {model}: {len(parts)}/3 members trained")
            continue
        gate = parts[0]["gate"]
        res[model] = {}
        for key in ("test_user_new", "test_user_old", "test_ref"):
            ev = evaluate(_merge(parts, key), gate)
            res[model][key] = {"summary": summarize(ev),
                               "per_line": {lc.CLASS_NAMES[k]: dict(v) for k, v in sorted(ev["lines"].items())},
                               "negatives_accepted": {k: f"{ev['neg_accepted'][k]}/{ev['neg_n'][k]}" for k in ev["neg_n"]}}
    for key, title in (("test_user_new", "YOUR later takes (not trained on)"),
                       ("test_user_old", "YOUR older session takes (not trained on)"),
                       ("test_ref", "3 held-out reference signers")):
        print(f"\n=== {title} ===")
        for model in res:
            s = res[model][key]["summary"]
            print(f"  model {model} ({'with' if model == 'B' else 'without'} your takes): complete lines n={s['n']} "
                  f"correct {s['correct']:.3f} wrong {s['wrong']:.3f} no-pred {s['no_pred']:.3f} | top-1 right "
                  f"{s['closed_acc']:.3f} | mean P(true line) {s['mean_p_true']:.3f} | negatives accepted "
                  f"{s['false_accept']:.3f} (n={s['n_neg']})")
        if key == "test_user_new" and len(res) == 2:
            print("  per line (correct/n  mean P(true)):  model A  ->  model B")
            for line in res["B"][key]["per_line"]:
                a_ = res["A"][key]["per_line"].get(line, {})
                b_ = res["B"][key]["per_line"][line]
                print(f"    {line[:34]:<34} {a_.get('correct', 0)}/{a_.get('n', 0)} {a_.get('p_true', 0) / max(a_.get('n', 1), 1):.2f}"
                      f"  ->  {b_.get('correct', 0)}/{b_['n']} {b_.get('p_true', 0) / b_['n']:.2f}"
                      f"  (B wrong {b_.get('wrong', 0)}, no-pred: true top-1 {b_.get('nopred_true_top1', 0)}, "
                      f"INVALID {b_.get('nopred_invalid', 0)}, other {b_.get('nopred_other', 0)})")
    (OUT / "report.json").write_text(json.dumps(res, indent=2, default=float), encoding="utf-8")
    return 0


def cmd_final(a):
    """Deployable member trained on ALL valid clips (reference + every user take)."""
    caps = load_captures()
    seed = 42 + 1000 * a.member
    allidx = list(range(len(caps)))
    tr, va = R.inner_split(caps, allidx, np.random.default_rng(seed))
    out = HERE / FINAL_NAME.format(m=a.member)
    best, _, _ = R.train_one(caps, tr, va, out, seed, a.verbose)
    gate = gate_for(caps, allidx, 7)
    ck = torch.load(out, map_location="cpu", weights_only=False)
    ck["metrics"].update(gate=gate, recipe="v5 + user takes", train_clips=len(tr), val_clips=len(va),
                         val_sources=sorted({caps[i]["source"] for i in va}),
                         user_takes_in_train=sum(caps[i]["source"] == "webcam_take" for i in tr))
    torch.save(ck, out)
    if a.member == 0:
        (OUT / "final_gate.json").write_text(json.dumps(gate, indent=2), encoding="utf-8")
    print(f"[final m{a.member}] train {len(tr)} (user {ck['metrics']['user_takes_in_train']}) val {len(va)} "
          f"{ck['metrics']['val_sources']} bacc {best['bacc']:.3f} @ ep {best['epoch']} -> {out.name}", flush=True)
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["experiment", "report", "final"])
    ap.add_argument("--member", type=int, default=0)
    ap.add_argument("--with-user", type=int, default=1)
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args()
    torch.set_num_threads(a.threads)
    OUT.mkdir(parents=True, exist_ok=True)
    return {"experiment": cmd_experiment, "report": cmd_report, "final": cmd_final}[a.cmd](a)


if __name__ == "__main__":
    raise SystemExit(main())
