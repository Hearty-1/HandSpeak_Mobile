"""Targeted fixes: Bayang magiliw, Perlas ng Silanganan vs Ang kislap, merged line 11.

    python fix_lupang_lines.py experiment --model A|B --member M   # held-out experiment member
    python fix_lupang_lines.py report                              # experiment results
    python fix_lupang_lines.py final --model A|B --member M        # deployable member (all data)

Models (same architecture / recipe as the staged switch model palm_lupang_v8_switch):
  A  "original" component: reference clips + the user's older-session takes (no new takes)
  B  "user-adapted" component: A's data + the user's new takes + the user's LABELLED webcam
     tester attempts of Bayang magiliw and Perlas ng Silanganan (session 20261012_090256),
     the only user samples of those two lines
Both use lupang_common's merged class 10 ("May dilag ang tula at awit sa paglayang
minamahal"; class 11 retired) - the class definition changed, so both are retrained.
build_lupang_switch.py combines them as before, with lines 1 and 2 added to the user's
recorded lines.

Experiment split (no clip / attempt in two partitions):
  test_ref       reference signers SRC3, SRC9, bE63aZBXC_g held out completely (SRC3 and
                 bE63aZBXC_g signed the merged line)
  test_user_rec  last 30 % (recording order) of each line's new takes
  bp_even        even-numbered labelled Bayang / Perlas attempts of session 090256 (test);
                 odd-numbered ones are B's training samples in the experiment
  inferred       session 20261012_085620 attempts 002-006 (Bayang) and 011-014 (Perlas):
                 logged with a fixed target, labels inferred from the anthem order and their
                 similarity to the labelled attempts - never used for training
"""
import argparse
import glob
import json
import pickle
from pathlib import Path

import numpy as np
import torch

import lupang_common as lc
import retrain_lupang_grouped as R
import retrain_lupang_user as U
from test_lupang_recognition import load_captures

HERE = Path(__file__).resolve().parent
OUT = HERE / "cv_runs" / "fix_v9"
SESS = HERE / "reports" / "lupang_retrain" / "webcam_sessions"
LABELLED = "session_20261012_090256"
INFERRED = {"session_20261012_085620": {0: range(2, 7), 1: range(11, 15)}}
FIX_LINES = (0, 1)                 # Bayang magiliw, Perlas ng Silanganan
FINAL_NAME = "palm_lupang_v9_{model}_m{m}.pt"


def attempt_captures(session, keep):
    """Webcam tester attempts -> capture dicts. keep(n, target) -> label or None."""
    out = []
    for p in sorted(glob.glob(str(SESS / session / "attempt_*.json"))):
        a = json.loads(Path(p).read_text(encoding="utf-8"))
        n = int(Path(p).stem.split("_")[1])
        lab = keep(n, a["target_index"])
        if lab is None or not any(f["left_hand"] or f["right_hand"] for f in a["frames"]):
            continue
        aspect = a["image_width"] / a["image_height"]
        raw = np.stack([lc.raw_from_arrays(f["pose"], f["left_hand"], f["right_hand"], aspect) for f in a["frames"]])
        ts = np.array([f["t"] for f in a["frames"]], dtype=np.float64)
        if lc.clean_sequence(raw, ts - ts[0]) is None:
            continue
        out.append({"label": lab, "source": "webcam_take", "path": p, "raw": raw.astype(np.float32),
                    "ts": ts - ts[0], "attempt": n})
    return out


def labelled_bp(parity=None):
    """Labelled Bayang / Perlas attempts of LABELLED (parity 1 = odd, 0 = even, None = all)."""
    return attempt_captures(LABELLED, lambda n, t: t if t in FIX_LINES and (parity is None or n % 2 == parity) else None)


def inferred_bp():
    out = []
    for sess, runs in INFERRED.items():
        out += attempt_captures(sess, lambda n, t, runs=runs: next((lab for lab, r in runs.items() if n in r), None))
    return out


def labelled_other():
    """Labelled attempts of LABELLED for every line except Bayang / Perlas (never trained on)."""
    return attempt_captures(LABELLED, lambda n, t: t if t is not None and t not in FIX_LINES
                            and t not in lc.RETIRED_CLASSES else None)   # target 12 is ambiguous now


def split(caps):
    sp = {"test_ref": [], "test_user_rec": [], "train_ref": [], "train_user_new": []}
    new_by_line = {}
    for i, c in enumerate(caps):
        if c["source"] in U.TEST_REF_SOURCES:
            sp["test_ref"].append(i)
        elif U.is_new_take(c):
            new_by_line.setdefault(c["label"], []).append(i)
        else:
            sp["train_ref"].append(i)        # reference + older-session takes
    for idx in new_by_line.values():
        idx = sorted(idx, key=lambda i: U.take_time(caps[i]))
        k = max(1, int(round(U.USER_TEST_FRAC * len(idx))))
        sp["train_user_new"] += idx[:-k]
        sp["test_user_rec"] += idx[-k:]
    return sp


def score_complete(scorer, gate, caps_list):
    recs = []
    for c in caps_list:
        r = scorer.score(c["raw"], c["ts"], gate)
        r.update(scenario="complete line", kind="positive", label=c["label"], cap=-1, attempt=c.get("attempt"),
                 path=c["path"])
        recs.append(r)
    return recs


def train_model(caps, extra, train_idx, model, member, out, verbose):
    """Train on caps[train_idx] + extra capture dicts (user attempts)."""
    allcaps = caps + extra
    idx = list(train_idx) + list(range(len(caps), len(caps) + len(extra)))
    seed = 42 + 1000 * member
    tr, va = R.inner_split(allcaps, idx, np.random.default_rng(seed))
    best, _, _ = R.train_one(allcaps, tr, va, out, seed, verbose)
    gate = U.gate_for(allcaps, idx, 7)
    return best, gate, allcaps, tr, va


def cmd_experiment(a):
    caps = load_captures()
    sp = split(caps)
    OUT.mkdir(parents=True, exist_ok=True)
    extra = labelled_bp(parity=1) if a.model == "B" else []
    train = sp["train_ref"] + (sp["train_user_new"] if a.model == "B" else [])
    ckpt = OUT / f"{a.model}_m{a.member}.pt"
    best, gate, allcaps, tr, va = train_model(caps, extra, train, a.model, a.member, ckpt, a.verbose)
    scorer = R.Scorer(ckpt)
    recs = {k: R.score_set(scorer, gate, R.scenario_captures(caps, sp[k], 500)) for k in ("test_ref", "test_user_rec")}
    recs["bp_even"] = score_complete(scorer, gate, labelled_bp(parity=0))
    recs["inferred"] = score_complete(scorer, gate, inferred_bp())
    recs["live_other"] = score_complete(scorer, gate, labelled_other())
    with open(OUT / f"{a.model}_m{a.member}_scored.pkl", "wb") as fh:
        pickle.dump({"gate": gate, "best": best, "recs": recs, "n_extra": len(extra)}, fh)
    print(f"[{a.model} m{a.member}] train {len(tr)} (+{len(extra)} labelled Bayang/Perlas attempts) val {len(va)} "
          f"| bacc {best['bacc']:.3f} @ ep {best['epoch']}", flush=True)
    return 0


def switch_recs(ra, rb, recorded):
    rec = np.zeros(lc.NUM_CLASSES, bool)
    rec[list(recorded)] = True
    out = []
    for x, y in zip(ra, rb):
        m = dict(y)
        if x.get("probs") is not None and y.get("probs") is not None:
            v = np.where(rec[y["view_probs"].argmax(1)][:, None], y["view_probs"], x["view_probs"])
            m["view_probs"], m["probs"] = v, v[:2].mean(0)
        out.append(m)
    return out


def outcome_table(recs, gate):
    rows = {}
    for r in recs:
        if r["scenario"] != "complete line":
            continue
        acc, top, _ = R.decide(r, gate)
        p = r.get("probs")
        top1 = int(np.argmax(p)) if p is not None else -1
        d = rows.setdefault(r["label"], {"n": 0, "correct": 0, "wrong": 0, "wrong_as": {}, "nopred": 0,
                                         "top1_true": 0, "top1_ang_kislap": 0})
        d["n"] += 1
        d["top1_true"] += int(top1 == r["label"])
        d["top1_ang_kislap"] += int(top1 == 12)
        if acc and top == r["label"]:
            d["correct"] += 1
        elif acc:
            d["wrong"] += 1
            d["wrong_as"][lc.CLASS_NAMES[top]] = d["wrong_as"].get(lc.CLASS_NAMES[top], 0) + 1
        else:
            d["nopred"] += 1
    return rows


def cmd_report(a):
    # Previous (staged) recipe on the same split for comparison: merge_v8 A / B were trained without
    # the same reference sources but with UNMERGED classes and without the Bayang / Perlas attempts.
    new = {k: [pickle.load(open(OUT / f"{k}_m{m}_scored.pkl", "rb")) for m in range(3)] for k in "AB"}
    ra = {s: U._merge(new["A"], s) for s in new["A"][0]["recs"]}
    rb = {s: U._merge(new["B"], s) for s in new["B"][0]["recs"]}
    gate = new["B"][0]["gate"]
    rec_lines = sorted({c["label"] for c in [*load_captures()] if U.is_new_take(c) or c["source"] == "webcam_take"} | set(FIX_LINES))
    res = {}
    for s in rb:
        sw = switch_recs(ra[s], rb[s], rec_lines)
        res[s] = {"switch": outcome_table(sw, gate), "A": outcome_table(ra[s], new["A"][0]["gate"]),
                  "B": outcome_table(rb[s], gate)}
        if s in ("test_ref", "test_user_rec"):
            ev = U.evaluate(sw, gate)
            res[s]["switch_summary"] = U.summarize(ev)
    (OUT / "report.json").write_text(json.dumps(res, indent=2, default=float), encoding="utf-8")
    print("recorded lines for the switch:", [r + 1 for r in rec_lines])
    for s in ("bp_even", "inferred", "test_ref", "test_user_rec", "live_other"):
        print(f"\n=== {s} ===")
        if s in ("test_ref", "test_user_rec"):
            sm = res[s]["switch_summary"]
            print(f"  switch: complete n={sm['n']} correct {sm['correct']:.3f} wrong {sm['wrong']:.3f} "
                  f"no-pred {sm['no_pred']:.3f} | negatives accepted {sm['false_accept']:.3f}")
        for lab, d in sorted(res[s]["switch"].items()):
            if s in ("test_ref", "test_user_rec", "live_other") and lab not in (0, 1, 10, 12) and not a.all:
                continue
            print(f"  [{lab + 1:02d}] {lc.CLASS_NAMES[lab][:34]:<34} n={d['n']:2d} correct {d['correct']} wrong {d['wrong']} "
                  f"{d['wrong_as'] or ''} no-pred {d['nopred']} | top-1 true {d['top1_true']} top-1 Ang kislap {d['top1_ang_kislap']}")
    return 0


def cmd_final(a):
    caps = load_captures()
    extra = labelled_bp() if a.model == "B" else []
    train = [i for i, c in enumerate(caps) if a.model == "B" or not U.is_new_take(c)]
    out = HERE / FINAL_NAME.format(model=a.model, m=a.member)
    best, gate, allcaps, tr, va = train_model(caps, extra, train, a.model, a.member, out, a.verbose)
    ck = torch.load(out, map_location="cpu", weights_only=False)
    ck["metrics"].update(gate=gate, recipe=f"v9 {a.model} (merged line 11; Bayang/Perlas user attempts in B)",
                         train_clips=len(tr), val_sources=sorted({allcaps[i]["source"] for i in va}),
                         labelled_attempts=len(extra))
    torch.save(ck, out)
    if a.member == 0:
        (OUT / f"final_gate_{a.model}.json").write_text(json.dumps(gate, indent=2), encoding="utf-8")
    print(f"[final {a.model} m{a.member}] train {len(tr)} (+{len(extra)} attempts) bacc {best['bacc']:.3f} "
          f"@ ep {best['epoch']} -> {out.name}", flush=True)
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["experiment", "report", "final"])
    ap.add_argument("--model", choices=["A", "B"], default="B")
    ap.add_argument("--member", type=int, default=0)
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--all", action="store_true", help="report: print every line")
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args()
    torch.set_num_threads(a.threads)
    OUT.mkdir(parents=True, exist_ok=True)
    return {"experiment": cmd_experiment, "report": cmd_report, "final": cmd_final}[a.cmd](a)


if __name__ == "__main__":
    raise SystemExit(main())
