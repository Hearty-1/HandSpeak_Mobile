"""Merge the user's own webcam takes into the Lupang Hinirang model WITHOUT losing the lines
the user has not recorded.

    python merge_lupang_user.py train --approach A|B|C --member M     # experiment ensemble member
    python merge_lupang_user.py report                                # compare approaches
    python merge_lupang_user.py final --approach X --member M         # deployable member, all data

Why the plain retrain (B) regressed: the user's takes exist for 12 of 22 lines, so
"this webcam + this signer" becomes evidence for those 12 lines and the user's signing
of the other 10 loses confidence (top-1 still right, probability lower).

Experiment that reproduces this (no clip in two partitions):
  HOLD lines   Lupang hinirang, Sa simoy at sa langit, Tagumpay na nagniningning,
               Ang bituin at araw niya, Nang dahil sa 'yo: ALL of the user's takes of these
               lines are withheld from training -> test_user_unrecorded. They stand in for
               Bayang magiliw / Alab ng puso / ...: lines whose user version matches the
               reference signers' (arm-trajectory check) but that the model never saw the
               user sign.
  other lines  user's new takes: first 70 % (recording order) train, last 30 % -> test_user_recorded;
               older-session takes -> train
  reference    SRC3, SRC9, bE63aZBXC_g held out -> test_ref; the rest train
Approaches (3-member ensembles, members early-stopped on different reference sources):
  A  reference clips only (the original setup)
  B  A + the user's takes (the regressed retrain)
  C  B + one webcam-like copy (lupang_degrade.py) of every REFERENCE clip, all 22 lines,
     so the webcam look appears in every line and stops pointing at the recorded ones
  A+B  probability average of the A and B ensembles (no training)
All decisions: full live gate with the staged thresholds (min_conf 0.65, min_margin 0.65).
"""
import argparse
import json
import os
import pickle
from collections import Counter
from pathlib import Path

import numpy as np
import torch

import lupang_common as lc
import retrain_lupang_grouped as R
import retrain_lupang_user as U
from test_lupang_recognition import load_captures

HERE = Path(__file__).resolve().parent
OUT = HERE / "cv_runs" / "merge_v8"
HOLD = (4, 9, 13, 14, 21)
DEGRADE_COPIES = {"A": 0, "B": 0, "C": 1}
FINAL_NAME = "palm_lupang_v8_{approach}_m{m}.pt"


def split(caps):
    sp = {k: [] for k in ("test_user_unrecorded", "test_user_recorded", "test_ref", "train_ref", "train_user")}
    new_by_line = {}
    for i, c in enumerate(caps):
        if c["source"] == "webcam_take":
            if c["label"] in HOLD:
                sp["test_user_unrecorded"].append(i)
            elif U.is_new_take(c):
                new_by_line.setdefault(c["label"], []).append(i)
            else:
                sp["train_user"].append(i)
        elif c["source"] in U.TEST_REF_SOURCES:
            sp["test_ref"].append(i)
        else:
            sp["train_ref"].append(i)
    for idx in new_by_line.values():
        idx = sorted(idx, key=lambda i: U.take_time(caps[i]))
        k = max(1, int(round(U.USER_TEST_FRAC * len(idx))))
        sp["train_user"] += idx[:-k]
        sp["test_user_recorded"] += idx[-k:]
    return {k: sorted(v) for k, v in sp.items()}


def train_member(caps, train, ref_idx, approach, member, out, verbose):
    seed = 42 + 1000 * member
    tr, va = R.inner_split(caps, train, np.random.default_rng(seed))
    ref_tr = [i for i in tr if i in set(ref_idx)]
    best, _, _ = R.train_one(caps, tr, va, out, seed, verbose,
                             degrade_idx=ref_tr, degrade=DEGRADE_COPIES[approach])
    return best, tr, va


def cmd_train(a):
    caps = load_captures()
    sp = split(caps)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "split.json").write_text(json.dumps({k: [caps[i]["path"] for i in v] for k, v in sp.items()}, indent=1),
                                    encoding="utf-8")
    train = sp["train_ref"] + ([] if a.approach == "A" else sp["train_user"])
    ckpt = OUT / f"{a.approach}_m{a.member}.pt"
    best, tr, va = train_member(caps, train, sp["train_ref"], a.approach, a.member, ckpt, a.verbose)
    gate = U.gate_for(caps, train, 7)
    scorer = R.Scorer(ckpt)
    recs = {k: R.score_set(scorer, gate, R.scenario_captures(caps, sp[k], 500))
            for k in ("test_user_unrecorded", "test_user_recorded", "test_ref")}
    with open(OUT / f"{a.approach}_m{a.member}_scored.pkl", "wb") as fh:
        pickle.dump({"gate": gate, "best": best, "recs": recs}, fh)
    print(f"[{a.approach} m{a.member}] train {len(tr)} (user {sum(caps[i]['source'] == 'webcam_take' for i in tr)}) "
          f"val {len(va)} | bacc {best['bacc']:.3f} @ ep {best['epoch']}", flush=True)
    return 0


def _load(approach):
    parts = []
    for m in range(3):
        p = OUT / f"{approach}_m{m}_scored.pkl"
        if p.exists():
            with open(p, "rb") as fh:
                parts.append(pickle.load(fh))
    return parts


def cmd_report(a):
    ens = {k: _load(k) for k in "ABC"}
    ens = {k: v for k, v in ens.items() if len(v) == 3}
    merged = {k: {s: U._merge(v, s) for s in ("test_user_unrecorded", "test_user_recorded", "test_ref")}
              for k, v in ens.items()}
    gates = {k: v[0]["gate"] for k, v in ens.items()}
    if "A" in merged and "B" in merged:
        avg = {}
        for s in merged["A"]:
            out = []
            for ra, rb in zip(merged["A"][s], merged["B"][s]):
                m = dict(rb)
                if ra.get("probs") is not None and rb.get("probs") is not None:
                    m["probs"] = (ra["probs"] + rb["probs"]) / 2
                    m["view_probs"] = (ra["view_probs"] + rb["view_probs"]) / 2
                out.append(m)
            avg[s] = out
        merged["A+B"], gates["A+B"] = avg, gates["B"]
    res = {}
    titles = {"test_user_unrecorded": "YOUR lines the model never saw you sign (stand-in for Bayang, Alab, ...)",
              "test_user_recorded": "YOUR later takes of lines you recorded",
              "test_ref": "3 unseen reference signers"}
    for s, title in titles.items():
        print(f"\n=== {title} ===")
        for k in merged:
            ev = U.evaluate(merged[k][s], gates[k])
            sm = U.summarize(ev)
            res.setdefault(k, {})[s] = {"summary": sm, "per_line": {lc.CLASS_NAMES[c]: dict(v) for c, v in ev["lines"].items()}}
            print(f"  {k:<4} complete lines n={sm['n']:3d}: correct {sm['correct']:.3f} wrong {sm['wrong']:.3f} "
                  f"no-pred {sm['no_pred']:.3f} | top-1 right {sm['closed_acc']:.3f} | mean P(true) {sm['mean_p_true']:.3f} "
                  f"| negatives accepted {sm['false_accept']:.3f} (n={sm['n_neg']})")
    print("\nper line, YOUR unrecorded stand-in lines (correct/n, mean P(true)):")
    for c in HOLD:
        name = lc.CLASS_NAMES[c]
        print(f"  {name[:30]:<30} " + "   ".join(
            f"{k}: {res[k]['test_user_unrecorded']['per_line'].get(name, {}).get('correct', 0)}/"
            f"{res[k]['test_user_unrecorded']['per_line'].get(name, {}).get('n', 0)} "
            f"{res[k]['test_user_unrecorded']['per_line'].get(name, {}).get('p_true', 0) / max(res[k]['test_user_unrecorded']['per_line'].get(name, {}).get('n', 1), 1):.2f}"
            for k in res))
    (OUT / "report.json").write_text(json.dumps(res, indent=2, default=float), encoding="utf-8")
    return 0


def cmd_final(a):
    """Deployable member on ALL valid clips with the chosen approach."""
    caps = load_captures()
    ref = [i for i, c in enumerate(caps) if c["source"] != "webcam_take"]
    user = [i for i, c in enumerate(caps) if c["source"] == "webcam_take"]
    train = ref + ([] if a.approach == "A" else user)
    out = HERE / FINAL_NAME.format(approach=a.approach, m=a.member)
    best, tr, va = train_member(caps, train, ref, a.approach, a.member, out, a.verbose)
    gate = U.gate_for(caps, train, 7)
    ck = torch.load(out, map_location="cpu", weights_only=False)
    ck["metrics"].update(gate=gate, recipe=f"v8 merge approach {a.approach}", train_clips=len(tr),
                         val_sources=sorted({caps[i]["source"] for i in va}),
                         user_takes_in_train=sum(caps[i]["source"] == "webcam_take" for i in tr),
                         degrade_copies_of_reference=DEGRADE_COPIES[a.approach])
    torch.save(ck, out)
    if a.member == 0:
        (OUT / f"final_gate_{a.approach}.json").write_text(json.dumps(gate, indent=2), encoding="utf-8")
    print(f"[final {a.approach} m{a.member}] train {len(tr)} (user {ck['metrics']['user_takes_in_train']}) "
          f"bacc {best['bacc']:.3f} @ ep {best['epoch']} -> {out.name}", flush=True)
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["train", "report", "final"])
    ap.add_argument("--approach", choices=["A", "B", "C"], default="C")
    ap.add_argument("--member", type=int, default=0)
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args()
    torch.set_num_threads(a.threads)
    OUT.mkdir(parents=True, exist_ok=True)
    return {"train": cmd_train, "report": cmd_report, "final": cmd_final}[a.cmd](a)


if __name__ == "__main__":
    raise SystemExit(main())
