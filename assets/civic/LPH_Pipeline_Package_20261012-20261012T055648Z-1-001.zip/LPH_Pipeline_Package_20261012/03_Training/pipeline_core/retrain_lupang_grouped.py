"""Source-grouped retraining, threshold calibration and evaluation of the
Lupang Hinirang recognizer (recipe v5 of cv_lupang.py).

    python retrain_lupang_grouped.py cv [--folds 5] [--only-fold F]   # outer folds
    python retrain_lupang_grouped.py calibrate                        # thresholds from INNER validation
    python retrain_lupang_grouped.py evaluate                         # held-out TEST metrics + scenarios
    python retrain_lupang_grouped.py final                            # deployable model on all valid clips

Data split (no source / signer is ever on both sides of a split):
    outer   the valid clips' sources (YouTube videos, SRCn signers, the
            webcam takes) are assigned to --folds test folds; sources of the
            rarest lines are spread over different folds first.
    inner   inside each outer training part, whole sources (~15 % of clips)
            form the validation set used for early stopping AND for threshold
            calibration; a source is only moved there if every line keeps
            >= 2 training clips.
    test    the outer fold: used only by `evaluate`, never for any choice.
Synthetic INVALID_GESTURE samples are built separately from the training,
validation and test sources (cv_lupang.build_training_set), so no part of a
held-out clip reaches training.

`cv` stores, per fold, the checkpoint plus scored captures (probabilities,
kinematics, durations, coverage) of the inner-validation and test sources:
complete lines and the raw-landmark negative scenarios of
test_lupang_recognition. `calibrate` replays the exact live decision
(lupang_common.evaluate_capture logic) over a threshold grid on the
inner-validation captures only. `evaluate` applies the calibrated gate to the
test captures (per-line precision / recall / F1, confusion matrix,
calibration) and re-runs the full scenario suite through
lupang_common.evaluate_capture with each fold's checkpoint.
"""
import argparse
import json
import pickle
import time
from collections import Counter
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

import lupang_common as lc
import train_lupang_model as t
from cv_lupang import RECIPES as BASE_RECIPES, TRAIN_ARGS, build_training_set
from extract_lupang_dataset import make_clip, make_negatives
from lupang_degrade import degrade_capture
from test_lupang_recognition import (CheckpointDecider, load_captures, negatives, positives, run_suite,
                                     summarize)

HERE = Path(__file__).resolve().parent
# v6: v5 + each training clip also seen as `degrade` webcam-like copies (lupang_degrade.py:
#     ~20 fps, motion-correlated hand-detection misses), with synthetic negatives built from
#     those copies too. v6p: v6 + pair penalty for Ang bituin at araw niya (14) vs Tagumpay
#     na nagniningning (13), the dominant confusion on held-out signers.
RECIPES = {**BASE_RECIPES,
           "v6": {**BASE_RECIPES["v5"], "degrade": 2},
           "v6p": {**BASE_RECIPES["v5"], "degrade": 2, "pairs": "14:13"}}
RECIPE = RECIPES["v5"]
OUT = HERE / "cv_runs" / "v5_grouped"
FINAL_CKPT = HERE / "palm_lupang_v5.pt"
# Initial acceptance requirements (task spec): calibration may only raise them.
FLOOR = {"min_conf": 0.65, "min_margin": 0.20}
TARGET_WRONG = 0.02          # accepted-but-wrong share of real lines allowed on inner validation
TARGET_FALSE = 0.02          # accepted share of negative scenarios allowed on inner validation
# Train args of cv_lupang's recipe, but no hand-picked confusable pairs: those
# pairs were chosen from the old (stratified, leaky) validation results.
ARGS = {**TRAIN_ARGS, "confusable_pairs": ""}


# ---------------------------------------------------------------------------
# Splits
# ---------------------------------------------------------------------------
def assign_folds(caps, k):
    """Deterministic source -> outer fold. Sources carrying lines that occur in
    few sources go first, each to the fold with the fewest sources of those
    lines, then by load (clips)."""
    src_lines, src_n = {}, Counter()
    for c in caps:
        src_lines.setdefault(c["source"], set()).add(c["label"])
        src_n[c["source"]] += 1
    line_src = Counter(lab for labs in src_lines.values() for lab in labs)
    rarity = {s: min(line_src[lab] for lab in labs) for s, labs in src_lines.items()}
    folds, load, lines = [[] for _ in range(k)], [0] * k, [Counter() for _ in range(k)]
    for s in sorted(src_lines, key=lambda s: (rarity[s], -src_n[s], s)):
        rare = [lab for lab in src_lines[s] if line_src[lab] <= k]
        j = min(range(k), key=lambda f: (sum(lines[f][lab] for lab in rare), load[f], f))
        folds[j].append(s)
        load[j] += src_n[s]
        lines[j].update(src_lines[s])
    return folds


def inner_split(caps, idx, rng, frac=0.15, min_train=2):
    """Split capture indices `idx` into (train, val) by whole sources."""
    per_src = {}
    for i in idx:
        per_src.setdefault(caps[i]["source"], []).append(i)
    count = Counter(caps[i]["label"] for i in idx)
    srcs = sorted(per_src)
    rng.shuffle(srcs)
    val = []
    for s in srcs:
        if len(val) >= frac * len(idx):
            break
        # A source larger than the whole validation share (the user's own webcam
        # takes: 264 of 585 clips) would take that data out of training entirely.
        if len(per_src[s]) > frac * len(idx):
            continue
        lab = Counter(caps[i]["label"] for i in per_src[s])
        if all(count[c] - n >= min_train for c, n in lab.items()):
            val += per_src[s]
            count.subtract(lab)
    val_set = set(val)
    return [i for i in idx if i not in val_set], sorted(val_set)


def fold_gate(X_tr, y_tr, durs_tr):
    gate = {**lc.GATE_DEFAULTS, **lc.LUPANG_RELIABILITY, "trim_still": RECIPE["trim_still"],
            **lc.calibrate_kinematics(X_tr[y_tr != lc.INVALID_IDX])}
    gate["class_min_duration"] = lc.calibrate_class_durations(durs_tr, y_tr)
    return gate


# ---------------------------------------------------------------------------
# Scoring captures once, deciding offline for any thresholds
# ---------------------------------------------------------------------------
class Scorer:
    def __init__(self, ckpt):
        self.model, _ = lc.load_model(ckpt)

    def probs(self, batch):
        with torch.no_grad():
            return torch.softmax(self.model(torch.from_numpy(np.asarray(batch, np.float32))), 1).numpy()

    def score(self, raw, ts, gate):
        """Everything evaluate_capture computes, with the classifier always run
        (so a later threshold change needs no new inference)."""
        seq, info = lc.build_sequence_with_info(raw, ts, trim_still=bool(gate.get("trim_still")))
        rec = {"seq": seq, "info": {k: v for k, v in info.items() if not k.startswith("_")}}
        if seq is None:
            return rec
        extra = lc.stability_views(info, gate) if gate.get("stability") else []
        allp = self.probs(np.stack([seq, lc.mirror_features(seq)] + extra))
        rec.update(probs=allp[:2].mean(0), view_probs=allp, n_extra=len(extra))
        return rec


def decide(rec, gate):
    """lupang_common.evaluate_capture's decision from a Scorer record.
    Returns (accepted, top or None, failed codes)."""
    seq, info = rec["seq"], rec["info"]
    if seq is None:
        return False, None, ["NO_HANDS"]
    pre = lc.duration_gate(info, gate) + lc.coverage_gate(info, gate) + lc.kinematic_gate(seq, gate)[0]
    if not all(c.passed for c in pre):
        return False, None, lc.failed_codes(pre)
    probs = rec["probs"]
    top = int(np.argmax(probs))
    accepted, failed, _ = lc.gate_decision(seq, probs, gate, info)
    if gate.get("stability"):
        st = (lc.stability_check(rec["view_probs"], top, gate) if rec["n_extra"] else
              lc.Check("UNSTABLE", "Stability", 0.0, 1.0, ">=", False, "too short"))
        if not st.passed:
            accepted = False
            failed = failed + ["UNSTABLE"]
    return accepted, top, failed


def scenario_captures(caps, idx, seed):
    """(scenario, kind, label, raw, ts) for complete lines and every
    raw-landmark scenario of test_lupang_recognition, built from caps[idx]."""
    by_source = {}
    for c in caps:
        by_source.setdefault(c["source"], []).append(c)
    out = []
    for kind, builders in (("positive", positives()), ("negative", negatives())):
        for name, build in builders.items():
            scored = "partial" if name == "less active hand never detected" else kind
            rng = np.random.default_rng(seed)
            for i in idx:
                c = caps[i]
                for raw, ts in build(c, by_source[c["source"]], rng):
                    out.append({"scenario": name, "kind": scored, "label": c["label"], "cap": int(i),
                                "raw": raw, "ts": ts})
    return out


def score_set(scorer, gate, captures):
    recs = []
    for cap in captures:
        r = scorer.score(cap["raw"], cap["ts"], gate)
        r.update({k: cap[k] for k in ("scenario", "kind", "label", "cap")})
        recs.append(r)
    return recs


# ---------------------------------------------------------------------------
# cv
# ---------------------------------------------------------------------------
def degraded_training_set(caps, idx, recipe, rng):
    """`recipe["degrade"]` webcam-like copies of each clip + proportional synthetic
    negatives built from those copies (same sources, so no cross-split leakage)."""
    clips = []
    for i in idx:
        c = caps[i]
        for _ in range(recipe["degrade"]):
            raw, ts = degrade_capture(c["raw"], c["ts"], rng)
            clip = make_clip(c["path"], c["label"], raw, ts, recipe["trim_still"])
            if clip is not None:
                clips.append(clip)
    n_neg = int(round(recipe["neg_count"] * len(clips) / len(caps)))
    nX, _, _ = make_negatives(rng, clips, n_neg, recipe["neg_mix"])
    X = np.stack([c["seq"] for c in clips] + nX).astype(np.float32)
    y = np.array([c["label"] for c in clips] + [lc.INVALID_IDX] * len(nX), dtype=np.int64)
    return X, y


def train_one(caps, tr_idx, va_idx, out, seed, verbose, degrade_idx=None, degrade=0):
    """degrade_idx / degrade: additionally train on `degrade` webcam-like copies of
    caps[degrade_idx] only (e.g. just the reference clips), independent of RECIPE."""
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    X_tr, y_tr, d_tr = build_training_set(caps, tr_idx, RECIPE, np.random.default_rng(seed))
    X_va, y_va, _ = build_training_set(caps, va_idx, RECIPE, np.random.default_rng(seed + 1000))
    gate = fold_gate(X_tr, y_tr, d_tr)          # calibrated on the clean clips only
    if RECIPE.get("degrade"):
        X_d, y_d = degraded_training_set(caps, tr_idx, RECIPE, np.random.default_rng(seed + 2000))
        X_tr, y_tr = np.concatenate([X_tr, X_d]), np.concatenate([y_tr, y_d])
    if degrade_idx and degrade:
        X_d, y_d = degraded_training_set(caps, degrade_idx, {**RECIPE, "degrade": degrade},
                                         np.random.default_rng(seed + 3000))
        X_tr, y_tr = np.concatenate([X_tr, X_d]), np.concatenate([y_tr, y_d])
    args = SimpleNamespace(**ARGS, out=Path(out), seed=seed)
    best = t.train_model(X_tr, y_tr, X_va, y_va, args, gate, rng, torch.device("cpu"), verbose=verbose)
    counts = {"train": np.bincount(y_tr, minlength=lc.NUM_CLASSES).tolist(),
              "val": np.bincount(y_va, minlength=lc.NUM_CLASSES).tolist()}
    return best, gate, counts


def cmd_cv(a):
    caps = load_captures()
    folds = assign_folds(caps, a.folds)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "folds.json").write_text(json.dumps(folds, indent=2), encoding="utf-8")
    for f, srcs in enumerate(folds):
        if a.only_fold is not None and f != a.only_fold:
            continue
        t0 = time.time()
        test = [i for i, c in enumerate(caps) if c["source"] in srcs]
        rest = [i for i, c in enumerate(caps) if c["source"] not in srcs]
        # Ensemble member M: own seed, so its inner validation holds out OTHER
        # sources; member 0 is the original single model.
        seed = a.seed + f + 1000 * a.member
        suffix = "" if a.member == 0 else f"_m{a.member}"
        tr, va = inner_split(caps, rest, np.random.default_rng(seed))
        ckpt = OUT / f"fold{f}{suffix}.pt"
        best, gate, counts = train_one(caps, tr, va, ckpt, seed, a.verbose)
        scorer = Scorer(ckpt)
        val_recs = score_set(scorer, gate, scenario_captures(caps, va, seed))
        # Test captures are identical for every member (same seed), so members can be averaged.
        test_recs = score_set(scorer, gate, scenario_captures(caps, test, a.seed + 100 + f))
        meta = {"fold": f, "member": a.member, "test_sources": srcs,
                "val_sources": sorted({caps[i]["source"] for i in va}),
                "train_sources": sorted({caps[i]["source"] for i in tr}),
                "n": {"train_clips": len(tr), "val_clips": len(va), "test_clips": len(test)},
                "per_line": {"train": np.bincount([caps[i]["label"] for i in tr], minlength=22).tolist(),
                             "val": np.bincount([caps[i]["label"] for i in va], minlength=22).tolist(),
                             "test": np.bincount([caps[i]["label"] for i in test], minlength=22).tolist()},
                "with_negatives": counts, "best": best, "gate": gate}
        with open(OUT / f"fold{f}{suffix}_scored.pkl", "wb") as fh:
            pickle.dump({"meta": meta, "val": val_recs, "test": test_recs}, fh)
        (OUT / f"fold{f}{suffix}.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        print(f"[fold {f}] test {srcs} | train {len(tr)} val {len(va)} test {len(test)} clips | "
              f"inner-val bacc {best['bacc']:.3f} @ ep {best['epoch']} | {time.time() - t0:.0f}s", flush=True)
    return 0


# ---------------------------------------------------------------------------
# calibrate
# ---------------------------------------------------------------------------
def load_folds():
    out = []
    for p in sorted(OUT.glob("fold?_scored.pkl")):        # member 0 = the single model
        with open(p, "rb") as fh:
            out.append(pickle.load(fh))
    if not out:
        raise SystemExit(f"no scored folds in {OUT}; run `cv` first")
    return out


def rates(folds, split, overrides):
    """Decision rates of the gate (each fold's own calibrated gate + overrides)."""
    n = Counter()
    for fd in folds:
        gate = {**fd["meta"]["gate"], **overrides}
        for r in fd[split]:
            acc, top, _ = decide(r, gate)
            k = r["kind"]
            n[k] += 1
            if acc:
                n[f"{k}_acc"] += 1
                n[f"{k}_ok" if top == r["label"] else f"{k}_wrong"] += 1
            if r["scenario"] == "complete line":
                n["complete"] += 1
                n["complete_ok"] += int(acc and top == r["label"])
                n["complete_wrong"] += int(acc and top != r["label"])
    p = max(n["positive"], 1)
    return {"tar": n["positive_ok"] / p, "war": n["positive_wrong"] / p,
            "far": n["negative_acc"] / max(n["negative"], 1),
            "partial_wrong": n["partial_wrong"] / max(n["partial"], 1),
            "complete_tar": n["complete_ok"] / max(n["complete"], 1),
            "complete_war": n["complete_wrong"] / max(n["complete"], 1),
            "n_pos": n["positive"], "n_neg": n["negative"], "n_complete": n["complete"]}


def ece(conf, correct, bins=10):
    conf, correct = np.asarray(conf), np.asarray(correct, float)
    edges = np.linspace(0, 1, bins + 1)
    e, table = 0.0, []
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        if m.any():
            e += m.mean() * abs(conf[m].mean() - correct[m].mean())
            table.append({"bin": f"{lo:.1f}-{hi:.1f}", "n": int(m.sum()),
                          "mean_conf": float(conf[m].mean()), "accuracy": float(correct[m].mean())})
    return float(e), table


def cmd_calibrate(a):
    folds = load_folds()
    grid = []
    for conf in np.round(np.arange(0.50, 0.96, 0.05), 2):
        for margin in np.round(np.arange(0.10, 0.81, 0.05), 2):
            r = rates(folds, "val", {"min_conf": float(conf), "min_margin": float(margin)})
            grid.append({"min_conf": float(conf), "min_margin": float(margin), **r})
    feasible = [g for g in grid if g["min_conf"] >= FLOOR["min_conf"] and g["min_margin"] >= FLOOR["min_margin"]
                and g["war"] <= TARGET_WRONG and g["far"] <= TARGET_FALSE]
    floor = next(g for g in grid if g["min_conf"] == FLOOR["min_conf"] and g["min_margin"] == FLOOR["min_margin"])
    if feasible:
        chosen = max(feasible, key=lambda g: (g["tar"], -g["min_conf"], -g["min_margin"]))
        status = "targets met on inner validation"
    else:
        ok_floor = [g for g in grid if g["min_conf"] >= FLOOR["min_conf"] and g["min_margin"] >= FLOOR["min_margin"]]
        chosen = min(ok_floor, key=lambda g: (g["war"] + g["far"], -g["tar"]))
        status = (f"NO setting >= the floors reaches wrong <= {TARGET_WRONG:.0%} and false accept <= "
                  f"{TARGET_FALSE:.0%} on inner validation; chose the lowest wrong+false rate")
    below = [g for g in grid if (g["min_conf"] < FLOOR["min_conf"] or g["min_margin"] < FLOOR["min_margin"])
             and g["war"] <= TARGET_WRONG and g["far"] <= TARGET_FALSE and g["tar"] > chosen["tar"] + 0.02]
    # Confidence calibration of the raw classifier on inner-validation complete lines.
    conf, correct = [], []
    for fd in folds:
        for r in fd["val"]:
            if r["scenario"] == "complete line" and r.get("probs") is not None:
                conf.append(float(r["probs"].max()))
                correct.append(int(np.argmax(r["probs"]) == r["label"]))
    e, table = ece(conf, correct)
    # Duration floors: fraction of complete inner-val lines the per-line floor would reject.
    dur_fail, frag_pass = Counter(), Counter()
    for fd in folds:
        g = fd["meta"]["gate"]
        for r in fd["val"]:
            if r["seq"] is None:
                continue
            fl = g["class_min_duration"][r["label"]]
            if r["scenario"] == "complete line":
                dur_fail["n"] += 1
                dur_fail["fail"] += int(r["info"]["duration_s"] < fl)
            elif r["scenario"].startswith("incomplete"):
                frag_pass["n"] += 1
                frag_pass["pass"] += int(r["info"]["duration_s"] >= fl)
    out = {"status": status, "chosen": chosen, "floor_setting": floor,
           "lower_than_floor_but_better": below[:10], "targets": {"wrong": TARGET_WRONG, "false": TARGET_FALSE},
           "inner_val_ece": e, "reliability": table, "n_inner_val_complete": len(conf),
           "duration_floor": {"complete_lines_below_floor": dur_fail["fail"] / max(dur_fail["n"], 1),
                              "n_complete": dur_fail["n"],
                              "fragments_at_or_above_floor": frag_pass["pass"] / max(frag_pass["n"], 1),
                              "n_fragments": frag_pass["n"]},
           "grid": grid}
    (OUT / "calibration.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(status)
    print(f"floor   conf {FLOOR['min_conf']:.2f} margin {FLOOR['min_margin']:.2f}: "
          + "  ".join(f"{k}={floor[k]:.3f}" for k in ("tar", "war", "far", "complete_tar", "complete_war")))
    print(f"chosen  conf {chosen['min_conf']:.2f} margin {chosen['min_margin']:.2f}: "
          + "  ".join(f"{k}={chosen[k]:.3f}" for k in ("tar", "war", "far", "complete_tar", "complete_war")))
    print(f"inner-val ECE {e:.3f} on {len(conf)} complete lines; reliability: "
          + ", ".join(f"{b['bin']} n={b['n']} conf={b['mean_conf']:.2f} acc={b['accuracy']:.2f}" for b in table))
    print("duration floors:", out["duration_floor"])
    if below:
        print(f"{len(below)} settings BELOW the floors would also meet the targets with >2 pt more correct accepts, "
              f"e.g. {below[0]['min_conf']:.2f}/{below[0]['min_margin']:.2f} tar={below[0]['tar']:.3f}")
    return 0


# ---------------------------------------------------------------------------
# evaluate
# ---------------------------------------------------------------------------
def prf(y_true, y_pred, labels):
    rows = []
    for c in labels:
        tp = int(np.sum((y_pred == c) & (y_true == c)))
        fp = int(np.sum((y_pred == c) & (y_true != c)))
        fn = int(np.sum((y_pred != c) & (y_true == c)))
        p = tp / (tp + fp) if tp + fp else 0.0
        r = tp / (tp + fn) if tp + fn else 0.0
        rows.append({"index": int(c), "line": lc.CLASS_NAMES[c], "support": tp + fn, "precision": p, "recall": r,
                     "f1": 2 * p * r / (p + r) if p + r else 0.0, "tp": tp, "fp": fp, "fn": fn})
    return rows


def cmd_evaluate(a):
    folds = load_folds()
    cal = json.loads((OUT / "calibration.json").read_text(encoding="utf-8"))
    over = {k: cal["chosen"][k] for k in ("min_conf", "min_margin")}
    over["min_margin_vs_invalid"] = over["min_margin"]
    NOPRED = 22                                   # "no prediction" column (INVALID or gate rejection)
    y_true, closed, gated, conf, correct = [], [], [], [], []
    for fd in folds:
        gate = {**fd["meta"]["gate"], **over}
        for r in fd["test"]:
            if r["scenario"] != "complete line":
                continue
            acc, top, failed = decide(r, gate)
            y_true.append(r["label"])
            p = r.get("probs")
            closed.append(int(np.argmax(p[:lc.INVALID_IDX])) if p is not None else NOPRED)
            gated.append(top if acc else NOPRED)
            if p is not None:
                conf.append(float(p.max()))
                correct.append(int(np.argmax(p) == r["label"]))
    y_true, closed, gated = map(np.array, (y_true, closed, gated))
    labels = list(range(lc.INVALID_IDX))
    cm = np.zeros((22, 23), dtype=int)
    for tt, pp in zip(y_true, gated):
        cm[tt, pp] += 1
    cm_closed = np.zeros((22, 22), dtype=int)
    for tt, pp in zip(y_true, closed):
        if pp < 22:
            cm_closed[tt, pp] += 1
    e, table = ece(conf, correct)
    conf_pairs = Counter()
    for tt, pp in zip(y_true, closed):
        if pp != tt and pp < 22:
            conf_pairs[(int(tt), int(pp))] += 1
    rates_test = rates(folds, "test", over)
    scen = {}
    for fd in folds:
        gate = {**fd["meta"]["gate"], **over}
        for r in fd["test"]:
            s = scen.setdefault(r["scenario"], {"kind": r["kind"], "n": 0, "correct": 0, "wrong": 0, "abstain": 0,
                                                "reasons": Counter()})
            acc, top, failed = decide(r, gate)
            s["n"] += 1
            if acc:
                s["correct" if top == r["label"] else "wrong"] += 1
            else:
                s["abstain"] += 1
                if failed:
                    s["reasons"][failed[0]] += 1
    for s in scen.values():
        s["reasons"] = dict(s["reasons"])
    out = {"thresholds": over, "n_test_complete": int(len(y_true)),
           "closed_set": {"accuracy": float(np.mean(closed == y_true)), "per_line": prf(y_true, closed, labels),
                          "confusion": cm_closed.tolist()},
           "gated": {"accepted_correct": float(np.mean(gated == y_true)),
                     "accepted_wrong": float(np.mean((gated != y_true) & (gated != NOPRED))),
                     "no_prediction": float(np.mean(gated == NOPRED)),
                     "per_line": prf(y_true, gated, labels), "confusion_with_nopred": cm.tolist()},
           "top_confusions_closed": [{"true": lc.CLASS_NAMES[tt], "pred": lc.CLASS_NAMES[pp], "n": k}
                                     for (tt, pp), k in conf_pairs.most_common(12)],
           "test_ece": e, "reliability": table, "scenario_rates": rates_test, "scenarios": scen}
    (OUT / "evaluation.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"TEST complete lines n={len(y_true)}  closed-set acc {out['closed_set']['accuracy']:.3f}  "
          f"gated: correct {out['gated']['accepted_correct']:.3f} wrong {out['gated']['accepted_wrong']:.3f} "
          f"no-pred {out['gated']['no_prediction']:.3f}  ECE {e:.3f}")
    for name, s in scen.items():
        n = max(s["n"], 1)
        print(f"  {name:<40} {s['kind']:<8} n={s['n']:4d} correct {s['correct'] / n:6.1%} "
              f"wrong {s['wrong'] / n:5.1%} abstain {s['abstain'] / n:6.1%}")
    if a.suite:
        # Cross-check: the real evaluate_capture path with each fold's checkpoint.
        caps = load_captures()
        folds_src = json.loads((OUT / "folds.json").read_text(encoding="utf-8"))
        total = []
        for f, srcs in enumerate(folds_src):
            test = [i for i, c in enumerate(caps) if c["source"] in srcs]
            dec = CheckpointDecider(OUT / f"fold{f}.pt", gate_overrides=over)
            res = run_suite(dec, caps, test, seed=a.seed + 100 + f, calendar=(f == 0), verbose=False)
            total.append(res)
            print(f"[suite fold {f}] " + "  ".join(f"{k}={v:.3f}" for k, v in summarize(res).items()
                                                  if isinstance(v, float)), flush=True)
        (OUT / "suite.json").write_text(json.dumps(total, indent=2), encoding="utf-8")
    return 0


# ---------------------------------------------------------------------------
# final
# ---------------------------------------------------------------------------
def cmd_final(a):
    caps = load_captures()
    cal = json.loads((OUT / "calibration.json").read_text(encoding="utf-8"))
    tr, va = inner_split(caps, list(range(len(caps))), np.random.default_rng(a.seed))
    best, gate, counts = train_one(caps, tr, va, a.out, a.seed, a.verbose)
    gate.update(min_conf=cal["chosen"]["min_conf"], min_margin=cal["chosen"]["min_margin"],
                min_margin_vs_invalid=cal["chosen"]["min_margin"])
    ckpt = torch.load(a.out, map_location="cpu", weights_only=False)
    ckpt["metrics"].update(gate=gate, split="source-grouped (inner validation = held-out sources)",
                           val_sources=sorted({caps[i]["source"] for i in va}),
                           recipe="v5", train_clips=len(tr), val_clips=len(va),
                           cv_summary=str(OUT / "evaluation.json"))
    torch.save(ckpt, a.out)
    scorer = Scorer(a.out)
    recs = score_set(scorer, gate, scenario_captures(caps, va, a.seed))
    r = rates([{"meta": {"gate": gate}, "val": recs}], "val", {})
    meta = {"best": best, "gate": gate, "val_sources": sorted({caps[i]["source"] for i in va}),
            "per_line": {"train": np.bincount([caps[i]["label"] for i in tr], minlength=22).tolist(),
                         "val": np.bincount([caps[i]["label"] for i in va], minlength=22).tolist()},
            "with_negatives": counts, "val_rates": r}
    name = "final.json" if a.out == FINAL_CKPT else f"final_{a.out.stem}.json"   # one file per ensemble member
    (OUT / name).write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"final: {len(tr)} train / {len(va)} val clips, val sources {meta['val_sources']}, "
          f"bacc {best['bacc']:.3f} @ ep {best['epoch']} -> {a.out}")
    print("inner-val rates with final gate: " + "  ".join(f"{k}={v:.3f}" for k, v in r.items() if isinstance(v, float)))
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["cv", "calibrate", "evaluate", "final"])
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--only-fold", type=int)
    ap.add_argument("--member", type=int, default=0, help="cv: ensemble member (0 = the original single model)")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--threads", type=int, default=2)
    ap.add_argument("--suite", action="store_true", help="evaluate: also run the scenario suite end to end")
    ap.add_argument("--out", type=Path, default=FINAL_CKPT)
    ap.add_argument("--recipe", choices=sorted(RECIPES), default="v5",
                    help="data recipe (v4 = the deployed model's, for comparison under the same protocol)")
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args()
    if a.recipe != "v5":
        global RECIPE, OUT, ARGS
        RECIPE, OUT = RECIPES[a.recipe], HERE / "cv_runs" / f"{a.recipe}_grouped"
        if a.recipe == "v4":
            ARGS = dict(TRAIN_ARGS)      # v4 as deployed, incl. its confusable-pair penalty
        else:
            ARGS = {**ARGS, "confusable_pairs": RECIPE.get("pairs", "")}
        if a.cmd == "final" and a.out == FINAL_CKPT:
            raise SystemExit(f"--recipe {a.recipe} final: pass --out (default is the v5 checkpoint)")
    torch.set_num_threads(a.threads)
    return {"cv": cmd_cv, "calibrate": cmd_calibrate, "evaluate": cmd_evaluate, "final": cmd_final}[a.cmd](a)


if __name__ == "__main__":
    raise SystemExit(main())
