"""Signer-held-out cross-validation of the Lupang Hinirang recognizer.

    python cv_lupang.py --recipe v5 [--folds 5] [--out-dir cv_runs]

A student is a NEW signer, so the honest test is on signers the model never
saw. For each fold, every clip of the fold's sources (signers / videos) is held
out; the model is trained on the rest with the recipe's data pipeline
(negatives are built from the TRAINING signers only, so no part of a test clip
leaks into training as INVALID_GESTURE), and the held-out signers' raw
captures are run through the full live decision
(test_lupang_recognition.run_suite -> lupang_common.evaluate_capture) in every
test scenario. Counts are summed over folds.

Recipes
    v4   the deployed v4 model: no still-edge trim, v4 negative mix
    v5   still-edge trim in training AND inference, plus transition /
         two-line negatives
"""
import argparse
import json
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

import lupang_common as lc
import train_lupang_model as t
from extract_lupang_dataset import make_clip, make_negatives
from test_lupang_recognition import CheckpointDecider, load_captures, run_suite, summarize

RECIPES = {
    "v4": dict(trim_still=False, neg_mix="v4", neg_count=128),
    "v5": dict(trim_still=True, neg_mix="v5", neg_count=160),
}
# Training hyper-parameters of the deployed checkpoint (palm_lupang_best.json "args").
TRAIN_ARGS = dict(per_class=60, regen_every=10, epochs=150, patience=35, batch=64, lr=1e-3,
                  weight_decay=1e-2, label_smoothing=0.1, confusable_pairs="14:13,15:12",
                  pair_penalty=1.0, pooling="halves", split="stratified")


def fold_sources(caps, k):
    """Deterministic source -> fold assignment, balancing the number of clips."""
    counts = {}
    for c in caps:
        counts[c["source"]] = counts.get(c["source"], 0) + 1
    folds, load = [[] for _ in range(k)], [0] * k
    for src, n in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])):
        j = int(np.argmin(load))
        folds[j].append(src)
        load[j] += n
    return folds


def build_training_set(caps, idx, recipe, rng):
    clips = [make_clip(caps[i]["path"], caps[i]["label"], caps[i]["raw"], caps[i]["ts"], recipe["trim_still"])
             for i in idx]
    clips = [c for c in clips if c is not None]
    n_neg = int(round(recipe["neg_count"] * len(clips) / len(caps)))
    nX, _, _ = make_negatives(rng, clips, n_neg, recipe["neg_mix"])
    X = np.stack([c["seq"] for c in clips] + nX).astype(np.float32)
    y = np.array([c["label"] for c in clips] + [lc.INVALID_IDX] * len(nX), dtype=np.int64)
    durs = np.array([c["duration"] for c in clips] + [np.nan] * len(nX))
    return X, y, durs


def train_fold(X, y, durs, recipe, out, seed, verbose, epochs=None):
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    tr, va = t.stratified_split(y, 0.15, rng)
    gate = {**lc.GATE_DEFAULTS, **lc.LUPANG_RELIABILITY, "trim_still": recipe["trim_still"],
            **lc.calibrate_kinematics(X[tr][y[tr] != lc.INVALID_IDX])}
    gate["class_min_duration"] = lc.calibrate_class_durations(durs[tr], y[tr])
    args = SimpleNamespace(**{**TRAIN_ARGS, **({"epochs": epochs} if epochs else {})}, out=Path(out), seed=seed)
    best = t.train_model(X[tr], y[tr], X[va], y[va], args, gate, rng, torch.device("cpu"), verbose=verbose)
    return best


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--recipe", choices=sorted(RECIPES), required=True)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--only-fold", type=int, help="run a single fold (for parallel runs)")
    ap.add_argument("--out-dir", type=Path, default=Path("cv_runs"))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--epochs", type=int, help="override the training epochs (smoke tests)")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()
    torch.set_num_threads(args.threads)
    recipe = RECIPES[args.recipe]
    out_dir = args.out_dir / args.recipe
    out_dir.mkdir(parents=True, exist_ok=True)

    caps = load_captures()
    folds = fold_sources(caps, args.folds)
    for f, srcs in enumerate(folds):
        if args.only_fold is not None and f != args.only_fold:
            continue
        test_idx = [i for i, c in enumerate(caps) if c["source"] in srcs]
        train_idx = [i for i, c in enumerate(caps) if c["source"] not in srcs]
        t0 = time.time()
        X, y, durs = build_training_set(caps, train_idx, recipe, np.random.default_rng(args.seed + f))
        ckpt = out_dir / f"fold{f}.pt"
        best = train_fold(X, y, durs, recipe, ckpt, args.seed + f, args.verbose, args.epochs)
        print(f"[{args.recipe} fold {f}] test sources {srcs} ({len(test_idx)} clips) | train {len(train_idx)} "
              f"clips + {int((y == lc.INVALID_IDX).sum())} negatives | inner-val bacc {best['bacc']:.3f} "
              f"@ epoch {best['epoch']} ({time.time() - t0:.0f}s)", flush=True)
        results = run_suite(CheckpointDecider(ckpt), caps, test_idx, seed=args.seed + f, verbose=args.verbose)
        (out_dir / f"fold{f}.json").write_text(json.dumps(
            {"sources": srcs, "best": best, "results": results, "summary": summarize(results)}, indent=2),
            encoding="utf-8")
        print(f"[{args.recipe} fold {f}] " + "  ".join(f"{k}={v:.3f}" for k, v in summarize(results).items()
                                                       if isinstance(v, float)), flush=True)
    return 0


def aggregate(out_dir):
    """Sum per-fold scenario counts of a recipe directory."""
    total = {}
    for p in sorted(Path(out_dir).glob("fold*.json")):
        for name, r in json.loads(p.read_text(encoding="utf-8"))["results"].items():
            a = total.setdefault(name, {"kind": r["kind"], "n": 0, "correct": 0, "wrong": 0, "abstain": 0,
                                        "accepted": 0, "reasons": {}, "confusions": {}})
            for k in ("n", "correct", "wrong", "abstain", "accepted"):
                a[k] += r[k]
            for field in ("reasons", "confusions"):
                for k, v in r[field].items():
                    a[field][k] = a[field].get(k, 0) + v
    return total


if __name__ == "__main__":
    raise SystemExit(main())
