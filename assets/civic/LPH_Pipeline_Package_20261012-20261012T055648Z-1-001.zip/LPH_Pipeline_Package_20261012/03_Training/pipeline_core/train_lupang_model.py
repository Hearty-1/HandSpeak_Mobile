"""Train the Lupang Hinirang FullSequenceConvBiLSTM.

    python train_lupang_model.py [--per-class 60] [--epochs 150] [--split stratified|group]
                                 [--pooling halves|mean] [--min-conf 0.65] [--min-margin 0.20]

Steps
1. Load X_raw_lupang.npy (M, 32, 181) / y_raw_lupang.npy (M,).
2. Split the ORIGINAL samples 85/15 (stratified by class; `--split group`
   instead holds out whole signers/source videos for a harder estimate).
3. Offline augmentation of the training split only, so every class reaches
   `--per-class` samples (>= 50): originals + mirrored originals + synthetic
   variants. The pool is regenerated every `--regen-every` epochs for more
   diversity (0 = generate once).
4. Train with AdamW, label-smoothed cross-entropy, ReduceLROnPlateau; keep the
   checkpoint with the best validation balanced accuracy -> palm_lupang_best.pt
5. Calibrate the kinematic rejection thresholds on the training phrases,
   store the full gate in the checkpoint, and report validation through the
   exact live decision rule (lupang_common.gate_decision).

Augmentations (applied to the 163 static channels; velocity is recomputed
afterwards so it is always consistent with the positions):
  * local speed variation 0.8x-1.2x + start/end crop or pad (+-8 %).
    A *uniform* speed change is a no-op after resampling to T=32, so speed is
    varied non-uniformly along the sequence (time warping).
  * global rotation +-8 deg and anisotropic scale jitter 0.9-1.1 of body
    anchors, per-hand rotation +-10 deg and scale 0.95-1.05 of the handshape.
  * Gaussian noise on coordinates / curl cosines / palm normal.
  * short hand-detection dropouts.
  * one-handed execution: the less-active hand removed for the whole sequence
    (p=0.25), matching the pipeline's resting-hand rule.
  * horizontal mirror (x negated, left/right hand slots swapped) with p=0.5.
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from sklearn.model_selection import GroupShuffleSplit

import lupang_common as lc

# ---------------------------------------------------------------------------
# Channel index tables for augmentation (derived from feature names)
# ---------------------------------------------------------------------------
N = lc.STATIC_NAMES
_I = {n: i for i, n in enumerate(N)}


def _pairs(pred):
    xs = [i for i, n in enumerate(N) if n.endswith(".x") and pred(n)]
    ys = [_I[N[i][:-2] + ".y"] for i in xs]
    return np.array(xs), np.array(ys)


HAND = {}
for s in ("L", "R"):
    HAND[s] = {
        "shape": _pairs(lambda n, s=s: n.startswith(f"{s}.shape.")),
        "anchor": _pairs(lambda n, s=s: n.startswith(f"{s}.") and not n.startswith(f"{s}.shape.")),
        "normal": (_I[f"{s}.palm_normal.nx"], _I[f"{s}.palm_normal.ny"]),
        "nz": _I[f"{s}.palm_normal.nz"],
        "cos": lc.static_index(lambda n, s=s: n.startswith(f"{s}.curl.") or n.startswith(f"{s}.spread.")),
        "scale": _I[f"{s}.palm_scale"],
        "present": _I[f"{s}.present"],
        "block": lc.static_index(lambda n, s=s: n.startswith(f"{s}.")),
    }
BODY = _pairs(lambda n: n.startswith("body."))


ONE_HAND_P = 0.25   # probability of the one-handed augmentation


def _rotate(x, y, theta):
    c, s = np.cos(theta), np.sin(theta)
    return c * x - s * y, s * x + c * y


def augment(sample, rng):
    """(32, 181) -> augmented (32, 181)."""
    T = lc.T
    st = sample[:, :lc.S_DIM].astype(np.float64)

    # --- time: local speed 0.8x-1.2x, then crop / pad the ends -------------
    speed = np.interp(np.linspace(0, 1, T), np.linspace(0, 1, 4), rng.uniform(0.8, 1.2, 4))
    w = np.concatenate([[0.0], np.cumsum(speed[1:])])
    w /= w[-1]
    a, b = rng.uniform(-0.08, 0.08), 1.0 + rng.uniform(-0.08, 0.08)
    u = np.clip(a + (b - a) * w, 0.0, 1.0) * (T - 1)
    i0 = np.minimum(np.floor(u).astype(int), T - 2)
    f = (u - i0)[:, None]
    st = st[i0] * (1 - f) + st[i0 + 1] * f
    present_mask = {s: (st[:, HAND[s]["present"]] > 0.5)[:, None] for s in ("L", "R")}

    # --- geometry ------------------------------------------------------------
    theta = np.deg2rad(rng.uniform(-8, 8))
    sx, sy = rng.uniform(0.9, 1.1, 2)
    bx, by = BODY
    st[:, bx], st[:, by] = _rotate(st[:, bx] * sx, st[:, by] * sy, theta)
    st[:, bx] += rng.normal(0, 0.01, st[:, bx].shape)
    st[:, by] += rng.normal(0, 0.01, st[:, by].shape)
    for s in ("L", "R"):
        h = HAND[s]
        m = present_mask[s]
        ax, ay = h["anchor"]
        st[:, ax], st[:, ay] = _rotate(st[:, ax] * sx, st[:, ay] * sy, theta)
        st[:, ax] += rng.normal(0, 0.01, st[:, ax].shape) * m
        st[:, ay] += rng.normal(0, 0.01, st[:, ay].shape) * m
        st[:, h["scale"]] *= np.sqrt(sx * sy)
        hand_theta = theta + np.deg2rad(rng.uniform(-10, 10))
        hs = rng.uniform(0.95, 1.05)
        shx, shy = h["shape"]
        st[:, shx], st[:, shy] = _rotate(st[:, shx] * hs, st[:, shy] * hs, hand_theta)
        st[:, shx] += rng.normal(0, 0.02, st[:, shx].shape) * m
        st[:, shy] += rng.normal(0, 0.02, st[:, shy].shape) * m
        nx, ny = h["normal"]
        st[:, nx], st[:, ny] = _rotate(st[:, nx], st[:, ny], hand_theta)
        nidx = [nx, ny, h["nz"]]
        st[:, nidx] += rng.normal(0, 0.02, (T, 3)) * m
        norm = np.maximum(np.linalg.norm(st[:, nidx], axis=1, keepdims=True), 1e-6)
        st[:, nidx] = np.where(m, st[:, nidx] / norm, 0.0)
        st[:, h["cos"]] = np.clip(st[:, h["cos"]] + rng.normal(0, 0.02, (T, len(h["cos"]))), -1, 1) * m

    # --- short hand dropout --------------------------------------------------
    if rng.random() < 0.15:
        s = "L" if rng.random() < 0.5 else "R"
        length = int(rng.integers(2, 7))
        start = int(rng.integers(0, T - length))
        st[start:start + length, HAND[s]["block"]] = 0.0

    # --- one-handed execution --------------------------------------------------
    # Live users often sign with the dominant hand only and rest the other
    # out of view; the reference videos almost always show both hands. Remove
    # the less-active hand for the whole sequence (what the pipeline's
    # one-hand rule produces) so the model learns to classify from one hand.
    if rng.random() < ONE_HAND_P:
        energy = {}
        for s in ("L", "R"):
            wx, wy = _I[f"{s}.wrist_mid.x"], _I[f"{s}.wrist_mid.y"]
            pres = st[:, HAND[s]["present"]] > 0.5
            step = np.linalg.norm(np.diff(st[:, [wx, wy]], axis=0), axis=1) * (pres[1:] & pres[:-1])
            energy[s] = step.sum() if pres.any() else -1.0
        if min(energy.values()) >= 0:          # both hands present somewhere
            weak = min(energy, key=energy.get)
            st[:, HAND[weak]["block"]] = 0.0

    out = lc.add_velocity(st.astype(np.float32))
    if rng.random() < 0.5:
        out = lc.mirror_features(out)
    return out.astype(np.float32)


def stratified_split(y, val_frac, rng, min_train=2):
    """Per-class random split: round(val_frac * n) clips of each class go to
    validation, but at least `min_train` always stay in training (so the
    3-clip class keeps all of its clips for training)."""
    tr, va = [], []
    for c in np.unique(y):
        idx = rng.permutation(np.flatnonzero(y == c))
        n_val = min(int(round(val_frac * len(idx))), max(0, len(idx) - min_train))
        va += idx[:n_val].tolist()
        tr += idx[n_val:].tolist()
    return np.array(sorted(tr)), np.array(sorted(va))


def build_balanced_pool(X, y, per_class, rng):
    """Offline balancing: originals + their mirrors + augmented samples until
    every class has `per_class` samples (more if originals*2 exceed it)."""
    Xs, ys = [], []
    for c in np.unique(y):
        src = X[y == c]
        items = list(src) + [lc.mirror_features(s) for s in src]
        while len(items) < per_class:
            items.append(augment(src[rng.integers(len(src))], rng))
        Xs.append(np.stack(items))
        ys.append(np.full(len(items), c, dtype=np.int64))
    return np.concatenate(Xs), np.concatenate(ys)


# ---------------------------------------------------------------------------
# Training / evaluation
# ---------------------------------------------------------------------------
@torch.no_grad()
def predict(model, X, device, batch=256):
    model.eval()
    out = []
    for i in range(0, len(X), batch):
        out.append(torch.softmax(model(torch.from_numpy(X[i:i + batch]).to(device)), dim=1).cpu())
    return torch.cat(out).numpy()


def balanced_accuracy(y_true, y_pred):
    accs = [np.mean(y_pred[y_true == c] == c) for c in np.unique(y_true)]
    return float(np.mean(accs))


from extract_lupang_dataset import KIND_NAMES  # noqa: E402  (0 real, 1.. synthetic negative kinds)


def report(probs, X, y, gate, title, kinds=None, durs=None):
    """Closed-set accuracy plus the full live decision (lupang_common.gate_decision)."""
    pred = probs.argmax(1)
    print(f"\n=== {title} ===")
    print(f"closed-set accuracy {np.mean(pred == y):.3f} | balanced accuracy "
          f"{balanced_accuracy(y, pred):.3f} | n={len(y)}")
    print("per-class accuracy:")
    for c in np.unique(y):
        m = y == c
        print(f"  [{c:02d}] {lc.CLASS_NAMES[c]:<40} {np.mean(pred[m] == c):5.2f}  (n={m.sum()})")
    conf = {}
    for t, p in zip(y, pred):
        if t != p:
            conf[(t, p)] = conf.get((t, p), 0) + 1
    if conf:
        print("most frequent confusions (true -> predicted):")
        for (t, p), k in sorted(conf.items(), key=lambda kv: -kv[1])[:8]:
            print(f"  {k}x  {lc.CLASS_NAMES[t]}  ->  {lc.CLASS_NAMES[p]}")

    accepted = np.zeros(len(y), dtype=bool)
    reasons = []
    for i in range(len(y)):
        # Duration checks need the raw clip duration (dur_raw_lupang.npy); the
        # frame count is approximated at the videos' ~30 fps. Synthetic
        # negatives have no raw duration and skip the duration checks.
        info = None
        if durs is not None and np.isfinite(durs[i]):
            info = {"active_frames": int(round(durs[i] * 30)) + 1, "duration_s": float(durs[i]), "fps": 30.0}
        pre = (lc.duration_gate(info, gate) if info else []) + lc.kinematic_gate(X[i], gate)[0]
        if all(c.passed for c in pre):        # classifier only runs past the pre-checks
            ok, failed, _ = lc.gate_decision(X[i], probs[i], gate, info)
        else:
            ok, failed = False, lc.failed_codes(pre)
        accepted[i] = ok
        reasons.append(failed)
    print("live decision: " + lc.format_gate(gate))
    pos = y != lc.INVALID_IDX
    print(f"  real phrases (n={pos.sum()}): accepted & correct "
          f"{np.mean(accepted[pos] & (pred[pos] == y[pos])):.3f}, accepted but WRONG "
          f"{np.mean(accepted[pos] & (pred[pos] != y[pos])):.3f}, rejected {np.mean(~accepted[pos]):.3f}")
    if (~pos).any():
        print(f"  invalid gestures (n={(~pos).sum()}): rejected {np.mean(~accepted[~pos]):.3f}")
        if kinds is not None:
            for k in np.unique(kinds[~pos]):
                m = (~pos) & (kinds == k)
                print(f"    {KIND_NAMES[k]:<8} rejected {np.mean(~accepted[m]):.2f} (n={m.sum()})")
    for name, mask in (("real phrases", pos), ("invalid gestures", ~pos)):
        counts = {}
        for i in np.flatnonzero(mask):
            for r in reasons[i]:
                counts[r] = counts.get(r, 0) + 1
        if counts:
            print(f"  rejection reasons on {name} (a sample can fail several): "
                  + ", ".join(f"{k} {v}" for k, v in sorted(counts.items(), key=lambda kv: -kv[1])))


def parse_pairs(spec):
    """'14:13,15:12' -> [(14, 13), (15, 12)] (class indices, 0-based)."""
    pairs = []
    for item in filter(None, (x.strip() for x in spec.split(","))):
        a, b = (int(v) for v in item.split(":"))
        for c in (a, b):
            if not 0 <= c < lc.INVALID_IDX:
                raise SystemExit(f"--confusable-pairs: {c} is not a phrase class (0-{lc.INVALID_IDX - 1})")
        pairs.append((a, b))
    return pairs


def pair_penalty(logits, target, pairs, weight):
    """Extra loss for specific known confusions: for a sample of class a in a
    pair (a, b), add -log(1 - p_b) (and symmetrically for b), which pushes the
    model specifically away from predicting the partner class."""
    if not pairs or weight <= 0:
        return logits.new_zeros(())
    p = torch.softmax(logits, dim=1)
    total = logits.new_zeros(())
    for a, b in pairs:
        for true, wrong in ((a, b), (b, a)):
            m = target == true
            if m.any():
                total = total - torch.log1p(-p[m, wrong].clamp(max=1 - 1e-6)).sum()
    return weight * total / len(target)


def evaluate_checkpoint(args, gate, X_va, y_va, va, device):
    model, _ = lc.load_model(args.out, device)
    kind_path = args.data_dir / "kind_raw_lupang.npy"
    kinds_va = np.load(kind_path)[va] if kind_path.exists() else None
    dur_path = args.data_dir / "dur_raw_lupang.npy"
    durs_va = np.load(dur_path)[va] if dur_path.exists() else None
    probs = predict(model, X_va, device)
    probs_m = predict(model, lc.mirror_features(X_va), device)
    print(f"\nmirror-invariance check: val accuracy {np.mean(probs.argmax(1) == y_va):.3f} as recorded, "
          f"{np.mean(probs_m.argmax(1) == y_va):.3f} horizontally flipped")
    # The live engine averages each sequence with its mirror; evaluate the same way.
    if getattr(args, "dump_val", None):
        np.savez(args.dump_val, probs=(probs + probs_m) / 2, y=y_va, idx=va)
    report((probs + probs_m) / 2, X_va, y_va, gate,
           "validation, live decision rule (mirror-averaged probabilities)", kinds_va, durs_va)


def recalibrate(args, gate, X_va, y_va, va, device):
    if not args.out.exists():
        raise SystemExit(f"{args.out} not found; train first")
    ckpt = torch.load(args.out, map_location="cpu", weights_only=False)
    ckpt.setdefault("metrics", {})["gate"] = gate
    torch.save(ckpt, args.out)
    print(f"updated rejection gate stored in {args.out}")
    evaluate_checkpoint(args, gate, X_va, y_va, va, device)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-dir", type=Path, default=Path("."))
    ap.add_argument("--out", type=Path, default=Path("palm_lupang_best.pt"))
    ap.add_argument("--split", choices=["stratified", "group"], default="stratified")
    ap.add_argument("--val-frac", type=float, default=0.15)
    ap.add_argument("--per-class", type=int, default=60, help="balanced samples per class (>= 50)")
    ap.add_argument("--regen-every", type=int, default=10,
                    help="regenerate the augmented pool every N epochs (0 = once)")
    ap.add_argument("--epochs", type=int, default=150)
    ap.add_argument("--patience", type=int, default=35, help="early-stopping patience (epochs)")
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--weight-decay", type=float, default=1e-2)
    ap.add_argument("--label-smoothing", type=float, default=0.1)
    ap.add_argument("--confusable-pairs", default="",
                    help="known confusions to penalise, e.g. '14:13,15:12' (0-based class ids); off by default")
    ap.add_argument("--pair-penalty", type=float, default=1.0,
                    help="weight of the extra -log(1 - p_partner) loss for --confusable-pairs")
    ap.add_argument("--dump-val", help="save mirror-averaged validation probabilities to this .npz")
    ap.add_argument("--pooling", choices=["halves", "mean"], default="halves",
                    help="temporal pooling: separate first/second-half means, or one global mean")
    ap.add_argument("--min-conf", type=float, default=lc.GATE_DEFAULTS["min_conf"])
    ap.add_argument("--min-margin", type=float, default=lc.GATE_DEFAULTS["min_margin"])
    ap.add_argument("--max-entropy", type=float, default=lc.GATE_DEFAULTS["max_entropy"])
    ap.add_argument("--min-phase-frac", type=float,
                    help="fixed per-phase motion share (e.g. 0.18); default: calibrated")
    ap.add_argument("--calibrate-only", action="store_true",
                    help="recalibrate the rejection gate of an existing --out checkpoint "
                         "on the same split and re-run the validation report (no training)")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    if args.per_class < 50:
        raise SystemExit("--per-class must be >= 50")
    x_path, y_path = args.data_dir / "X_raw_lupang.npy", args.data_dir / "y_raw_lupang.npy"
    if not x_path.exists() or not y_path.exists():
        raise SystemExit("X_raw_lupang.npy / y_raw_lupang.npy not found; run extract_lupang_dataset.py first")
    X = np.load(x_path).astype(np.float32)
    y = np.load(y_path).astype(np.int64)
    if X.ndim != 3 or X.shape[1:] != (lc.T, lc.FEATURE_DIM):
        raise SystemExit(f"X has shape {X.shape}, expected (M, {lc.T}, {lc.FEATURE_DIM}); "
                         f"re-run extract_lupang_dataset.py")
    if len(X) != len(y):
        raise SystemExit("X and y length mismatch")

    rng = np.random.default_rng(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # --- split originals BEFORE any augmentation -----------------------------
    if args.split == "group":
        groups = np.load(args.data_dir / "groups_raw_lupang.npy")
        tr, va = next(GroupShuffleSplit(1, test_size=args.val_frac, random_state=args.seed)
                      .split(X, y, groups))
    else:
        tr, va = stratified_split(y, args.val_frac, rng)
    missing = sorted(set(np.unique(y)) - set(np.unique(y[tr])))
    if missing:
        raise SystemExit(f"classes {missing} have no training samples; change --seed or --val-frac")
    X_tr, y_tr, X_va, y_va = X[tr], y[tr], X[va], y[va]
    print(f"data {X.shape} | train {len(tr)} originals | val {len(va)} ({args.split} split)")
    print("train originals per class:", np.bincount(y_tr, minlength=lc.NUM_CLASSES).tolist())

    # Lupang reliability (landmark coverage + stability abstention) is part of every gate.
    gate = {**lc.GATE_DEFAULTS, **lc.LUPANG_RELIABILITY,
            "min_conf": args.min_conf, "min_margin": args.min_margin, "max_entropy": args.max_entropy,
            **lc.calibrate_kinematics(X_tr[y_tr != lc.INVALID_IDX])}
    if args.min_phase_frac is not None:
        gate["min_phase_frac"] = args.min_phase_frac
    dur_path = args.data_dir / "dur_raw_lupang.npy"
    if dur_path.exists():
        gate["class_min_duration"] = lc.calibrate_class_durations(np.load(dur_path)[tr], y_tr)
    else:
        print("WARNING: dur_raw_lupang.npy missing; per-phrase duration check disabled "
              "(re-run extract_lupang_dataset.py)")
    print("rejection gate (calibrated on training phrases): " + lc.format_gate(gate))
    if args.calibrate_only:
        recalibrate(args, gate, X_va, y_va, va, device)
        return

    best = train_model(X_tr, y_tr, X_va, y_va, args, gate, rng, device)
    evaluate_checkpoint(args, gate, X_va, y_va, va, device)
    with open(args.out.with_suffix(".json"), "w", encoding="utf-8") as f:
        json.dump({**best, "gate": gate, "args": {k: str(v) for k, v in vars(args).items()}}, f, indent=2)


def train_model(X_tr, y_tr, X_va, y_va, args, gate, rng, device, verbose=True):
    """Train on (X_tr, y_tr); keep the epoch with the best balanced accuracy on
    (X_va, y_va) in args.out (with `gate` stored in it). Returns the best metrics.
    Used by main() and by cv_lupang.py (signer-held-out cross-validation)."""
    log = print if verbose else (lambda *a, **k: None)
    pool_X, pool_y = build_balanced_pool(X_tr, y_tr, args.per_class, rng)
    log(f"balanced training pool {pool_X.shape} "
        f"({np.bincount(pool_y).min()}-{np.bincount(pool_y).max()} per class)")

    config = dict(in_features=lc.FEATURE_DIM, num_classes=lc.NUM_CLASSES,
                  conv_channels=128, hidden=128, lstm_dropout=0.3, head_dropout=0.4,
                  pooling=args.pooling)
    model = lc.FullSequenceConvBiLSTM(**config).to(device)
    flat = pool_X.reshape(-1, lc.FEATURE_DIM)
    model.feat_mean.copy_(torch.from_numpy(flat.mean(0)))
    model.feat_std.copy_(torch.from_numpy(np.maximum(flat.std(0), 1e-2)))

    criterion = nn.CrossEntropyLoss(label_smoothing=args.label_smoothing)
    pairs = parse_pairs(args.confusable_pairs)
    if pairs:
        log("pair penalty x{:.2f} on: ".format(args.pair_penalty)
            + ", ".join(f"{lc.CLASS_NAMES[a]} <-> {lc.CLASS_NAMES[b]}" for a, b in pairs))
    eval_ce = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", factor=0.5,
                                                           patience=8, min_lr=1e-5)
    Xv_t = torch.from_numpy(X_va).to(device)
    yv_t = torch.from_numpy(y_va).to(device)

    best = {"bacc": -1.0, "loss": float("inf"), "epoch": 0}
    t0 = time.time()
    for epoch in range(1, args.epochs + 1):
        if args.regen_every and epoch > 1 and (epoch - 1) % args.regen_every == 0:
            pool_X, pool_y = build_balanced_pool(X_tr, y_tr, args.per_class, rng)
        model.train()
        perm = rng.permutation(len(pool_X))
        tot, correct = 0.0, 0
        for i in range(0, len(perm), args.batch):
            idx = perm[i:i + args.batch]
            if len(idx) < 2:
                continue
            xb = torch.from_numpy(pool_X[idx]).to(device)
            yb = torch.from_numpy(pool_y[idx]).to(device)
            optimizer.zero_grad()
            logits = model(xb)
            loss = criterion(logits, yb) + pair_penalty(logits, yb, pairs, args.pair_penalty)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            tot += loss.item() * len(idx)
            correct += (logits.argmax(1) == yb).sum().item()
        train_loss, train_acc = tot / len(perm), correct / len(perm)

        model.eval()
        with torch.no_grad():
            v_logits = model(Xv_t)
            v_loss = eval_ce(v_logits, yv_t).item()
            v_pred = v_logits.argmax(1).cpu().numpy()
        v_acc = float(np.mean(v_pred == y_va))
        v_bacc = balanced_accuracy(y_va, v_pred)
        scheduler.step(v_loss)

        improved = v_bacc > best["bacc"] or (v_bacc == best["bacc"] and v_loss < best["loss"])
        if improved:
            best = {"bacc": v_bacc, "acc": v_acc, "loss": v_loss, "epoch": epoch}
            lc.save_checkpoint(args.out, model, config, metrics={
                **best, "split": args.split, "seed": args.seed, "gate": gate})
        if epoch == 1 or epoch % 5 == 0 or improved:
            log(f"ep {epoch:3d} | train loss {train_loss:.3f} acc {train_acc:.3f} | "
                f"val loss {v_loss:.3f} acc {v_acc:.3f} bacc {v_bacc:.3f} | "
                f"lr {optimizer.param_groups[0]['lr']:.1e}{'  *saved' if improved else ''}")
        if epoch - best["epoch"] >= args.patience:
            log(f"early stop at epoch {epoch} (no improvement for {args.patience})")
            break

    log(f"\nbest epoch {best['epoch']}: val acc {best['acc']:.3f}, balanced {best['bacc']:.3f}, "
        f"loss {best['loss']:.3f}  ({time.time() - t0:.0f}s)  -> {args.out}")
    return best


if __name__ == "__main__":
    main()
