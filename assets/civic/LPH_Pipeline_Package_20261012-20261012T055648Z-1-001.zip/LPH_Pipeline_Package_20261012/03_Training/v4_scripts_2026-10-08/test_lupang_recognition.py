"""Reproducible Lupang Hinirang recognition test (no webcam needed).

    python test_lupang_recognition.py                       # deployed service model, held-out clips
    python test_lupang_recognition.py --model palm_lupang_best.pt
    python test_lupang_recognition.py --json report.json    # also write the numbers

Every capture is REAL MediaPipe Holistic output of a recorded clip
(lupang_landmarks_cache.pkl); scenarios are built by cutting, padding,
re-timing, moving or removing those real landmarks. Each capture is sent
through the exact production decision:

    --model service (default)
        inference-service RawSpecialistModel.predict(frames, w, h): the code
        behind POST /v1/predict_raw/lupang_hinirang (ONNX + JSON gate), with the
        landmarks converted to the request's frame format.
    --model <checkpoint.pt>
        lupang_common.evaluate_capture with the PyTorch checkpoint and the gate
        stored in it (same function the service calls).

Held-out clips: the deployed checkpoint's validation split (stratified, seed
42), i.e. clips that model never trained on, or --heldout-sources for whole
signers. Expected behaviour:

    positive scenarios   complete line, possibly slower / faster / lower fps /
                         nearer / tilted / with idle hands before and after
                         -> accepted with the TRUE line
    partial scenario     the less active hand is never detected: the true line
                         or no prediction (one-handed lines need no 2nd hand)
    negative scenarios   idle, no hands, fragments, transitions between lines,
                         two lines in one capture, random movement, missing or
                         out-of-frame landmarks, other (Calendar) signs
                         -> NO prediction (abstain)
"""
import argparse
import json
import pickle
import sys
import time
from pathlib import Path

import numpy as np

import lupang_common as lc

HERE = Path(__file__).resolve().parent
CACHE = HERE / "lupang_landmarks_cache.pkl"
JITTER = 0.003            # MediaPipe landmark jitter of a hand held still (normalised units)


# ---------------------------------------------------------------------------
# Captures
# ---------------------------------------------------------------------------
def load_captures():
    """All real clips in dataset order: dicts(label, source, path, raw, ts).
    Order == the real rows of X_raw_lupang.npy (clips without hands skipped)."""
    from extract_lupang_dataset import list_videos
    cache = pickle.load(open(CACHE, "rb"))
    _, items = list_videos(lc.RAW_DIR)
    out = []
    for path, label in items:
        e = cache.get(path)
        if e is None or lc.clean_sequence(e["raw"], e["ts"]) is None:
            continue
        out.append({"label": label, "source": lc.source_id(path), "path": path,
                    "raw": e["raw"].astype(np.float32), "ts": e["ts"].astype(np.float64)})
    return out


def heldout_split(caps, sources=None, seed=42, val_frac=0.15):
    """Indices of held-out captures: whole sources, or the stratified
    validation split the deployed checkpoint was trained with."""
    if sources:
        return [i for i, c in enumerate(caps) if c["source"] in sources]
    import train_lupang_model as t
    y = np.load(HERE / "y_raw_lupang.npy")
    _, va = t.stratified_split(y, val_frac, np.random.default_rng(seed))
    return [int(i) for i in va if i < len(caps)]


def _active(c):
    """The UNCLEANED frames from the first to the last hand detection (what a
    phone sends once idle frames without hands are cut). Scenarios are built
    from these so the server's cleaning runs exactly once, as in production."""
    raw, ts = c["raw"], c["ts"]
    hit = np.flatnonzero((raw[:, lc.RAW_FLAG_LH] > 0.5) | (raw[:, lc.RAW_FLAG_RH] > 0.5))
    a, b = hit[0], hit[-1] + 1
    return raw[a:b].copy(), ts[a:b] - ts[a]


def _cut(raw, ts, a, b):
    n = len(raw)
    i, j = int(round(a * n)), max(int(round(b * n)), int(round(a * n)) + 2)
    return raw[i:j].copy(), ts[i:j] - ts[i]


def _concat(parts):
    raws, tss, t0 = [], [], 0.0
    for raw, ts in parts:
        dt = float(np.median(np.diff(ts))) if len(ts) > 1 else 1 / 30
        raws.append(raw)
        tss.append(ts - ts[0] + t0)
        t0 = tss[-1][-1] + dt
    return np.concatenate(raws), np.concatenate(tss)


def _hold(frame, seconds, rng, fps=30.0):
    """A pose held still for `seconds` with MediaPipe-like jitter."""
    n = max(2, int(round(seconds * fps)))
    seq = np.repeat(frame[None], n, axis=0).copy()
    xy = np.r_[np.r_[lc.RAW_POSE],
               np.r_[lc.RAW_LH].reshape(21, 3)[:, :2].ravel(),
               np.r_[lc.RAW_RH].reshape(21, 3)[:, :2].ravel()]
    # Smoothed (not white) noise: MediaPipe's smooth_landmarks output of a
    # still hand drifts slowly. Measured on the still edges of real clips the
    # wrist moves 0.07-0.16 shoulder spans/s; white noise of the same size
    # would read as ~1 span/s, i.e. as motion.
    k = 15
    noise = rng.normal(0, 1, (n + k - 1, len(xy)))
    noise = np.stack([np.convolve(noise[:, j], np.ones(k) / k, "valid") for j in range(len(xy))], 1)
    seq[:, xy] += (JITTER * noise / noise.std()).astype(np.float32)
    seq = _clear_absent(seq)
    return seq, np.arange(n) / fps


def _clear_absent(raw):
    raw[:, lc.RAW_LH][raw[:, lc.RAW_FLAG_LH] < 0.5] = 0.0
    raw[:, lc.RAW_RH][raw[:, lc.RAW_FLAG_RH] < 0.5] = 0.0
    if (raw[:, lc.RAW_FLAG_POSE] < 0.5).any():
        raw[raw[:, lc.RAW_FLAG_POSE] < 0.5, lc.RAW_POSE] = 0.0
    return raw


def _geom(raw, scale=1.0, angle_deg=0.0, dx=0.0, dy=0.0):
    """Rotate/scale every landmark about the median mid-shoulder point, then shift."""
    out = raw.copy()
    n = len(raw)
    pose = out[:, lc.RAW_POSE].reshape(n, 7, 2)
    ok = out[:, lc.RAW_FLAG_POSE] > 0.5
    c = np.median((pose[ok, lc.P_LSH] + pose[ok, lc.P_RSH]) / 2, axis=0)
    th = np.deg2rad(angle_deg)
    R = np.array([[np.cos(th), -np.sin(th)], [np.sin(th), np.cos(th)]], dtype=np.float32)

    def tf(p):
        return (p - c) @ R.T * scale + c + [dx, dy]
    out[:, lc.RAW_POSE] = tf(pose).reshape(n, 14)
    for sl in (lc.RAW_LH, lc.RAW_RH):
        h = out[:, sl].reshape(n, 21, 3)
        h[..., :2] = tf(h[..., :2])
        h[..., 2] *= scale
        out[:, sl] = h.reshape(n, 63)
    return _clear_absent(out)


def _hand_frames(raw):
    return np.flatnonzero((raw[:, lc.RAW_FLAG_LH] > 0.5) | (raw[:, lc.RAW_FLAG_RH] > 0.5))


def _drop_hands(raw, mask):
    out = raw.copy()
    for sl, flag in ((lc.RAW_LH, lc.RAW_FLAG_LH), (lc.RAW_RH, lc.RAW_FLAG_RH)):
        out[mask, flag] = 0.0
        out[mask, sl] = 0.0
    return out


def _weaker_hand(raw):
    e = {}
    for sl, flag, s in ((lc.RAW_LH, lc.RAW_FLAG_LH, "L"), (lc.RAW_RH, lc.RAW_FLAG_RH, "R")):
        pres = raw[:, flag] > 0.5
        w = raw[:, sl][:, :2]
        e[s] = (np.linalg.norm(np.diff(w, axis=0), axis=1) * (pres[1:] & pres[:-1])).sum() if pres.any() else -1
    return min(e, key=e.get) if min(e.values()) >= 0 else None


# Scenario builders: f(capture, all captures of the same source, rng) -> [(raw, ts), ...]
def positives():
    def complete(c, mates, rng):
        return [(c["raw"], c["ts"])]

    def slow(c, mates, rng):
        return [(c["raw"], c["ts"] * 1.4)]

    def fast(c, mates, rng):
        return [(c["raw"], c["ts"] * 0.8)]

    def fps15(c, mates, rng):
        return [(c["raw"][::2].copy(), c["ts"][::2] - c["ts"][0])]

    def fps10(c, mates, rng):
        return [(c["raw"][::3].copy(), c["ts"][::3] - c["ts"][0])]

    def far(c, mates, rng):
        return [(_geom(c["raw"], scale=0.6), c["ts"])]

    def near_shift(c, mates, rng):
        return [(_geom(c["raw"], scale=1.15, dx=0.06, dy=0.03), c["ts"])]

    def tilt(c, mates, rng):
        return [(_geom(c["raw"], angle_deg=a), c["ts"]) for a in (-8.0, 8.0)]

    def idle_edges(c, mates, rng):
        raw, ts = _active(c)
        pre, _ = _hold(raw[0], 1.5, rng)
        post, _ = _hold(raw[-1], 1.5, rng)
        dt = float(np.median(np.diff(ts)))
        return [_concat([(pre, np.arange(len(pre)) * dt), (raw, ts), (post, np.arange(len(post)) * dt)])]

    def idle_end(c, mates, rng):
        raw, ts = _active(c)
        post, _ = _hold(raw[-1], 2.0, rng)
        dt = float(np.median(np.diff(ts)))
        return [_concat([(raw, ts), (post, np.arange(len(post)) * dt)])]

    return {
        "complete line": complete,
        "slow (x1.4 duration)": slow,
        "fast (x0.8 duration)": fast,
        "low camera fps (15)": fps15,
        "low camera fps (10)": fps10,
        "farther from camera (60% size)": far,
        "nearer + off-centre": near_shift,
        "body tilted +-8 deg": tilt,
        "idle hands 1.5 s before + after": idle_edges,
        "hands held 2 s after the line": idle_end,
    }


def negatives():
    def idle(c, mates, rng):
        raw, _ = _active(c)
        return [_hold(raw[rng.choice(_hand_frames(raw))], 3.0, rng)]

    def no_hands(c, mates, rng):
        return [(_drop_hands(c["raw"], np.ones(len(c["raw"]), bool)), c["ts"])]

    def first_half(c, mates, rng):
        return [_cut(*_active(c), 0.0, 0.5)]

    def second_half(c, mates, rng):
        return [_cut(*_active(c), 0.5, 1.0)]

    def first_third(c, mates, rng):
        return [_cut(*_active(c), 0.0, 0.33)]

    def middle(c, mates, rng):
        return [_cut(*_active(c), 0.3, 0.7)]

    def transition(c, mates, rng):
        others = [m for m in mates if m["label"] != c["label"]]
        if not others:
            return []
        o = others[rng.integers(len(others))]
        return [_concat([_cut(*_active(c), 0.6, 1.0), _cut(*_active(o), 0.0, 0.4)])]

    def two_lines(c, mates, rng):
        others = [m for m in mates if m["label"] != c["label"]]
        if not others:
            return []
        o = others[rng.integers(len(others))]
        return [_concat([_active(c), _active(o)])]

    def fidget(c, mates, rng):
        raw, ts = _active(c)
        hands = _hand_frames(raw)
        seq, _ = _hold(raw[hands[len(hands) // 2]], ts[-1], rng)
        n = len(seq)
        for sl, flag, pw in ((lc.RAW_LH, lc.RAW_FLAG_LH, lc.P_LWR), (lc.RAW_RH, lc.RAW_FLAG_RH, lc.P_RWR)):
            if seq[0, flag] < 0.5:
                continue
            walk = np.cumsum(rng.normal(0, 1, (n + 8, 2)), axis=0)
            walk = np.stack([np.convolve(walk[:, k], np.ones(9) / 9, "valid") for k in range(2)], 1)[:n]
            walk = (walk - walk[0]) * 0.15 / (np.abs(walk).max() + 1e-6)
            h = seq[:, sl].reshape(n, 21, 3)
            h[..., :2] += walk[:, None]
            seq[:, sl] = h.reshape(n, 63)
            seq[:, 2 * pw:2 * pw + 2] += walk
        return [(seq, np.arange(n) / 30.0)]

    def missing(c, mates, rng):
        return [(_drop_hands(c["raw"], rng.random(len(c["raw"])) < 0.75), c["ts"])]

    def one_hand_lost(c, mates, rng):
        # The signer's less active hand is never detected (e.g. out of view).
        w = _weaker_hand(c["raw"])
        if w is None:
            return []
        out = c["raw"].copy()
        sl, flag = (lc.RAW_LH, lc.RAW_FLAG_LH) if w == "L" else (lc.RAW_RH, lc.RAW_FLAG_RH)
        out[:, sl] = 0.0
        out[:, flag] = 0.0
        return [(out, c["ts"])]

    def out_of_frame(c, mates, rng):
        r = c["raw"].copy()
        for sl in (lc.RAW_LH, lc.RAW_RH):
            h = r[:, sl].reshape(len(r), 21, 3)
            h[..., 1] += 1.0 - h[..., 1].min(axis=1, keepdims=True)
            r[:, sl] = h.reshape(len(r), 63)
        return [(_clear_absent(r), c["ts"])]

    return {
        "idle: hands visible, no sign (3 s)": idle,
        "no hands in view": no_hands,
        "incomplete: first half": first_half,
        "incomplete: second half": second_half,
        "incomplete: first third": first_third,
        "incomplete: middle 40%": middle,
        "transition: end of A + start of B": transition,
        "two lines in one capture": two_lines,
        "random hand movement": fidget,
        "hands found in only 25% of frames": missing,
        "hands below the image edge": out_of_frame,
        "less active hand never detected": one_hand_lost,      # kind "partial", see run_suite
    }


def calendar_captures():
    try:
        import calendar_common as cc
        cal = pickle.load(open(cc.LANDMARK_CACHE, "rb"))
    except Exception as exc:          # optional data set
        print(f"(Calendar signs unavailable: {exc})")
        return []
    return [(e["raw"].astype(np.float32), e["ts"]) for k, e in sorted(cal.items()) if "webcam_" not in k][::3]


# ---------------------------------------------------------------------------
# Deciders
# ---------------------------------------------------------------------------
def raw_to_frames(raw, ts):
    """Raw rows -> /v1/predict_raw request frames (image_width == image_height,
    so the x already scaled by the aspect ratio passes through unchanged)."""
    frames = []
    for row, t in zip(raw, ts):
        f = {"t": float(t), "pose": None, "left_hand": None, "right_hand": None}
        if row[lc.RAW_FLAG_POSE] > 0.5:
            pose = np.zeros((33, 3), dtype=np.float64)
            pose[list(lc.POSE_IDS), :2] = row[lc.RAW_POSE].reshape(7, 2)
            pose[list(lc.POSE_IDS), 2] = row[lc.RAW_VIS]
            f["pose"] = pose.tolist()
        for key, sl, flag in (("left_hand", lc.RAW_LH, lc.RAW_FLAG_LH), ("right_hand", lc.RAW_RH, lc.RAW_FLAG_RH)):
            if row[flag] > 0.5:
                f[key] = row[sl].reshape(21, 3).astype(np.float64).tolist()
        frames.append(f)
    return frames


class ServiceDecider:
    """The inference service's RawSpecialistModel (ONNX + exported gate)."""

    def __init__(self, models_dir=None):
        sys.path.insert(0, str(HERE / "inference-service"))
        from app.lupang_raw import LupangRawModel, MODELS_DIR
        self.model = LupangRawModel(Path(models_dir) if models_dir else MODELS_DIR)
        self.name = f"service ONNX ({self.model.meta['onnx_file']}, {self.model.meta['source_checkpoint']})"
        self.gate = self.model.gate

    def __call__(self, raw, ts):
        r = self.model.predict(raw_to_frames(raw, ts), 1000, 1000, top_k=3)
        top = r["top_k"][0]["index"] if r["top_k"] else None
        return r["accepted"], top, r["failed_checks"]


class CheckpointDecider:
    """lupang_common.evaluate_capture with a PyTorch checkpoint and its gate."""

    def __init__(self, path, gate_overrides=None):
        import torch
        self.torch = torch
        self.model, ckpt = lc.load_model(path)
        self.gate = {**lc.GATE_DEFAULTS, **lc.LUPANG_RELIABILITY, **ckpt.get("metrics", {}).get("gate", {}),
                     **(gate_overrides or {})}
        self.name = f"checkpoint {Path(path).name}"

    def probs(self, batch):
        with self.torch.no_grad():
            return self.torch.softmax(self.model(self.torch.from_numpy(np.asarray(batch, np.float32))), 1).numpy()

    def __call__(self, raw, ts):
        out = lc.evaluate_capture(raw, ts, self.probs, self.gate)
        top = int(np.argmax(out["probs"])) if out["probs"] is not None else None
        return out["accepted"], top, out["failed"]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------
def run_suite(decide, caps, held, seed=0, calendar=True, verbose=True):
    """Returns {scenario: dict(kind, n, correct, wrong, abstain, accepted, reasons, confusions)}."""
    by_source = {}
    for c in caps:
        by_source.setdefault(c["source"], []).append(c)
    results = {}

    def tally(name, kind, captures):
        r = {"kind": kind, "n": 0, "correct": 0, "wrong": 0, "abstain": 0, "reasons": {}, "confusions": {}}
        for label, raw, ts in captures:
            acc, top, failed = decide(raw, ts)
            r["n"] += 1
            if acc:
                if top == label:
                    r["correct"] += 1
                else:
                    r["wrong"] += 1
                    key = f"{lc.CLASS_NAMES[label] if label >= 0 else 'other'} -> {lc.CLASS_NAMES[top]}"
                    r["confusions"][key] = r["confusions"].get(key, 0) + 1
            else:
                r["abstain"] += 1
                if failed:
                    r["reasons"][failed[0]] = r["reasons"].get(failed[0], 0) + 1
        r["accepted"] = r["correct"] + r["wrong"]
        results[name] = r
        if verbose:
            print(f"  {name:<40} n={r['n']:4d}  " + _fmt(r), flush=True)

    t0 = time.time()
    for kind, builders in (("positive", positives()), ("negative", negatives())):
        for name, build in builders.items():
            # One-handed lines are complete without the second hand, so either
            # the true line or no prediction is right; only a WRONG line fails.
            scored_as = "partial" if name == "less active hand never detected" else kind
            rng = np.random.default_rng(seed)
            captures = []
            for i in held:
                c = caps[i]
                for raw, ts in build(c, by_source[c["source"]], rng):
                    captures.append((c["label"], raw, ts))
            tally(name, scored_as, captures)
    if calendar:
        cal = calendar_captures()
        if cal:
            tally("other signs (Calendar months)", "negative", [(-1, raw, ts) for raw, ts in cal])
    if verbose:
        print(f"  ({time.time() - t0:.0f}s)")
    return results


def _fmt(r):
    n = max(r["n"], 1)
    reasons = ", ".join(f"{k} {v}" for k, v in sorted(r["reasons"].items(), key=lambda kv: -kv[1])[:3])
    if r["kind"] in ("positive", "partial"):
        return (f"correct {r['correct'] / n:6.1%}  WRONG {r['wrong'] / n:5.1%}  "
                f"no prediction {r['abstain'] / n:6.1%}  | {reasons}")
    return f"PREDICTED {r['accepted'] / n:6.1%}  no prediction {r['abstain'] / n:6.1%}  | {reasons}"


def summarize(results):
    pos = [r for r in results.values() if r["kind"] == "positive"]
    neg = [r for r in results.values() if r["kind"] == "negative"]
    s = lambda rs, k: sum(r[k] for r in rs)
    part = [r for r in results.values() if r["kind"] == "partial"]
    return {
        "positive_n": s(pos, "n"),
        "true_accept_rate": s(pos, "correct") / max(s(pos, "n"), 1),
        "wrong_accept_rate": s(pos, "wrong") / max(s(pos, "n"), 1),
        "false_negative_rate": s(pos, "abstain") / max(s(pos, "n"), 1),
        "negative_n": s(neg, "n"),
        "false_positive_rate": s(neg, "accepted") / max(s(neg, "n"), 1),
        "complete_line_correct": results["complete line"]["correct"] / max(results["complete line"]["n"], 1),
        "partial_wrong_rate": s(part, "wrong") / max(s(part, "n"), 1),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", default="service", help="'service' (deployed ONNX) or a .pt checkpoint")
    ap.add_argument("--models-dir", help="inference-service models dir (default: the service's)")
    ap.add_argument("--heldout-sources", nargs="*", help="evaluate on these whole sources instead")
    ap.add_argument("--json", help="write per-scenario results here")
    ap.add_argument("--gate", nargs="*", default=[], metavar="KEY=VALUE",
                    help="override gate settings, JSON values (e.g. trim_still=false)")
    ap.add_argument("--no-calendar", action="store_true")
    args = ap.parse_args()

    caps = load_captures()
    held = heldout_split(caps, args.heldout_sources)
    decide = ServiceDecider(args.models_dir) if args.model == "service" else CheckpointDecider(args.model)
    for kv in args.gate:
        key, value = kv.split("=", 1)
        decide.gate[key] = json.loads(value)          # the decider's live gate dict
    print(f"{decide.name}: {len(held)} held-out real captures of {len(caps)}")
    print("gate: " + lc.format_gate(decide.gate))
    results = run_suite(decide, caps, held, calendar=not args.no_calendar)
    summ = summarize(results)
    print("\nSUMMARY  " + "  ".join(f"{k}={v:.3f}" if isinstance(v, float) else f"{k}={v}" for k, v in summ.items()))
    if args.json:
        Path(args.json).write_text(json.dumps({"model": decide.name, "summary": summ, "results": results},
                                              indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
