"""Extract the Lupang Hinirang dataset into fixed-length feature sequences.

    python extract_lupang_dataset.py [--workers 4] [--neg-count 128] [--force]

Pipeline per clip (all math lives in lupang_common.build_sequence):
    video --MediaPipe Holistic--> raw (N, 150)
          --trim idle edges, repair occluded pose points,
            bridge <=0.5 s hand dropouts-->
          --static_features--> (N, 163)
          --linear resample over time--> (32, 163)
          --append dx_t velocity--> (32, 181)

Outputs (in --out-dir):
    X_raw_lupang.npy      float32 (M, 32, 181)
    y_raw_lupang.npy      int64   (M,)   0..21 phrases, 22 INVALID_GESTURE
    groups_raw_lupang.npy str     (M,)   source/signer id of each sample
    kind_raw_lupang.npy   int64   (M,)   0 real, 1 partial, 2 frozen, 3 chimera, 4 fidget,
                                         5 transition, 6 double (see NEG_MIXES / --neg-mix)
    dur_raw_lupang.npy    float64 (M,)   active (hands-visible) duration in s, NaN for negatives
    lupang_meta.json      class names, feature names, counts
    lupang_landmarks_cache.pkl  raw MediaPipe output (re-used unless --force)

Augmentation is NOT done here; train_lupang_model.py augments the training
split only, so validation never contains copies of training clips.
"""
import argparse
import json
import multiprocessing as mp
import pickle
import sys
import time
from pathlib import Path

import numpy as np

import lupang_common as lc

KIND_REAL, KIND_PARTIAL, KIND_FROZEN, KIND_CHIMERA, KIND_FIDGET, KIND_TRANSITION, KIND_DOUBLE = range(7)
KIND_NAMES = ["real", "partial", "frozen", "chimera", "fidget", "transition", "double"]
VIDEO_EXTS = {".mp4", ".avi", ".mov", ".mkv"}


def list_videos(raw_dir):
    folders = sorted(d for d in raw_dir.iterdir() if d.is_dir())
    if len(folders) != lc.NUM_CLASSES - 1:
        raise SystemExit(f"Expected {lc.NUM_CLASSES - 1} class folders in {raw_dir}, "
                         f"found {len(folders)}")
    items = []
    for label, folder in enumerate(folders):
        prefix = int(folder.name.split("_", 1)[0])
        if prefix != label + 1:
            raise SystemExit(f"Folder {folder.name} is out of order (expected prefix {label + 1:02d})")
        vids = sorted(p for p in folder.iterdir() if p.suffix.lower() in VIDEO_EXTS)
        if not vids:
            print(f"  WARNING: no videos in {folder.name}")
        items += [(str(v), label) for v in vids]
    return folders, items


def _file_key(path):
    st = Path(path).stat()
    return (st.st_size, int(st.st_mtime))


def _extract_worker(path):
    try:
        raw, ts = lc.extract_raw_from_video(path)
        return path, raw, ts, None
    except Exception as exc:  # report and keep going
        return path, None, None, f"{type(exc).__name__}: {exc}"


def extract_all(items, cache_path, workers, force):
    cache = {}
    if cache_path.exists() and not force:
        with open(cache_path, "rb") as f:
            cache = pickle.load(f)
    todo = [p for p, _ in items
            if p not in cache or cache[p]["key"] != _file_key(p)
            or cache[p]["raw"].shape[1] != lc.RAW_DIM            # stale raw layout
            or cache[p].get("holistic") != lc.HOLISTIC_KWARGS]   # different MediaPipe settings
    print(f"{len(items)} videos, {len(items) - len(todo)} cached, {len(todo)} to extract "
          f"with {workers} worker(s)")
    if todo:
        t0 = time.time()
        if workers > 1:
            pool = mp.get_context("spawn").Pool(workers)
            results = pool.imap_unordered(_extract_worker, todo)
        else:
            pool, results = None, map(_extract_worker, todo)
        try:
            for i, (path, raw, ts, err) in enumerate(results, 1):
                if err:
                    print(f"  [{i}/{len(todo)}] FAILED {Path(path).name}: {err}")
                    continue
                cache[path] = {"key": _file_key(path), "raw": raw, "ts": ts,
                               "holistic": dict(lc.HOLISTIC_KWARGS)}
                if i % 10 == 0 or i == len(todo):
                    rate = i / (time.time() - t0)
                    print(f"  [{i}/{len(todo)}] {rate:.2f} videos/s, "
                          f"ETA {(len(todo) - i) / rate:.0f}s")
        finally:
            if pool is not None:
                pool.close()
                pool.join()
        with open(cache_path, "wb") as f:
            pickle.dump(cache, f)
    return cache


# ---------------------------------------------------------------------------
# Synthetic INVALID_GESTURE samples
# ---------------------------------------------------------------------------
# Pure noise is trivially separable and teaches nothing about rejection, so
# negatives are built from real landmark data that is *not* a complete phrase.
def neg_partial(rng, clip):
    """15-40 % fragment of a real phrase (start, middle or end)."""
    static, ts = clip["static"], clip["ts"]
    n = len(static)
    length = max(3, int(round(n * rng.uniform(0.15, 0.40))))
    start = rng.choice([0, n - length, rng.integers(0, max(1, n - length))])
    sl = slice(int(start), int(start) + length)
    return lc.add_velocity(lc.resample(static[sl], ts[sl]))


def neg_frozen(rng, clip):
    """One real frame held still (hand parked on the chest, no motion)."""
    frame = clip["static"][rng.integers(len(clip["static"]))]
    seq = np.repeat(frame[None], lc.T, axis=0)
    jitter = np.cumsum(rng.normal(0, 0.003, size=seq.shape), axis=0).astype(np.float32)
    seq = seq + jitter * (np.abs(seq) > 0)        # keep absent channels at exactly 0
    return lc.add_velocity(seq)


def neg_chimera(rng, clip_a, clip_b):
    """First half of phrase A spliced onto second half of phrase B (same
    signer), blended over a few frames so the cut is not a trivial cue."""
    def half(clip, first):
        st, ts = clip["static"], clip["ts"]
        cut = int(len(st) * rng.uniform(0.4, 0.6))
        sl = slice(0, max(cut, 2)) if first else slice(min(cut, len(st) - 2), len(st))
        return lc.resample(st[sl], ts[sl], lc.T // 2)
    a, b = half(clip_a, True), half(clip_b, False)
    k = 3
    w = np.linspace(0, 1, 2 * k)[:, None]
    blend = (1 - w) * a[-k:].mean(0) + w * b[:k].mean(0)
    seq = np.concatenate([a[:-k], blend, b[k:]], axis=0)
    return lc.add_velocity(seq)


def neg_fidget(rng, clip):
    """Real pose + handshape moved along a smooth random path (aimless motion)."""
    raw0 = clip["raw"][rng.integers(len(clip["raw"]))]
    n = int(rng.integers(30, 90))
    seq = np.repeat(raw0[None], n, axis=0).copy()
    pose = seq[:, lc.RAW_POSE].reshape(n, 7, 2)
    span = np.linalg.norm(pose[0, lc.P_LSH] - pose[0, lc.P_RSH]) + 1e-6
    for sl, flag, pw, pe in ((lc.RAW_LH, lc.RAW_FLAG_LH, lc.P_LWR, lc.P_LEL),
                             (lc.RAW_RH, lc.RAW_FLAG_RH, lc.P_RWR, lc.P_REL)):
        if raw0[flag] < 0.5:
            continue
        steps = np.cumsum(rng.normal(0, 1, size=(n + 8, 2)), axis=0)
        walk = np.stack([np.convolve(steps[:, k], np.ones(9) / 9, "valid") for k in range(2)], axis=1)
        walk = walk - walk[0]
        walk *= rng.uniform(0.1, 0.5) * span / (np.abs(walk).max() + 1e-6)
        h = seq[:, sl].reshape(n, 21, 3)
        h[..., :2] += walk[:, None]
        seq[:, sl] = h.reshape(n, 63)
        pose[:, pw] += walk
        pose[:, pe] += 0.5 * walk
    seq[:, lc.RAW_POSE] = pose.reshape(n, 14)
    out = lc.build_sequence(seq, np.arange(n) / 30.0, trim_still=clip.get("trim_still", False))
    return out


def neg_transition(rng, clip_a, clip_b):
    """End of phrase A run into the start of phrase B (same signer): what the
    camera sees between two lines, e.g. a student who starts the next line
    before the capture ends."""
    def part(clip, lo, hi, tail):
        st, ts = clip["static"], clip["ts"]
        k = max(3, int(round(len(st) * rng.uniform(lo, hi))))
        return (st[-k:], ts[-k:]) if tail else (st[:k], ts[:k])
    (sa, ta), (sb, tb) = part(clip_a, 0.3, 0.6, True), part(clip_b, 0.3, 0.6, False)
    return _joined(sa, ta, sb, tb)


def neg_double(rng, clip_a, clip_b):
    """Two complete phrases signed in one capture (same signer)."""
    return _joined(clip_a["static"], clip_a["ts"], clip_b["static"], clip_b["ts"])


def _joined(sa, ta, sb, tb):
    dt = float(np.median(np.diff(ta))) if len(ta) > 1 else 1 / 30
    ts = np.concatenate([ta - ta[0], tb - tb[0] + (ta[-1] - ta[0]) + dt])
    return lc.add_velocity(lc.resample(np.concatenate([sa, sb]), ts))


# Negative kinds and their shares. "v4" is the mix the deployed v4 model was
# trained with; "v5" adds transitions between lines and two lines in one
# capture, which v4 accepted as a (third) phrase in testing.
NEG_MIXES = {
    "v4": [(KIND_PARTIAL, 0.30), (KIND_FROZEN, 0.20), (KIND_CHIMERA, 0.25), (KIND_FIDGET, 0.25)],
    "v5": [(KIND_PARTIAL, 0.25), (KIND_FROZEN, 0.15), (KIND_CHIMERA, 0.15), (KIND_FIDGET, 0.15),
           (KIND_TRANSITION, 0.15), (KIND_DOUBLE, 0.15)],
}


def make_negatives(rng, clips, count, mix="v4"):
    by_source = {}
    for c in clips:
        by_source.setdefault(c["source"], []).append(c)
    makers = NEG_MIXES[mix]
    kinds = rng.choice([k for k, _ in makers], size=count, p=[p for _, p in makers])
    X, groups, kind_out = [], [], []
    attempts = 0
    for kind in kinds:
        while attempts < count * 20:
            attempts += 1
            clip = clips[rng.integers(len(clips))]
            if kind == KIND_PARTIAL:
                seq = neg_partial(rng, clip)
            elif kind == KIND_FROZEN:
                seq = neg_frozen(rng, clip)
            elif kind in (KIND_CHIMERA, KIND_TRANSITION, KIND_DOUBLE):
                mates = [c for c in by_source[clip["source"]] if c["label"] != clip["label"]]
                if not mates:
                    continue
                pair = {KIND_CHIMERA: neg_chimera, KIND_TRANSITION: neg_transition, KIND_DOUBLE: neg_double}[kind]
                seq = pair(rng, clip, mates[rng.integers(len(mates))])
            else:
                seq = neg_fidget(rng, clip)
            if seq is not None and np.isfinite(seq).all():
                X.append(seq)
                groups.append(clip["source"])
                kind_out.append(kind)
                break
    return X, groups, kind_out


def make_clip(path, label, raw, ts, trim_still=False):
    """One real clip -> dict with its cleaned raw / static features / (32, 181)
    sequence, built exactly as live inference builds it (trim_still included).
    Returns None if the clip has no usable hands."""
    hand_rate = float(((raw[:, lc.RAW_FLAG_LH] > 0.5) | (raw[:, lc.RAW_FLAG_RH] > 0.5)).mean()) if len(raw) else 0.0
    cleaned = lc.clean_sequence(raw, ts, trim_still=trim_still)
    if cleaned is None:
        return None
    raw_c, ts_c = cleaned
    static = lc.static_features(raw_c)
    return {
        "path": path, "label": label, "source": lc.source_id(path),
        "raw": raw_c, "ts": ts_c, "static": static, "hand_rate": hand_rate, "trim_still": trim_still,
        "seq": lc.add_velocity(lc.resample(static, ts_c)),
        "duration": float(ts_c[-1] - ts_c[0]),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raw-dir", type=Path, default=lc.RAW_DIR)
    ap.add_argument("--out-dir", type=Path, default=Path("."))
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--neg-count", type=int, default=128,
                    help="number of synthetic INVALID_GESTURE samples")
    ap.add_argument("--force", action="store_true", help="ignore the landmark cache")
    ap.add_argument("--neg-mix", choices=sorted(NEG_MIXES), default="v4",
                    help="kinds of synthetic negatives (v4 = the deployed v4 model's mix)")
    ap.add_argument("--no-trim-still", dest="trim_still", action="store_false",
                    help="keep still hands at the start / end of clips (v4 behaviour); must match "
                         "the gate's trim_still at inference")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    if not args.raw_dir.is_dir():
        raise SystemExit(f"Raw video directory not found: {args.raw_dir.resolve()}")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    folders, items = list_videos(args.raw_dir)
    cache = extract_all(items, args.out_dir / "lupang_landmarks_cache.pkl",
                        max(1, args.workers), args.force)

    clips, skipped = [], []
    for path, label in items:
        entry = cache.get(path)
        if entry is None:
            skipped.append((path, "extraction failed"))
            continue
        clip = make_clip(path, label, entry["raw"], entry["ts"], args.trim_still)
        if clip is None:
            skipped.append((path, "no usable hands"))
            continue
        clips.append(clip)
        hand_rate = clip["hand_rate"]
        if hand_rate < 0.5:
            print(f"  low hand detection {hand_rate:.0%}: {Path(path).name}")
    for path, why in skipped:
        print(f"  SKIPPED {Path(path).name}: {why}")
    if not clips:
        raise SystemExit("No usable clips extracted.")

    rng = np.random.default_rng(args.seed)
    X = [c["seq"] for c in clips]
    y = [c["label"] for c in clips]
    groups = [c["source"] for c in clips]
    kinds = [KIND_REAL] * len(clips)
    nX, ng, nk = make_negatives(rng, clips, args.neg_count, args.neg_mix)
    X += nX
    y += [lc.INVALID_IDX] * len(nX)
    groups += ng
    kinds += nk
    durations = [c["duration"] for c in clips] + [np.nan] * len(nX)

    X = np.stack(X).astype(np.float32)
    y = np.array(y, dtype=np.int64)
    assert X.shape[1:] == (lc.T, lc.FEATURE_DIM) and np.isfinite(X).all()

    out = args.out_dir
    np.save(out / "X_raw_lupang.npy", X)
    np.save(out / "y_raw_lupang.npy", y)
    np.save(out / "groups_raw_lupang.npy", np.array(groups))
    np.save(out / "kind_raw_lupang.npy", np.array(kinds, dtype=np.int64))
    np.save(out / "dur_raw_lupang.npy", np.array(durations, dtype=np.float64))
    counts = np.bincount(y, minlength=lc.NUM_CLASSES)
    meta = {
        "feature_version": lc.FEATURE_VERSION,
        "T": lc.T,
        "feature_dim": lc.FEATURE_DIM,
        "class_names": lc.CLASS_NAMES,
        "folders": [f.name for f in folders],
        "feature_names": lc.FEATURE_NAMES,
        "class_counts": counts.tolist(),
        "negative_kinds": {KIND_NAMES[k]: int(np.sum(np.array(kinds) == k)) for k in range(1, len(KIND_NAMES))},
        "neg_mix": args.neg_mix,
        "trim_still": args.trim_still,
        "skipped": [Path(p).name for p, _ in skipped],
    }
    with open(out / "lupang_meta.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)

    print(f"\nX_raw_lupang.npy {X.shape}  y_raw_lupang.npy {y.shape}")
    print(f"per frame: {lc.S_DIM} static + {lc.FEATURE_DIM - lc.S_DIM} velocity = {lc.FEATURE_DIM}")
    for i, name in enumerate(lc.CLASS_NAMES):
        print(f"  [{i:02d}] {name:<40} {counts[i]:3d}")
    print(f"negatives by kind: {meta['negative_kinds']}")


if __name__ == "__main__":
    sys.exit(main())
