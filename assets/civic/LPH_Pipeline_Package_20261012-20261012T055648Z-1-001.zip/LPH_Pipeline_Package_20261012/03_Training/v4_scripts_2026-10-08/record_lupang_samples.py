import cv2
import os
import time

TARGET_CLASSES = {
    "1": ("08_Di_ka_pasisiil", "Di ka pasisiil"),
    "2": ("15_Ang_bituin_at_araw_niya", "Ang bituin at araw niya"),
    "3": ("16_Kailan_pa_may_di_magdidilim", "Kailan pa ma'y di magdidilim"),
    "4": ("19_Aming_ligaya", "Aming ligaya")
}

BASE_DIR = r"specialists\civic_observances\raw\lupang_hinirang"

print("Piliin ang phrase na ire-record:")
for k, v in TARGET_CLASSES.items():
    print(f"[{k}] {v[1]} ({v[0]})")

choice = input("Pumili ng numero (1-4): ").strip()
if choice not in TARGET_CLASSES:
    print("Invalid choice.")
    exit()

folder_name, display_name = TARGET_CLASSES[choice]
target_dir = os.path.join(BASE_DIR, folder_name)
os.makedirs(target_dir, exist_ok=True)

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
recording = False
out = None

print(f"\nNakahanda para sa: {display_name}")
print("SPACEBAR: Simulan / Itigil ang pag-record")
print("Q: Lumabas\n")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    h, w, _ = frame.shape
    display_frame = frame.copy()

    if recording:
        out.write(frame)
        cv2.circle(display_frame, (30, 30), 12, (0, 0, 255), -1)
        cv2.putText(display_frame, f"RECORDING: {display_name}", (50, 35),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    else:
        cv2.putText(display_frame, f"STANDBY: Pindutin ang SPACE para mag-record", (30, 35),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    cv2.imshow("Record FSL Clips", display_frame)
    key = cv2.waitKey(1) & 0xFF

    if key == 32:  # SPACEBAR
        if not recording:
            timestamp = int(time.time())
            filename = os.path.join(target_dir, f"webcam_take_{timestamp}.mp4")
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(filename, fourcc, 20.0, (w, h))
            recording = True
            print(f"-> Nagsimula mag-record: {filename}")
        else:
            recording = False
            out.release()
            print("-> Naitabi ang clip!")
    elif key == ord('q'):
        break

if recording and out:
    out.release()
cap.release()
cv2.destroyAllWindows()
