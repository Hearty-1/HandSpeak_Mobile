"""Export a specialist checkpoint for the Cloud Run inference service.

    python export_lupang_onnx.py                          # Lupang Hinirang (palm_lupang_best.pt)
    python export_lupang_onnx.py --specialist calendar    # Calendar (specialists/calendar/...)

Writes (Lupang / Calendar)
    fsl_lupang_hinirang_v4.onnx / fsl_calendar_v1.onnx
        input "features" (batch, 32, 181) float32 -> output "logits" (batch, n_classes).
        Feature standardisation is inside the graph.
    lupang_hinirang_v4.json / calendar_v1.json
        model id, class names, feature version / names, T, MediaPipe settings and
        the full rejection gate (specialist defaults + calibrated values from the
        checkpoint, incl. invalid_index and trim_still).
and copies lupang_common.py into inference-service/app/ (the service imports it
for the exact same landmark -> feature pipeline and gates).
Verifies ONNX Runtime output against PyTorch on real dataset samples.
"""
import argparse
import json
import shutil
from pathlib import Path

import numpy as np
import torch

import lupang_common as lc

HERE = Path(__file__).resolve().parent


def specialist_spec(name):
    """Per-specialist export settings."""
    if name == "lupang":
        return {"model_id": "lupang_hinirang", "model": HERE / "palm_lupang_best.pt",
                "onnx": "fsl_lupang_hinirang_v4.onnx", "meta": "lupang_hinirang_v4.json", "labels": None,
                "base_gate": {**lc.GATE_DEFAULTS, **lc.LUPANG_RELIABILITY}, "duration_overrides": None,
                "parity_data": HERE / "X_raw_lupang.npy"}
    if name == "calendar":
        import calendar_common as cc
        return {"model_id": "calendar", "model": cc.MODEL_PATH,
                "onnx": "fsl_calendar_v1.onnx", "meta": "calendar_v1.json", "labels": cc.LABELS_FIL,
                "base_gate": cc.GATE_DEFAULTS, "duration_overrides": {},
                "parity_data": cc.DATA_FILES["X"]}
    raise SystemExit(f"unknown specialist {name!r}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--specialist", choices=["lupang", "calendar"], default="lupang")
    ap.add_argument("--model", type=Path, default=None, help="checkpoint (default: the specialist's)")
    ap.add_argument("--out-dir", type=Path, default=HERE / "inference-service" / "models")
    ap.add_argument("--app-dir", type=Path, default=HERE / "inference-service" / "app")
    args = ap.parse_args()
    spec = specialist_spec(args.specialist)
    args.model = args.model or spec["model"]

    model, ckpt = lc.load_model(args.model)
    model.eval()
    onnx_path = args.out_dir / spec["onnx"]
    meta_path = args.out_dir / spec["meta"]
    args.out_dir.mkdir(parents=True, exist_ok=True)

    dummy = torch.zeros(1, lc.T, lc.FEATURE_DIM)
    torch.onnx.export(model, dummy, str(onnx_path), input_names=["features"], output_names=["logits"],
                      dynamic_axes={"features": {0: "batch"}, "logits": {0: "batch"}},
                      opset_version=17, dynamo=False)

    gate = dict(spec["base_gate"])
    gate.update({k: v for k, v in ckpt.get("metrics", {}).get("gate", {}).items() if k in spec["base_gate"]})
    gate["class_min_duration"] = lc.apply_class_duration_overrides(gate["class_min_duration"],
                                                                   spec["duration_overrides"])
    invalid_index = int(gate.get("invalid_index", lc.INVALID_IDX))
    if ckpt["class_names"][invalid_index] != "INVALID_GESTURE":
        raise SystemExit(f"class {invalid_index} is {ckpt['class_names'][invalid_index]!r}, expected INVALID_GESTURE")
    meta = {
        "model_id": spec["model_id"],
        "onnx_file": onnx_path.name,
        "feature_version": lc.FEATURE_VERSION,
        "T": lc.T,
        "feature_dim": lc.FEATURE_DIM,
        "feature_names": lc.FEATURE_NAMES,
        "class_names": ckpt["class_names"],
        # Shown to users as "label"; class_names is returned as "label_en".
        "display_labels": spec["labels"] or ckpt["class_names"],
        "invalid_index": invalid_index,
        "holistic_settings": lc.HOLISTIC_KWARGS,
        "gate": gate,
        "training_metrics": {k: v for k, v in ckpt.get("metrics", {}).items() if k != "gate"},
        "source_checkpoint": args.model.name,
    }
    meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    shutil.copyfile(HERE / "lupang_common.py", args.app_dir / "lupang_common.py")

    # Parity check: ONNX Runtime vs PyTorch on real samples (batch of 2 = live TTA shape too).
    import onnxruntime as ort
    sess = ort.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
    X = np.load(spec["parity_data"])[:64].astype(np.float32)
    with torch.no_grad():
        ref = model(torch.from_numpy(X)).numpy()
    got = np.concatenate([sess.run(["logits"], {"features": X[i:i + 2]})[0] for i in range(0, len(X), 2)])
    err = float(np.abs(ref - got).max())
    agree = float(np.mean(ref.argmax(1) == got.argmax(1)))
    print(f"wrote {onnx_path} ({onnx_path.stat().st_size / 1e6:.1f} MB), {meta_path.name}, app/lupang_common.py")
    print(f"ONNX vs PyTorch on {len(X)} samples: max |logit diff| {err:.2e}, top-1 agreement {agree:.0%}")
    if err > 1e-3 or agree < 1.0:
        raise SystemExit("ONNX export does not match PyTorch")


if __name__ == "__main__":
    main()
