"""Signer-independent comparison of Lupang Hinirang model variants and decision rules.

    python compare_lupang_variants.py [--rescore-v4-trim] [--json reports/lupang_retrain/compare.json]

Every variant is scored on the SAME held-out test captures of the 5 source
folds of retrain_lupang_grouped.py (complete lines + raw-landmark negative
scenarios; each capture comes from sources its model never trained on):

    v4 trim off   deployed v4 recipe, idle edges NOT trimmed  (= live_lupang_engine2.py)
    v4 trim on    same models, idle edges trimmed at inference (= live_lupang_engine.py /
                  the production gate, trim_still=True) - needs --rescore-v4-trim once
    v5 single     the staged recipe (one model per fold)
    v5 ens3       mean probabilities of 3 v5 models per fold whose inner validation
                  held out different sources (members 0-2)

Decision rules (the live decision, lupang_common.evaluate_capture logic):
    fixed 0.65    min_conf 0.65 / min_margin 0.20 (deployed v4 and engine2)
    fixed 0.90    min_conf 0.90 / min_margin 0.20 (staged v5)
    LOFO          per test fold, thresholds chosen ONLY on the other 4 folds' held-out
                  captures: highest correct-accept rate with wrong <= 2 % and
                  false accept <= 2 %, never below 0.65 / 0.20
Only min_conf / min_margin vary; every other gate (INVALID, entropy, durations,
kinematics, coverage, stability) is applied unchanged.
"""
import argparse
import json
import pickle
from pathlib import Path

import numpy as np

import lupang_common as lc
import retrain_lupang_grouped as R
from cv_lupang import RECIPES, build_training_set
from test_lupang_recognition import load_captures

HERE = Path(__file__).resolve().parent
CV = HERE / "cv_runs"
FLOOR_C, FLOOR_M, TGT_W, TGT_F = 0.65, 0.20, 0.02, 0.02
CONFS = np.round(np.arange(0.50, 0.96, 0.05), 2)
MARGINS = np.round(np.arange(0.10, 0.81, 0.05), 2)
NEG_GROUPS = {"incomplete (4 kinds)": lambda s: s.startswith("incomplete"),
              "transition A->B": lambda s: s.startswith("transition"),
              "two lines": lambda s: s.startswith("two lines"),
              "random movement": lambda s: s.startswith("random"),
              "idle / no hands / out of frame / 25% hands": lambda s: s.split(":")[0] in (
                  "idle", "no hands in view", "hands below the image edge", "hands found in only 25% of frames")}


def _load(path):
    with open(path, "rb") as fh:
        return pickle.load(fh)


def fold_files(d, pattern):
    return [d / pattern.format(f=f) for f in range(5)]


def rescore_v4_trim(caps, seed=42):
    """Score the v4 fold models' test captures with trim_still=True (production gate)."""
    d = CV / "v4_grouped"
    for f in range(5):
        out = d / f"fold{f}_scored_trimon.pkl"
        if out.exists():
            continue
        fd = _load(d / f"fold{f}_scored.pkl")
        gate = {**fd["meta"]["gate"], "trim_still": True}
        srcs = fd["meta"]["test_sources"]
        test = [i for i, c in enumerate(caps) if c["source"] in srcs]
        recs = R.score_set(R.Scorer(d / f"fold{f}.pt"), gate, R.scenario_captures(caps, test, seed + 100 + f))
        with open(out, "wb") as fh:
            pickle.dump({"meta": {**fd["meta"], "gate": gate}, "test": recs}, fh)
        print(f"rescored v4 fold {f} with trim_still=True")


def ensemble_folds(caps, members=3, seed=42):
    """Average members' test probabilities per capture; gate calibrated on ALL
    of the fold's training sources (what the ensemble jointly trained on)."""
    d = CV / "v5_grouped"
    out = []
    for f in range(5):
        parts = [_load(d / (f"fold{f}_scored.pkl" if m == 0 else f"fold{f}_m{m}_scored.pkl")) for m in range(members)]
        recs0 = parts[0]["test"]
        for p in parts[1:]:
            assert [(r["scenario"], r["cap"], r["label"]) for r in p["test"]] == \
                   [(r["scenario"], r["cap"], r["label"]) for r in recs0], "members scored different captures"
        merged = []
        for k, r in enumerate(recs0):
            m = dict(r)
            if r.get("probs") is not None:
                m["probs"] = np.mean([p["test"][k]["probs"] for p in parts], axis=0)
                m["view_probs"] = np.mean([p["test"][k]["view_probs"] for p in parts], axis=0)
            merged.append(m)
        srcs = parts[0]["meta"]["test_sources"]
        rest = [i for i, c in enumerate(caps) if c["source"] not in srcs]
        X, y, d_ = build_training_set(caps, rest, RECIPES["v5"], np.random.default_rng(seed + f))
        out.append({"meta": {"gate": R.fold_gate(X, y, d_), "test_sources": srcs}, "test": merged})
    return out


def table(folds, caps):
    """Per capture: fold, kind, scenario, label, source, base_ok (all checks except
    conf / margin pass), top, p1, margin, closed-set prediction."""
    rows = []
    for f, fd in enumerate(folds):
        g0 = {**fd["meta"]["gate"], "min_conf": 0.0, "min_margin": 0.0, "min_margin_vs_invalid": 0.0}
        for r in fd["test"]:
            ok, top, _ = R.decide(r, g0)
            p = r.get("probs")
            if p is None:
                p1 = mg = 0.0
                closed = -1
            else:
                s = np.sort(p)[::-1]
                p1, mg = float(s[0]), float(s[0] - s[1])
                closed = int(np.argmax(p[:lc.INVALID_IDX]))
            rows.append((f, r["kind"], r["scenario"], r["label"], caps[r["cap"]]["source"], bool(ok),
                         -1 if top is None else top, p1, mg, closed))
    cols = list(zip(*rows))
    names = ["fold", "kind", "scenario", "label", "source", "base_ok", "top", "p1", "margin", "closed"]
    return {n: np.array(c) for n, c in zip(names, cols)}


def accepted(t, conf, margin):
    return t["base_ok"] & (t["p1"] >= conf) & (t["margin"] >= margin)


def rates(t, acc, mask=None):
    m = np.ones(len(acc), bool) if mask is None else mask
    pos, neg, part = m & (t["kind"] == "positive"), m & (t["kind"] == "negative"), m & (t["kind"] == "partial")
    comp = m & (t["scenario"] == "complete line")
    ok = acc & (t["top"] == t["label"])
    out = {"tar": ok[pos].mean(), "war": (acc & ~ok)[pos].mean(), "far": acc[neg].mean(),
           "complete_correct": ok[comp].mean(), "complete_wrong": (acc & ~ok)[comp].mean(),
           "complete_nopred": (~acc)[comp].mean(), "partial_wrong": (acc & ~ok)[part].mean() if part.any() else 0.0,
           "n_complete": int(comp.sum()), "n_pos": int(pos.sum()), "n_neg": int(neg.sum())}
    for name, pred in NEG_GROUPS.items():
        g = neg & np.array([pred(s) for s in t["scenario"]])
        out["far: " + name] = acc[g].mean() if g.any() else float("nan")
    return {k: float(v) if not isinstance(v, int) else v for k, v in out.items()}


def lofo_thresholds(t, folds=range(5)):
    """Per fold: thresholds chosen on the OTHER folds only (fold -1: on all folds)."""
    chosen = {}
    for f in folds:
        other = t["fold"] != f
        best, fallback = None, None
        for c in CONFS:
            for mg in MARGINS:
                if c < FLOOR_C or mg < FLOOR_M:
                    continue
                r = rates(t, accepted(t, c, mg), other)
                key = (r["tar"], -c, -mg)
                if r["war"] <= TGT_W and r["far"] <= TGT_F and (best is None or key > best[0]):
                    best = (key, float(c), float(mg))
                fk = (-(r["war"] + r["far"]), r["tar"])
                if fallback is None or fk > fallback[0]:
                    fallback = (fk, float(c), float(mg))
        chosen[f] = (best or fallback)[1:] + (best is not None,)
    return chosen


def lofo_accept(t, chosen):
    acc = np.zeros(len(t["fold"]), bool)
    for f, (c, mg, _) in chosen.items():
        m = t["fold"] == f
        acc[m] = accepted({k: v[m] for k, v in t.items()}, c, mg)
    return acc


def per_line(t, acc):
    comp = t["scenario"] == "complete line"
    y, pred = t["label"][comp], np.where(acc[comp], t["top"][comp], -1)
    out = []
    for c in range(lc.INVALID_IDX):
        tp = int(((pred == c) & (y == c)).sum())
        fp = int(((pred == c) & (y != c)).sum())
        fn = int(((pred != c) & (y == c)).sum())
        p = tp / (tp + fp) if tp + fp else 0.0
        r = tp / (tp + fn) if tp + fn else 0.0
        out.append({"index": c, "line": lc.CLASS_NAMES[c], "n": tp + fn, "precision": p, "recall": r,
                    "f1": 2 * p * r / (p + r) if p + r else 0.0, "wrong_accepts_as_this_line": fp})
    return out


def closed_metrics(t):
    comp = t["scenario"] == "complete line"
    y, pr = t["label"][comp], t["closed"][comp]
    f1 = []
    for c in range(lc.INVALID_IDX):
        tp, fp, fn = ((pr == c) & (y == c)).sum(), ((pr == c) & (y != c)).sum(), ((pr != c) & (y == c)).sum()
        p, r = (tp / (tp + fp) if tp + fp else 0.0), (tp / (tp + fn) if tp + fn else 0.0)
        f1.append(2 * p * r / (p + r) if p + r else 0.0)
    return {"closed_acc": float((pr == y).mean()), "closed_macro_f1": float(np.mean(f1))}


def bootstrap_diff(ta, acc_a, tb, acc_b, n=2000, seed=0):
    """Source-cluster bootstrap of the difference in complete-line correct rate (b - a)."""
    rng = np.random.default_rng(seed)
    comp = ta["scenario"] == "complete line"
    assert (tb["scenario"] == ta["scenario"]).all() and (tb["label"] == ta["label"]).all()
    srcs = np.unique(ta["source"][comp])
    ok_a = (acc_a & (ta["top"] == ta["label"]))[comp]
    ok_b = (acc_b & (tb["top"] == tb["label"]))[comp]
    src = ta["source"][comp]
    idx = {s: np.flatnonzero(src == s) for s in srcs}
    diffs = []
    for _ in range(n):
        pick = np.concatenate([idx[s] for s in rng.choice(srcs, len(srcs))])
        diffs.append(ok_b[pick].mean() - ok_a[pick].mean())
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    return float(ok_b.mean() - ok_a.mean()), float(lo), float(hi)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rescore-v4-trim", action="store_true")
    ap.add_argument("--final-gate", help="write the deployable v5-ensemble gate (thresholds chosen on ALL "
                                         "folds' held-out captures + kinematics / durations on all clips) here")
    ap.add_argument("--json", default=str(HERE / "reports" / "lupang_retrain" / "compare.json"))
    args = ap.parse_args()
    caps = load_captures()
    if args.final_gate:
        t = table(ensemble_folds(caps), caps)
        c, mg, ok = lofo_thresholds(t, folds=[-1])[-1]
        X, y, d_ = build_training_set(caps, list(range(len(caps))), RECIPES["v5"], np.random.default_rng(42))
        gate = {**R.fold_gate(X, y, d_), "min_conf": c, "min_margin": mg, "min_margin_vs_invalid": mg}
        r = rates(t, accepted(t, c, mg))
        Path(args.final_gate).write_text(json.dumps({k: v for k, v in gate.items() if k != "trim_still" or True},
                                                    indent=2), encoding="utf-8")
        print(f"final gate: min_conf {c:.2f} min_margin {mg:.2f} (targets met: {ok}); pooled held-out: "
              + "  ".join(f"{k}={v:.3f}" for k, v in r.items() if isinstance(v, float)))
        return 0
    if args.rescore_v4_trim:
        rescore_v4_trim(caps)
    variants = {
        "v4 trim off (engine2)": [_load(p) for p in fold_files(CV / "v4_grouped", "fold{f}_scored.pkl")],
        "v5 single (staged)": [_load(p) for p in fold_files(CV / "v5_grouped", "fold{f}_scored.pkl")],
    }
    if all(p.exists() for p in fold_files(CV / "v4_grouped", "fold{f}_scored_trimon.pkl")):
        variants["v4 trim on (engine/prod)"] = [_load(p) for p in fold_files(CV / "v4_grouped", "fold{f}_scored_trimon.pkl")]
    if all(p.exists() for p in fold_files(CV / "v5_grouped", "fold{f}_m2_scored.pkl")):
        variants["v5 ens3"] = ensemble_folds(caps)
    report, tables, accs = {}, {}, {}
    for name, folds in variants.items():
        t = table(folds, caps)
        tables[name] = t
        chosen = lofo_thresholds(t)
        rules = {"fixed 0.65/0.20": accepted(t, 0.65, 0.20), "fixed 0.90/0.20": accepted(t, 0.90, 0.20),
                 "LOFO": lofo_accept(t, chosen)}
        webcam = t["source"] == "webcam_take"
        rep = {**closed_metrics(t), "lofo_thresholds": {str(f): list(v) for f, v in chosen.items()}, "rules": {}}
        for rn, acc in rules.items():
            accs[(name, rn)] = acc
            rep["rules"][rn] = {**rates(t, acc), "webcam_take (your recordings)": rates(t, acc, webcam),
                                "per_line": per_line(t, acc)}
        report[name] = rep
        print(f"\n=== {name} ===  closed-set acc {rep['closed_acc']:.3f}  macro-F1 {rep['closed_macro_f1']:.3f}  "
              f"LOFO thresholds " + ", ".join(f"f{f}:{c:.2f}/{m:.2f}{'' if ok else '(targets unmet)'}"
                                              for f, (c, m, ok) in chosen.items()))
        for rn in rules:
            r = rep["rules"][rn]
            w = r["webcam_take (your recordings)"]
            print(f"  {rn:<16} complete: correct {r['complete_correct']:.3f} wrong {r['complete_wrong']:.3f} "
                  f"nopred {r['complete_nopred']:.3f} | all-pos TAR {r['tar']:.3f} WAR {r['war']:.3f} | FAR {r['far']:.3f} "
                  f"(incompl {r['far: incomplete (4 kinds)']:.3f}, 2 lines {r['far: two lines']:.3f}, "
                  f"random {r['far: random movement']:.3f}) | your clips correct {w['complete_correct']:.3f} "
                  f"wrong {w['complete_wrong']:.3f} (n={w['n_complete']})")
    base = "v5 single (staged)"
    report["bootstrap_complete_correct_diff"] = {}
    for name in variants:
        if name == base:
            continue
        for rn in ("fixed 0.65/0.20", "LOFO"):
            d, lo, hi = bootstrap_diff(tables[base], accs[(base, rn)], tables[name], accs[(name, rn)])
            report["bootstrap_complete_correct_diff"][f"{name} - {base} [{rn}]"] = [d, lo, hi]
            print(f"  {name} minus {base} [{rn}]: complete-line correct {d:+.3f} (95% CI {lo:+.3f} .. {hi:+.3f})")
    Path(args.json).write_text(json.dumps(report, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
