"""Per-line, signer-independent evaluation of Lupang Hinirang model variants, including webcam conditions.

    python evaluate_lupang_lines.py [--variants "v5 ens3" "v6 ens3" ...] [--json reports/lupang_retrain/lines.json]

Every variant is evaluated on the held-out folds of retrain_lupang_grouped.py
(a capture is only ever scored by models that never trained on its source):

  clean       complete lines + raw-landmark negative scenarios of the reference clips
              (the *_scored.pkl test records written by `retrain_lupang_grouped.py cv`)
  webcam-sim  the same held-out clips passed through lupang_degrade.degrade_capture
              (20 fps, motion-correlated hand misses, calibrated to the user's webcam takes):
              complete line (positive), first half / second half (incomplete, negative),
              two lines of the same signer (negative). Identical captures for every variant.
  your takes  the clean records of source webcam_take (the user's real webcam recordings;
              fold 3 - no fold-3 model trained on them)

Decision: lupang_common.evaluate_capture logic with each fold's gate. min_conf /
min_margin are chosen per test fold ONLY on the other folds' clean + webcam-sim
captures (highest correct-accept rate with wrong <= 2 % and false accept <= 2 %,
never below 0.65 / 0.20); fixed 0.65 / 0.20 is reported as well.

Per line it separates: correct accept, confidently WRONG accept, and the reason for
"no prediction": the true line was top-1 but under the thresholds (low confidence
/ margin / stability), INVALID_GESTURE was top-1, another line was top-1, or a
pre-check failed before the model ran.
"""
import argparse
import json
import pickle
from pathlib import Path

import numpy as np

import lupang_common as lc
import retrain_lupang_grouped as R
from cv_lupang import build_training_set
from lupang_degrade import degrade_capture
from test_lupang_recognition import _active, _concat, _cut, load_captures

HERE = Path(__file__).resolve().parent
CV = HERE / "cv_runs"
FLOOR_C, FLOOR_M, TGT_W, TGT_F = 0.65, 0.20, 0.02, 0.02
CONFS = np.round(np.arange(0.50, 0.96, 0.05), 2)
MARGINS = np.round(np.arange(0.10, 0.81, 0.05), 2)
VARIANTS = {                       # name: (cv directory, members, recipe)
    "v4 (engine2 model)": ("v4_grouped", 1, "v4"),
    "v5 single": ("v5_grouped", 1, "v5"),
    "v5 ens3 (staged)": ("v5_grouped", 3, "v5"),
    "v6 single": ("v6_grouped", 1, "v6"),
    "v6p single": ("v6p_grouped", 1, "v6p"),
    "v6 ens3": ("v6_grouped", 3, "v6"),
    "v6p ens3": ("v6p_grouped", 3, "v6p"),
}
AFFECTED = [4, 5, 7, 9, 10, 12, 13, 14, 16, 19, 20, 1]   # 0-based indices of the lines reported by the user


def _load(p):
    with open(p, "rb") as fh:
        return pickle.load(fh)


def _suffix(m):
    return "" if m == 0 else f"_m{m}"


def available(d, members):
    return all((CV / d / f"fold{f}{_suffix(m)}_scored.pkl").exists() for f in range(5) for m in range(members))


def merge(parts, key):
    """Average probabilities of members' records (identical captures, identical order)."""
    base = parts[0][key]
    out = []
    for k, r in enumerate(base):
        m = dict(r)
        if r.get("probs") is not None:
            m["probs"] = np.mean([p[key][k]["probs"] for p in parts], axis=0)
            m["view_probs"] = np.mean([p[key][k]["view_probs"] for p in parts], axis=0)
        out.append(m)
    return out


def fold_gates(d, members, recipe, caps):
    """Single model: its own gate. Ensemble: calibrated on all of the fold's training sources."""
    if members == 1:
        return [_load(CV / d / f"fold{f}_scored.pkl")["meta"]["gate"] for f in range(5)]
    folds = json.loads((CV / d / "folds.json").read_text(encoding="utf-8"))
    gates = []
    for f, srcs in enumerate(folds):
        rest = [i for i, c in enumerate(caps) if c["source"] not in srcs]
        X, y, dur = build_training_set(caps, rest, R.RECIPES[recipe], np.random.default_rng(42 + f))
        gates.append({**R.fold_gate(X, y, dur), "trim_still": R.RECIPES[recipe]["trim_still"]})
    return gates


def clean_folds(d, members, gates):
    out = []
    for f in range(5):
        parts = [_load(CV / d / f"fold{f}{_suffix(m)}_scored.pkl") for m in range(members)]
        out.append({"gate": gates[f], "recs": merge(parts, "test") if members > 1 else parts[0]["test"]})
    return out


def sim_captures(caps, test_idx, fold):
    """Webcam-degraded scenarios of the fold's held-out clips (deterministic per clip)."""
    by_src = {}
    for i in test_idx:
        by_src.setdefault(caps[i]["source"], []).append(i)
    deg = {}
    for i in test_idx:
        raw, ts = degrade_capture(caps[i]["raw"], caps[i]["ts"], np.random.default_rng(10_000 * fold + i))
        if ((raw[:, lc.RAW_FLAG_LH] > 0.5) | (raw[:, lc.RAW_FLAG_RH] > 0.5)).any():
            deg[i] = {"raw": raw, "ts": ts}
    out = []
    for i, c in deg.items():
        lab = caps[i]["label"]
        out.append(("webcam-sim complete line", "positive", lab, i, c["raw"], c["ts"]))
        act = _active(c)
        for name, a, b in (("webcam-sim incomplete: first half", 0.0, 0.5),
                           ("webcam-sim incomplete: second half", 0.5, 1.0)):
            raw, ts = _cut(*act, a, b)
            out.append((name, "negative", lab, i, raw, ts))
        mates = [j for j in by_src[caps[i]["source"]] if caps[j]["label"] != lab and j in deg]
        if mates:
            j = mates[np.random.default_rng(i).integers(len(mates))]
            raw, ts = _concat([act, _active(deg[j])])
            out.append(("webcam-sim two lines", "negative", lab, i, raw, ts))
    return out


def sim_folds(d, members, gates, caps):
    folds = json.loads((CV / d / "folds.json").read_text(encoding="utf-8"))
    out = []
    for f, srcs in enumerate(folds):
        cache = CV / d / f"fold{f}_sim_ens{members}.pkl"
        if cache.exists():
            out.append({"gate": gates[f], "recs": _load(cache)})
            continue
        test = [i for i, c in enumerate(caps) if c["source"] in srcs]
        scorers = [R.Scorer(CV / d / f"fold{f}{_suffix(m)}.pt") for m in range(members)]
        recs = []
        for scen, kind, lab, i, raw, ts in sim_captures(caps, test, f):
            parts = [s.score(raw, ts, gates[f]) for s in scorers]
            r = parts[0]
            if members > 1 and r.get("probs") is not None:
                r["probs"] = np.mean([p["probs"] for p in parts], axis=0)
                r["view_probs"] = np.mean([p["view_probs"] for p in parts], axis=0)
            r.update(scenario=scen, kind=kind, label=lab, cap=i)
            recs.append(r)
        with open(cache, "wb") as fh:
            pickle.dump(recs, fh)
        out.append({"gate": gates[f], "recs": recs})
    return out


def table(folds, caps):
    rows = []
    for f, fd in enumerate(folds):
        g0 = {**fd["gate"], "min_conf": 0.0, "min_margin": 0.0, "min_margin_vs_invalid": 0.0}
        for r in fd["recs"]:
            ok, top, failed = R.decide(r, g0)
            p = r.get("probs")
            if p is None:
                p1 = mg = 0.0
                top1 = -1
            else:
                s = np.sort(p)[::-1]
                p1, mg, top1 = float(s[0]), float(s[0] - s[1]), int(np.argmax(p))
            rows.append((f, r["kind"], r["scenario"], r["label"], caps[r["cap"]]["source"], bool(ok), top1, p1, mg,
                         int(np.argmax(p[:lc.INVALID_IDX])) if p is not None else -1))
    names = ["fold", "kind", "scenario", "label", "source", "base_ok", "top1", "p1", "margin", "closed"]
    return {n: np.array(c) for n, c in zip(names, zip(*rows))}


def cat(a, b):
    return {k: np.concatenate([a[k], b[k]]) for k in a}


def accepted(t, c, m):
    return t["base_ok"] & (t["p1"] >= c) & (t["margin"] >= m)


def summary(t, acc, mask=None):
    m = np.ones(len(acc), bool) if mask is None else mask
    pos, neg = m & (t["kind"] == "positive"), m & (t["kind"] == "negative")
    comp = m & np.isin(t["scenario"], ["complete line", "webcam-sim complete line"])
    ok = acc & (t["top1"] == t["label"])
    f = lambda x, mm: float(x[mm].mean()) if mm.any() else float("nan")
    return {"complete_correct": f(ok, comp), "complete_wrong": f(acc & ~ok, comp), "complete_nopred": f(~acc, comp),
            "all_pos_correct": f(ok, pos), "all_pos_wrong": f(acc & ~ok, pos), "false_accept": f(acc, neg),
            "n_complete": int(comp.sum()), "n_neg": int(neg.sum())}


def lofo(t):
    chosen = {}
    for f in range(5):
        other = t["fold"] != f
        best = fb = None
        for c in CONFS:
            for mg in MARGINS:
                if c < FLOOR_C or mg < FLOOR_M:
                    continue
                s = summary(t, accepted(t, c, mg), other)
                if s["all_pos_wrong"] <= TGT_W and s["false_accept"] <= TGT_F:
                    k = (s["all_pos_correct"], -c, -mg)
                    if best is None or k > best[0]:
                        best = (k, float(c), float(mg))
                k2 = (-(s["all_pos_wrong"] + s["false_accept"]), s["all_pos_correct"])
                if fb is None or k2 > fb[0]:
                    fb = (k2, float(c), float(mg))
        chosen[f] = (best or fb)[1:] + (best is not None,)
    return chosen


def apply(t, chosen):
    acc = np.zeros(len(t["fold"]), bool)
    for f, (c, mg, _) in chosen.items():
        m = t["fold"] == f
        acc[m] = t["base_ok"][m] & (t["p1"][m] >= c) & (t["margin"][m] >= mg)
    return acc


def per_line(t, acc, scen):
    """Complete lines of scenario `scen`: outcome breakdown and confusion matrix (22 x 24:
    22 lines + INVALID top-1 + pre-check rejection) of the top-1 class."""
    m = t["scenario"] == scen
    y, top1, a = t["label"][m], t["top1"][m], acc[m]
    rows, cm = [], np.zeros((22, 24), dtype=int)
    for yy, tt in zip(y, top1):
        cm[yy, 23 if tt < 0 else tt] += 1
    for c in range(22):
        k = y == c
        n = int(k.sum())
        corr = a[k] & (top1[k] == c)
        tp, fp = int(corr.sum()), int((a & (top1 == c) & (y != c)).sum())
        fr = lambda x: float(x.mean()) if n else float("nan")
        rows.append({"index": c, "line": lc.CLASS_NAMES[c], "n": n,
                     "correct": fr(corr), "confident_wrong": fr(a[k] & (top1[k] != c)),
                     "no_pred_true_top1_low_conf": fr(~a[k] & (top1[k] == c)),
                     "no_pred_invalid_top1": fr(~a[k] & (top1[k] == lc.INVALID_IDX)),
                     "no_pred_other_line_top1": fr(~a[k] & (top1[k] >= 0) & (top1[k] != c) & (top1[k] != lc.INVALID_IDX)),
                     "no_pred_precheck": fr(~a[k] & (top1[k] < 0)),
                     "precision": tp / (tp + fp) if tp + fp else float("nan"),
                     "recall": fr(corr),
                     "top1_confusions": {lc.CLASS_NAMES[j]: int(v) for j, v in
                                         sorted(enumerate(cm[c, :22]), key=lambda kv: -kv[1]) if j != c and v}})
    return rows, cm.tolist()


def bootstrap(t, acc_a, acc_b, scen, n=2000):
    m = t["scenario"] == scen
    ok_a = (acc_a & (t["top1"] == t["label"]))[m]
    ok_b = (acc_b["acc"] & (acc_b["t"]["top1"] == acc_b["t"]["label"]))[acc_b["t"]["scenario"] == scen]
    src = t["source"][m]
    srcs = np.unique(src)
    idx = {s: np.flatnonzero(src == s) for s in srcs}
    rng = np.random.default_rng(0)
    d = []
    for _ in range(n):
        p = np.concatenate([idx[s] for s in rng.choice(srcs, len(srcs))])
        d.append(ok_b[p].mean() - ok_a[p].mean())
    return float(ok_b.mean() - ok_a.mean()), float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--variants", nargs="*", default=list(VARIANTS))
    ap.add_argument("--baseline", default="v5 ens3 (staged)")
    ap.add_argument("--json", default=str(HERE / "reports" / "lupang_retrain" / "lines.json"))
    a = ap.parse_args()
    caps = load_captures()
    res, keep = {}, {}
    for name in a.variants:
        d, members, recipe = VARIANTS[name]
        if not available(d, members):
            print(f"(skipping {name}: not trained)")
            continue
        gates = fold_gates(d, members, recipe, caps)
        tc = table(clean_folds(d, members, gates), caps)
        ts = table(sim_folds(d, members, gates, caps), caps)
        both = cat(tc, ts)
        ch = lofo(both)
        acc_both = apply(both, ch)
        acc_c, acc_s = acc_both[:len(tc["fold"])], acc_both[len(tc["fold"]):]
        you = tc["source"] == "webcam_take"
        comp_c = tc["scenario"] == "complete line"
        out = {"lofo_thresholds": {str(f): list(v) for f, v in ch.items()},
               "closed_acc_clean": float((tc["closed"] == tc["label"])[comp_c].mean()),
               "closed_acc_sim": float((ts["closed"] == ts["label"])[ts["scenario"] == "webcam-sim complete line"].mean()),
               "closed_acc_your_takes": float((tc["closed"] == tc["label"])[comp_c & you].mean()),
               "LOFO": {"clean": summary(tc, acc_c), "webcam_sim": summary(ts, acc_s), "your_takes": summary(tc, acc_c, you)},
               "fixed_0.65_0.20": {"clean": summary(tc, accepted(tc, .65, .2)),
                                   "webcam_sim": summary(ts, accepted(ts, .65, .2)),
                                   "your_takes": summary(tc, accepted(tc, .65, .2), you)}}
        for key, tt, acc, scen in (("per_line_clean", tc, acc_c, "complete line"),
                                   ("per_line_sim", ts, acc_s, "webcam-sim complete line")):
            out[key], out[key.replace("per_line", "confusion")] = per_line(tt, acc, scen)
        neg_s = {}
        for scen in np.unique(ts["scenario"]):
            if scen.startswith("webcam-sim") and "complete" not in scen:
                neg_s[str(scen)] = float(acc_s[ts["scenario"] == scen].mean())
        out["webcam_sim_negatives_accepted"] = neg_s
        res[name] = out
        keep[name] = {"tc": tc, "ts": ts, "acc_c": acc_c, "acc_s": acc_s}
        L = out["LOFO"]
        print(f"\n=== {name} ===  closed-set acc: clean {out['closed_acc_clean']:.3f}  webcam-sim {out['closed_acc_sim']:.3f}  "
              f"your takes {out['closed_acc_your_takes']:.3f} | LOFO "
              + ", ".join(f"{c:.2f}/{m:.2f}{'' if ok else '!'}" for c, m, ok in ch.values()))
        for cond in ("clean", "webcam_sim", "your_takes"):
            s = L[cond]
            print(f"  {cond:<11} complete: correct {s['complete_correct']:.3f} wrong {s['complete_wrong']:.3f} "
                  f"no-pred {s['complete_nopred']:.3f} (n={s['n_complete']}) | false accept {s['false_accept']:.3f} (n={s['n_neg']})")
        print("  webcam-sim negatives accepted: " + ", ".join(f"{k.split(': ')[-1]} {v:.3f}" for k, v in neg_s.items()))
    base = a.baseline
    if base in keep:
        res["bootstrap_vs_baseline"] = {}
        for name in keep:
            if name == base:
                continue
            for cond, tkey, akey, scen in (("clean", "tc", "acc_c", "complete line"),
                                           ("webcam-sim", "ts", "acc_s", "webcam-sim complete line")):
                d, lo, hi = bootstrap(keep[base][tkey], keep[base][akey], {"t": keep[name][tkey], "acc": keep[name][akey]}, scen)
                res["bootstrap_vs_baseline"][f"{name} - {base} [{cond}]"] = [d, lo, hi]
                print(f"  {name} minus {base} [{cond}] complete-line correct {d:+.3f} (95% CI {lo:+.3f}..{hi:+.3f})")
    Path(a.json).write_text(json.dumps(res, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
