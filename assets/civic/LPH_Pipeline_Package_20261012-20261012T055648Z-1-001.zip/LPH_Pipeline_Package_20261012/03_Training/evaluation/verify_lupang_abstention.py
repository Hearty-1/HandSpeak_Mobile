"""Verify Lupang Hinirang abstention through the live decision path
(live_lupang_engine.Recognizer.evaluate -> lupang_common.evaluate_capture)
with the real model and real landmark captures.

    python verify_lupang_abstention.py

Cases (every capture is real landmarks; the corrupted ones are real captures
with landmarks removed / shifted / replaced):
  complete correct sign   held-out validation clips (never trained on)
  incomplete sign         first half and second half of every clip
  random movement         real pose + real handshape moved along a random path
  unknown gesture         Calendar month signs (not Lupang lines)
  missing landmarks       held-out clips with the hands dropped in 75 % of frames
  partly outside camera   held-out clips with the hands shifted below the image
  unstable prediction     held-out clips rejected only by the stability check
"""
import pickle
import sys
from pathlib import Path

import numpy as np

import lupang_common as lc
import live_lupang_engine as live
import train_lupang_model as t
from extract_lupang_dataset import list_videos

HERE = Path(__file__).resolve().parent


def lupang_rows():
    cache = pickle.load(open(HERE / "lupang_landmarks_cache.pkl", "rb"))
    _, items = list_videos(lc.RAW_DIR)
    rows = []
    for path, label in items:
        e = cache.get(path)
        if e is not None and lc.clean_sequence(e["raw"], e["ts"]) is not None:
            rows.append((label, e["raw"], e["ts"]))
    return rows


def main():
    rec = live.Recognizer(str(HERE / "palm_lupang_best.pt"), {})
    rows = lupang_rows()
    y = np.load(HERE / "y_raw_lupang.npy")
    _, va = t.stratified_split(y, 0.15, np.random.default_rng(42))
    val = [rows[i] for i in va if i < len(rows)]
    rng = np.random.default_rng(0)
    results = {}

    def tally(name, captures, expect_label=None):
        acc = right = 0
        reasons = {}
        for label, raw, ts in captures:
            r = rec.evaluate(raw, ts)
            if r["accepted"]:
                acc += 1
                right += expect_label is not None and r["top3"][0][2] == label
            elif r["failed"]:
                reasons[r["failed"][0]] = reasons.get(r["failed"][0], 0) + 1
        results[name] = (acc, right, len(captures), reasons)

    # 1. complete correct signs (held-out)
    tally("complete correct sign (held-out)", val, expect_label=True)

    # 2. incomplete: first / second half of every clip
    halves = []
    for label, raw, ts in rows:
        cr, cts = lc.clean_sequence(raw, ts)
        h = len(cr) // 2
        halves += [(label, cr[:h], cts[:h] - cts[0]), (label, cr[h:], cts[h:] - cts[h])]
    tally("incomplete sign (half of a line)", halves)

    # 3. random movement: real pose + real handshape on a random smooth path
    randoms = []
    for label, raw, ts in rows[::3]:
        cr, cts = lc.clean_sequence(raw, ts)
        n = len(cr)
        seq = np.repeat(cr[n // 2:n // 2 + 1], n, axis=0).copy()
        for sl, flag in ((lc.RAW_LH, lc.RAW_FLAG_LH), (lc.RAW_RH, lc.RAW_FLAG_RH)):
            if seq[0, flag] < 0.5:
                continue
            walk = np.cumsum(rng.normal(0, 1, (n + 8, 2)), axis=0)
            walk = np.stack([np.convolve(walk[:, k], np.ones(9) / 9, "valid") for k in range(2)], 1)[:n]
            walk = (walk - walk[0]) * 0.15 / (np.abs(walk).max() + 1e-6)
            h = seq[:, sl].reshape(n, 21, 3)
            h[..., :2] += walk[:, None]
            seq[:, sl] = h.reshape(n, 63)
        randoms.append((label, seq, cts))
    tally("random movement", randoms)

    # 4. unknown gesture: Calendar month signs through the Lupang engine
    import calendar_common as cc
    cal = pickle.load(open(cc.LANDMARK_CACHE, "rb"))
    unknown = [(-1, e["raw"], e["ts"]) for k, e in sorted(cal.items()) if "webcam_" not in k][::3]
    tally("unknown gesture (Calendar signs)", unknown)

    # 5. missing landmarks: hands dropped in 75 % of frames
    missing = []
    for label, raw, ts in val:
        r = raw.copy()
        drop = rng.random(len(r)) < 0.75
        for sl, flag in ((lc.RAW_LH, lc.RAW_FLAG_LH), (lc.RAW_RH, lc.RAW_FLAG_RH)):
            r[drop, flag] = 0.0
            r[drop, sl] = 0.0
        missing.append((label, r, ts))
    tally("missing landmarks (hands in 25% of frames)", missing)

    # 6. partly outside the camera: hands shifted below the bottom edge
    outside = []
    for label, raw, ts in val:
        r = raw.copy()
        for sl in (lc.RAW_LH, lc.RAW_RH):
            h = r[:, sl].reshape(len(r), 21, 3)
            h[..., 1] += 1.0 - h[..., 1].min(axis=1, keepdims=True)   # hand moved below the bottom edge
            r[:, sl] = h.reshape(len(r), 63)
        outside.append((label, r, ts))
    tally("partly outside camera (hands cut off)", outside)

    print("\n=== Lupang Hinirang abstention (live decision path, real model) ===")
    for name, (acc, right, n, reasons) in results.items():
        top = ", ".join(f"{k} {v}" for k, v in sorted(reasons.items(), key=lambda kv: -kv[1])[:3])
        if name.startswith("complete"):
            print(f"  {name:<44} accepted CORRECT {right}/{n}, accepted wrong {acc - right}/{n}, "
                  f"no prediction {n - acc}/{n} | main reasons: {top}")
        else:
            print(f"  {name:<44} accepted {acc}/{n} ({acc / n:.1%}) -> no prediction {n - acc}/{n} | main reasons: {top}")
    st = results["complete correct sign (held-out)"][3].get("UNSTABLE", 0)
    print(f"  {'unstable prediction':<44} {st} held-out capture(s) withheld because the answer changed between views")
    return 0


if __name__ == "__main__":
    sys.exit(main())
