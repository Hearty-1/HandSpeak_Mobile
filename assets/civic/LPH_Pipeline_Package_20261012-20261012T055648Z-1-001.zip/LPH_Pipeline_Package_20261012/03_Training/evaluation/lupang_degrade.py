"""Raw-landmark degradation that mimics a low-frame-rate webcam (training augmentation).

On the user's 20 fps webcam, MediaPipe Holistic misses hands that are clearly
in view while they move (motion blur): in the 35 webcam takes both hands are
detected in a median 18 % of active frames (reference videos 73 %), any hand in
78 % (98 %); pose wrists / elbows stay tracked. degrade_capture() turns a
reference capture into that condition BEFORE the normal pipeline
(lupang_common.clean_sequence / static_features), so the model learns lines
from sparse hand detections plus the pose trajectory, exactly as the live
service receives them:

  * resample to a webcam frame rate (18-22 fps) by picking the nearest frames
  * per hand, a miss probability that grows with that hand's speed
    (fast = blurred), with temporally correlated (bursty) noise; one hand,
    chosen at random, is tracked worse than the other
  * missed frames: hand flag 0 and landmarks zeroed (MediaPipe's "not detected")

Parameters were fitted so degraded reference clips match the webcam takes'
coverage (see calibrate() / `python lupang_degrade.py`).
"""
import numpy as np

import lupang_common as lc

FPS_RANGE = (18.0, 22.0)
BASE_MISS = (0.0, 0.1)        # miss probability of a still hand
SPEED_GAIN = (0.08, 0.2)      # added miss probability per shoulder-span/s of wrist speed
WEAK_HAND_EXTRA = (0.15, 0.45)  # one hand (random) is tracked worse, as in the webcam takes
SMOOTH_FRAMES = 5             # burst length scale of the correlated noise


def _speed(raw, ts, sl, flag, pose_wrist):
    """Per-frame wrist speed in shoulder spans / s (hand wrist, else pose wrist)."""
    n = len(raw)
    pose = raw[:, lc.RAW_POSE].reshape(n, 7, 2)
    span = float(np.median(np.linalg.norm(pose[:, lc.P_LSH] - pose[:, lc.P_RSH], axis=1))) + 1e-6
    w = np.where((raw[:, flag] > 0.5)[:, None], raw[:, sl][:, :2], pose[:, pose_wrist])
    v = np.zeros(n)
    v[1:] = np.linalg.norm(np.diff(w, axis=0), axis=1) / np.maximum(np.diff(ts), 1e-3) / span
    return v


def _correlated_uniform(rng, n, k=SMOOTH_FRAMES):
    """Uniform(0,1) marginals with temporal correlation (bursty misses)."""
    z = np.convolve(rng.normal(size=n + k - 1), np.ones(k) / k, mode="valid")
    ranks = np.argsort(np.argsort(z))
    return (ranks + 0.5) / n


def degrade_capture(raw, ts, rng):
    """(raw (N, RAW_DIM), ts (N,)) -> degraded copy (raw', ts'). Inputs are not modified."""
    raw = np.asarray(raw, dtype=np.float32)
    ts = np.asarray(ts, dtype=np.float64)
    fps = rng.uniform(*FPS_RANGE)
    grid = np.arange(ts[0], ts[-1] + 1e-9, 1.0 / fps)
    idx = np.unique(np.clip(np.searchsorted(ts, grid), 0, len(ts) - 1))
    out, t2 = raw[idx].copy(), ts[idx] - ts[idx[0]]
    base, gain = rng.uniform(*BASE_MISS), rng.uniform(*SPEED_GAIN)
    weak = int(rng.integers(2))
    for h, (sl, flag, pw) in enumerate(((lc.RAW_LH, lc.RAW_FLAG_LH, lc.P_LWR), (lc.RAW_RH, lc.RAW_FLAG_RH, lc.P_RWR))):
        extra = rng.uniform(*WEAK_HAND_EXTRA) if h == weak else 0.0
        p = np.clip(base + extra + gain * _speed(out, t2, sl, flag, pw), 0.0, 0.97)
        miss = (_correlated_uniform(rng, len(out)) < p) & (out[:, flag] > 0.5)
        out[miss, flag] = 0.0
        out[miss, sl] = 0.0
    return out, t2


def coverage(raw):
    """(any-hand, both-hands) detection share on the active segment (first..last hand)."""
    lh, rh = raw[:, lc.RAW_FLAG_LH] > 0.5, raw[:, lc.RAW_FLAG_RH] > 0.5
    hit = np.flatnonzero(lh | rh)
    if len(hit) == 0:
        return 0.0, 0.0
    a, b = hit[0], hit[-1] + 1
    return float((lh | rh)[a:b].mean()), float((lh & rh)[a:b].mean())


def calibrate(seed=0):
    """Coverage of degraded reference clips vs the user's webcam takes."""
    from test_lupang_recognition import load_captures
    caps = load_captures()
    rng = np.random.default_rng(seed)
    web = np.array([coverage(c["raw"]) for c in caps if c["source"] == "webcam_take"])
    ref = [c for c in caps if c["source"] != "webcam_take"]
    deg = np.array([coverage(degrade_capture(c["raw"], c["ts"], rng)[0]) for c in ref])
    clean = np.array([coverage(c["raw"]) for c in ref])
    for name, a in (("reference clean", clean), ("reference degraded", deg), ("webcam takes (target)", web)):
        print(f"{name:<24} any hand median {np.median(a[:, 0]):.2f} p10 {np.percentile(a[:, 0], 10):.2f} | "
              f"both hands median {np.median(a[:, 1]):.2f} p90 {np.percentile(a[:, 1], 90):.2f}")


if __name__ == "__main__":
    calibrate()
