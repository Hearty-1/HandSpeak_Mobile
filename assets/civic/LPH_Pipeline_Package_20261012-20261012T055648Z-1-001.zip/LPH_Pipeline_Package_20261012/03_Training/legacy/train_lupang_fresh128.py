﻿import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

# 1. Load fresh normalized dataset
X = np.load("X_lupang_fresh128.npy") # (367, 32, 128)
y = np.load("y_lupang_fresh128.npy") # (367,)

print(f"Fresh Dataset loaded: X={X.shape}, y={y.shape}")

# 2. Mirror Augmentation Function
def mirror_sample(sample):
    """
    Bumabaliktad ng x coordinates at nagpapalit ng Left at Right hand slots
    upang maiwasan ang webcam mirror confusion.
    """
    s = sample.copy() # (32, 128)
    # LH: 0..41, RH: 42..83
    lh = s[:, :42].copy()
    rh = s[:, 42:84].copy()
    # Invert x-coordinates
    lh[:, 0::2] *= -1.0
    rh[:, 0::2] *= -1.0
    # Swap hands
    s[:, :42] = rh
    s[:, 42:84] = lh
    # Invert spatial x metrics
    # spatial indices: 84..106
    s[:, 84::3] *= -1.0
    return s

aug_X, aug_y = [], []
for sample, label in zip(X, y):
    aug_X.append(sample)
    aug_y.append(label)
    if label != 22: # Huwag i-mirror ang invalid class
        aug_X.append(mirror_sample(sample))
        aug_y.append(label)

X_all = np.array(aug_X, dtype=np.float32)
y_all = np.array(aug_y, dtype=np.int64)

print(f"Dataset pagkatapos ng Mirror Augmentation: X={X_all.shape}, y={y_all.shape}")

# Train/Val Split (85% train, 15% val)
np.random.seed(42)
indices = np.arange(len(X_all))
np.random.shuffle(indices)

split = int(0.85 * len(X_all))
train_idx, val_idx = indices[:split], indices[split:]

X_train, y_train = torch.tensor(X_all[train_idx]), torch.tensor(y_all[train_idx])
X_val, y_val = torch.tensor(X_all[val_idx]), torch.tensor(y_all[val_idx])

train_loader = DataLoader(TensorDataset(X_train, y_train), batch_size=32, shuffle=True)
val_loader = DataLoader(TensorDataset(X_val, y_val), batch_size=32, shuffle=False)

# 3. Model Architecture
class FullSequenceConvBiLSTM(nn.Module):
    def __init__(self, in_features=128, hidden_dim=128, num_classes=23):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(in_features, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.25)
        )
        self.lstm = nn.LSTM(
            input_size=64,
            hidden_size=hidden_dim,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.3
        )
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes)
        )

    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.conv(x)
        x = x.transpose(1, 2)
        out, _ = self.lstm(x)
        feat = torch.mean(out, dim=1)
        return self.fc(feat)

device = torch.device("cpu")
model = FullSequenceConvBiLSTM(in_features=128, hidden_dim=128, num_classes=23).to(device)
criterion = nn.CrossEntropyLoss()
optimizer = optim.AdamW(model.parameters(), lr=0.002, weight_decay=1e-4)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='max', factor=0.5, patience=6)

best_val_acc = 0.0
epochs = 55

print("\n--- Training Model Gamit ang Fresh Invariant Features ---")
for epoch in range(1, epochs + 1):
    model.train()
    total_loss, correct = 0.0, 0
    for bx, by in train_loader:
        optimizer.zero_grad()
        out = model(bx)
        loss = criterion(out, by)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * bx.size(0)
        correct += (out.argmax(dim=1) == by).sum().item()

    train_acc = (correct / len(X_train)) * 100.0

    model.eval()
    val_correct = 0
    with torch.no_grad():
        for bx, by in val_loader:
            out = model(bx)
            val_correct += (out.argmax(dim=1) == by).sum().item()

    val_acc = (val_correct / len(X_val)) * 100.0
    scheduler.step(val_acc)

    if val_acc >= best_val_acc:
        best_val_acc = val_acc
        torch.save(model.state_dict(), "palm_lupang_fresh128.pt")

    if epoch % 5 == 0 or epoch == epochs:
        print(f"Epoch [{epoch:02d}/{epochs}] | Loss: {total_loss/len(X_train):.4f} | Train Acc: {train_acc:.1f}% | Val Acc: {val_acc:.1f}% (Best: {best_val_acc:.1f}%)")

print(f"\nTapos na! Best model saved to: palm_lupang_fresh128.pt (Best Val Acc: {best_val_acc:.1f}%)")
