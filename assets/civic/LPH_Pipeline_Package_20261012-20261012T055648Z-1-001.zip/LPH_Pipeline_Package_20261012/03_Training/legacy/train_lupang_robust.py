﻿import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

# 1. Load existing holistic data
X = np.load("X_holistic_lupang.npy")  # (N, 32, 128)
y = np.load("y_holistic_lupang.npy")  # (N,)

print(f"Original Dataset: {X.shape}")

# 2. Balance at mag-Augment ng Data (Jittering, Scaling, Time Shifts)
augmented_X = []
augmented_y = []

# Bilangin bawat klase
unique_classes, counts = np.unique(y, return_counts=True)
target_per_class = 40  # Pantayin lahat sa 40 samples per class

for cls in unique_classes:
    cls_idx = np.where(y == cls)[0]
    cls_samples = X[cls_idx]
    
    # Isama ang original
    for s in cls_samples:
        augmented_X.append(s)
        augmented_y.append(cls)
        
    # Mag-generate ng variations hanggang umabot sa target
    num_needed = target_per_class - len(cls_samples)
    if num_needed > 0 and cls != 22: # Huwag masyadong damihan ang invalid
        for i in range(num_needed):
            base = cls_samples[i % len(cls_samples)].copy()
            # Gaussian noise / hand tremor simulation
            noise = np.random.normal(0, 0.015, base.shape).astype(np.float32)
            # Scale jitter
            scale = np.random.uniform(0.92, 1.08)
            aug_sample = (base * scale) + noise
            augmented_X.append(aug_sample)
            augmented_y.append(cls)

X_aug = np.array(augmented_X, dtype=np.float32)
y_aug = np.array(augmented_y, dtype=np.int64)

print(f"Augmented Dataset: {X_aug.shape}, Classes: {len(unique_classes)}")

# Train / Val Split
np.random.seed(42)
indices = np.arange(len(X_aug))
np.random.shuffle(indices)

split = int(0.85 * len(X_aug))
train_idx, val_idx = indices[:split], indices[split:]

X_train, y_train = torch.tensor(X_aug[train_idx]), torch.tensor(y_aug[train_idx])
X_val, y_val = torch.tensor(X_aug[val_idx]), torch.tensor(y_aug[val_idx])

train_loader = DataLoader(TensorDataset(X_train, y_train), batch_size=32, shuffle=True)
val_loader = DataLoader(TensorDataset(X_val, y_val), batch_size=32, shuffle=False)

# Model Definition
class FullSequenceConvBiLSTM(nn.Module):
    def __init__(self, in_features=128, hidden_dim=128, num_classes=23):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(in_features, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.2)
        )
        self.lstm = nn.LSTM(
            input_size=64,
            hidden_size=hidden_dim,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.3
        )
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes)
        )

    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.conv(x)
        x = x.transpose(1, 2)
        out, _ = self.lstm(x)
        feat = torch.mean(out, dim=1)
        return self.fc(feat)

device = torch.device("cpu")
model = FullSequenceConvBiLSTM(in_features=128, hidden_dim=128, num_classes=23).to(device)
criterion = nn.CrossEntropyLoss()
optimizer = optim.AdamW(model.parameters(), lr=0.0015, weight_decay=1e-4)

best_val_acc = 0.0
epochs = 50

print("\n--- Training Robust Lupang Hinirang Model ---")
for epoch in range(1, epochs + 1):
    model.train()
    total_loss, correct = 0.0, 0
    for bx, by in train_loader:
        optimizer.zero_grad()
        out = model(bx)
        loss = criterion(out, by)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * bx.size(0)
        correct += (out.argmax(dim=1) == by).sum().item()

    train_acc = (correct / len(X_train)) * 100.0

    model.eval()
    val_correct = 0
    with torch.no_grad():
        for bx, by in val_loader:
            out = model(bx)
            val_correct += (out.argmax(dim=1) == by).sum().item()

    val_acc = (val_correct / len(X_val)) * 100.0

    if val_acc >= best_val_acc:
        best_val_acc = val_acc
        torch.save(model.state_dict(), "palm_lupang_robust_23class.pt")

    if epoch % 10 == 0 or epoch == epochs:
        print(f"Epoch [{epoch:02d}/{epochs}] | Loss: {total_loss/len(X_train):.4f} | Train Acc: {train_acc:.1f}% | Val Acc: {val_acc:.1f}% (Best: {best_val_acc:.1f}%)")

print(f"\nTapos na! Nai-save sa 'palm_lupang_robust_23class.pt' na may Best Val Acc: {best_val_acc:.1f}%")
