﻿import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import numpy as np

X = np.load("X_holistic_lupang.npy")
y = np.load("y_holistic_lupang.npy")

print(f"Dataset na-load: X={X.shape}, y={y.shape}")

np.random.seed(42)
indices = np.arange(len(X))
np.random.shuffle(indices)

split = int(0.85 * len(X))
train_idx, val_idx = indices[:split], indices[split:]

X_train, y_train = torch.tensor(X[train_idx], dtype=torch.float32), torch.tensor(y[train_idx], dtype=torch.long)
X_val, y_val = torch.tensor(X[val_idx], dtype=torch.float32), torch.tensor(y[val_idx], dtype=torch.long)

train_loader = DataLoader(TensorDataset(X_train, y_train), batch_size=16, shuffle=True)
val_loader = DataLoader(TensorDataset(X_val, y_val), batch_size=16, shuffle=False)

class FullSequenceConvBiLSTM(nn.Module):
    def __init__(self, in_features=128, hidden_dim=128, num_classes=23):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(in_features, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.2)
        )
        self.lstm = nn.LSTM(
            input_size=64,
            hidden_size=hidden_dim,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.3
        )
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes)
        )

    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.conv(x)
        x = x.transpose(1, 2)
        out, _ = self.lstm(x)
        feat = torch.mean(out, dim=1)
        return self.fc(feat)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Gagamiting Device:", device)

model = FullSequenceConvBiLSTM(in_features=128, hidden_dim=128, num_classes=23).to(device)
criterion = nn.CrossEntropyLoss()
optimizer = optim.AdamW(model.parameters(), lr=0.001, weight_decay=1e-4)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='max', factor=0.5, patience=5)

best_val_acc = 0.0
epochs = 45

print("\n--- Pagsasanay gamit ang Face + Pose + Hand Holistic Features ---")
for epoch in range(1, epochs + 1):
    model.train()
    total_loss, correct = 0.0, 0
    for bx, by in train_loader:
        bx, by = bx.to(device), by.to(device)
        optimizer.zero_grad()
        out = model(bx)
        loss = criterion(out, by)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * bx.size(0)
        correct += (out.argmax(dim=1) == by).sum().item()

    train_acc = (correct / len(X_train)) * 100.0

    model.eval()
    val_correct = 0
    with torch.no_grad():
        for bx, by in val_loader:
            bx, by = bx.to(device), by.to(device)
            out = model(bx)
            val_correct += (out.argmax(dim=1) == by).sum().item()

    val_acc = (val_correct / len(X_val)) * 100.0
    scheduler.step(val_acc)

    if val_acc >= best_val_acc:
        best_val_acc = val_acc
        torch.save(model.state_dict(), "palm_lupang_holistic_23class.pt")

    if epoch % 5 == 0 or epoch == epochs:
        print(f"Epoch [{epoch:02d}/{epochs}] | Loss: {total_loss/len(X_train):.4f} | Train Acc: {train_acc:.1f}% | Val Acc: {val_acc:.1f}% (Best: {best_val_acc:.1f}%)")

print("\nTapos na ang Training!")
print("Nai-save ang holistic weights sa: palm_lupang_holistic_23class.pt")
