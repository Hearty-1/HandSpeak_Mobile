# Missing files, unverified history, known inconsistencies

| Item | Finding | Evidence |
|---|---|---|
| Original source archive | `D:\lupang hinirang-20260928T002750Z-1-001` exists but is **empty**; the zip / Drive source is not on disk. History before the videos' 2026-09-13 creation time / 2026-09-28 08:28 modification time is **unverifiable**. | folder listing; video timestamps |
| Git history | No LPH file is tracked; last commit 2026-09-26. Development history is reconstructed from timestamps, metadata and logs only. | `git ls-files`, `git log` |
| Original component member 0 | `palm_lupang_v5.pt` was **overwritten** 2026-10-11 05:25; the staged original part (v5 ens3) cannot be reproduced from checkpoints on disk (max prob diff 0.28). Weights exist only inside the staged ONNX / `models_staging_v5_ens3` ONNX. | audit `prov32.txt` |
| `y_raw_lupang.npy` / `lupang_meta.json` | Relabelled 2026-10-11 03:01 by an **unknown** process: 465 / 713 labels shifted from index 11 (22-class numbering); `.bak` copies beside them. Not used by the staged model's training; would mislead `train_lupang_model.py` / `test_lupang_recognition.heldout_split`. | audit `prov` / `sess.txt` |
| `D:\labels_lupang_hinirang.json` | origin unverified (2026-09-28 10:51), not referenced by code. | file timestamp |
| Revision 00016 content | inferred to contain the staged model (files replaced before deploy); container not opened. | GCP_STATUS.md |
| Who ran the deploy | performed outside this session (backup folder + revision 00016 appeared 2026-10-12 ~12:45 local). | timestamps |
| Experiment pickles / fold checkpoints | 138 files (4.88 GB) not copied — see `EXCLUDED_FILES.csv`. | — |
| Staged metadata | `ensemble_members` lists only v9 B; full composition is under `switch`; `model_version` unchanged by the Perlas patch. | staged JSON |
| Service tests | fixtures hold v4 expectations; `test_lupang_raw.py` will fail on the v9 model until regenerated. | code |
| Flutter app | does not contain the raw-endpoint client; ready-made Dart files are only in the training repo. | `06_Flutter_Integration` |
| Webcam attempt labels | three fixed-target runs (sessions 075517, 085620, 111351 #006–020) and adjacent-line target slips; labels cannot be verified without video. | audit `bysess.txt` |
