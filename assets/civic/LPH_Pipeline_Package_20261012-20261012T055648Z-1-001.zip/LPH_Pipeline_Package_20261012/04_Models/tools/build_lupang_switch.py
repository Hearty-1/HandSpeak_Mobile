"""Combine the ORIGINAL Lupang ensemble and the USER-ADAPTED ensemble into one ONNX model.

    D:\\venv_lupang_export\\Scripts\\python.exe build_lupang_switch.py \\
        --original inference-service/models_staging_v5_ens3 --user inference-service/models_staging_v7_user \\
        --out inference-service/models_staging

Rule (per input row, i.e. per view the service scores):
    if the user-adapted model's top-1 class is one of the lines the user recorded takes
    for, its probabilities are used; otherwise the ORIGINAL model's probabilities are used
    unchanged.
Evidence (merge_lupang_user.py experiment, held-out data, staged thresholds 0.65 / 0.65):
user's recorded lines 100 % correct (= user-adapted), unseen reference signers identical to
the original model, user's lines without takes 6.1 % (user-adapted 3.5 %, original 14.9 %).

Both inputs are exports of export_lupang_onnx.py (input "features" (B, 32, 181), output
"logits" = log of the ensemble's mean probability), so the combined "logits" output is
a log probability as well and the service's softmax returns it unchanged. The gate,
class names and feature set are taken from the user-adapted model's JSON.
"""
import argparse
import json
import shutil
from pathlib import Path

import numpy as np
import onnx
from onnx import TensorProto, compose, helper, numpy_helper

META = "lupang_hinirang_v4.json"


def build(original_onnx, user_onnx, recorded, n_classes, fold=None, arbitrate=False, patch_onnx=None, patch_class=None):
    """fold {from: to}: the original model's probability of class `from` is added to `to`
    (it was trained with two half-line classes that are one line now). arbitrate: the
    user-adapted model is only used when, besides naming a recorded line, it is at least
    as confident as the original model. patch_onnx / patch_class: a fine-tuned copy of the
    user-adapted model replaces it only where the copy's top-1 is patch_class (class-local fix)."""
    a = compose.add_prefix(onnx.load(original_onnx), prefix="orig/")
    b = compose.add_prefix(onnx.load(user_onnx), prefix="user/")
    mask = np.zeros(n_classes, dtype=np.int64)
    mask[list(recorded)] = 1
    nodes = [helper.make_node("Identity", ["features"], ["orig/features"]),
             helper.make_node("Identity", ["features"], ["user/features"])]
    nodes += list(a.graph.node) + list(b.graph.node)
    inits = list(a.graph.initializer) + list(b.graph.initializer) + [numpy_helper.from_array(mask, "recorded_mask")]
    user = "user/logits"
    if patch_onnx is not None:
        c = compose.add_prefix(onnx.load(patch_onnx), prefix="patch/")
        nodes += [helper.make_node("Identity", ["features"], ["patch/features"])] + list(c.graph.node)
        inits += list(c.graph.initializer) + [numpy_helper.from_array(np.array([patch_class], np.int64), "patch_class")]
        nodes += [helper.make_node("ArgMax", ["patch/logits"], ["patch_top"], axis=1, keepdims=1),
                  helper.make_node("Equal", ["patch_top", "patch_class"], ["patch_hit"]),
                  helper.make_node("Where", ["patch_hit", "patch/logits", "user/logits"], ["user_patched"])]
        user = "user_patched"
    orig = "orig/logits"
    if fold:
        fm = np.eye(n_classes, dtype=np.float32)
        for f, t in fold.items():
            fm[f, f], fm[f, t] = 0.0, 1.0
        inits += [numpy_helper.from_array(fm, "fold_matrix"), numpy_helper.from_array(np.array(1e-12, np.float32), "eps")]
        nodes += [helper.make_node("Exp", [orig], ["orig_p"]),
                  helper.make_node("MatMul", ["orig_p", "fold_matrix"], ["orig_pf"]),
                  helper.make_node("Max", ["orig_pf", "eps"], ["orig_pfc"]),
                  helper.make_node("Log", ["orig_pfc"], ["orig_folded"])]
        orig = "orig_folded"
    nodes += [
        helper.make_node("ArgMax", [user], ["user_top"], axis=1, keepdims=1),
        helper.make_node("Gather", ["recorded_mask", "user_top"], ["is_rec_i"], axis=0),
        helper.make_node("Cast", ["is_rec_i"], ["is_rec0"], to=TensorProto.BOOL),
    ]
    if arbitrate:
        nodes += [helper.make_node("ReduceMax", [user], ["user_max"], axes=[1], keepdims=1),
                  helper.make_node("ReduceMax", [orig], ["orig_max"], axes=[1], keepdims=1),
                  helper.make_node("GreaterOrEqual", ["user_max", "orig_max"], ["user_surer"]),
                  helper.make_node("And", ["is_rec0", "user_surer"], ["is_rec"])]
    else:
        nodes += [helper.make_node("Identity", ["is_rec0"], ["is_rec"])]
    nodes += [helper.make_node("Where", ["is_rec", user, orig], ["logits"])]
    graph = helper.make_graph(
        nodes, "lupang_switch",
        [helper.make_tensor_value_info("features", TensorProto.FLOAT, ["batch", 32, 181])],
        [helper.make_tensor_value_info("logits", TensorProto.FLOAT, ["batch", n_classes])],
        initializer=inits)
    model = helper.make_model(graph, opset_imports=list(b.opset_import))
    model.ir_version = b.ir_version
    onnx.checker.check_model(model)
    return model


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--original", type=Path, required=True, help="models dir of the original ensemble")
    ap.add_argument("--user", type=Path, required=True, help="models dir of the user-adapted ensemble")
    ap.add_argument("--recorded", type=int, nargs="+", required=True, help="1-based lines with user takes")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--name", default="palm_lupang_v8_switch")
    ap.add_argument("--fold", nargs="*", default=[], metavar="FROM:TO",
                    help="1-based original-model classes to add into another (e.g. 12:11 for the merged line)")
    ap.add_argument("--arbitrate", action="store_true",
                    help="use the user-adapted model only when it is at least as confident as the original")
    ap.add_argument("--patch", type=Path, help="models dir of a class-local fine-tuned copy of the user model")
    ap.add_argument("--patch-class", type=int, help="1-based class the patch is used for")
    a = ap.parse_args()
    fold = {int(x.split(":")[0]) - 1: int(x.split(":")[1]) - 1 for x in a.fold}
    meta_o = json.loads((a.original / META).read_text(encoding="utf-8"))
    meta_u = json.loads((a.user / META).read_text(encoding="utf-8"))
    if len(meta_o["class_names"]) != len(meta_u["class_names"]) or meta_o["feature_names"] != meta_u["feature_names"]:
        raise SystemExit("original and user-adapted models use different class counts / features")
    for i, (x, y) in enumerate(zip(meta_o["class_names"], meta_u["class_names"])):
        if x != y and i not in fold and i not in fold.values():
            raise SystemExit(f"class {i}: {x!r} vs {y!r} - only folded classes may differ")
    recorded = sorted(r - 1 for r in a.recorded)
    n = len(meta_u["class_names"])
    meta_p = json.loads((a.patch / META).read_text(encoding="utf-8")) if a.patch else None
    pc = a.patch_class - 1 if a.patch else None
    model = build(a.original / meta_o["onnx_file"], a.user / meta_u["onnx_file"], recorded, n, fold, a.arbitrate,
                  a.patch / meta_p["onnx_file"] if a.patch else None, pc)
    a.out.mkdir(parents=True, exist_ok=True)
    onnx_name = "fsl_lupang_hinirang_v4.onnx"
    onnx.save(model, str(a.out / onnx_name))
    meta = {**meta_u, "onnx_file": onnx_name, "source_checkpoint": a.name,
            "switch": {"original": meta_o["source_checkpoint"], "user_adapted": meta_u["source_checkpoint"],
                       "recorded_lines_1based": [r + 1 for r in recorded],
                       "rule": "user-adapted probabilities if its top-1 is a recorded line"
                               + (" and it is at least as confident as the original" if a.arbitrate else "")
                               + ", else original",
                       "original_folded_classes_1based": {str(k + 1): v + 1 for k, v in fold.items()},
                       **({"class_patch": {"class_1based": pc + 1, "patched_from": meta_p["source_checkpoint"],
                                            "rule": "patched user model used only where its top-1 is this class"}}
                          if a.patch else {})}}
    (a.out / META).write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")

    # Parity: combined graph == switch applied to the two source models.
    import onnxruntime as ort
    so = ort.InferenceSession(str(a.original / meta_o["onnx_file"]), providers=["CPUExecutionProvider"])
    su = ort.InferenceSession(str(a.user / meta_u["onnx_file"]), providers=["CPUExecutionProvider"])
    sc = ort.InferenceSession(str(a.out / onnx_name), providers=["CPUExecutionProvider"])
    X = np.load(Path(__file__).resolve().parent / "X_raw_lupang.npy")[:200].astype(np.float32)
    lo, lu = so.run(["logits"], {"features": X})[0], su.run(["logits"], {"features": X})[0]
    if a.patch:
        sp = ort.InferenceSession(str(a.patch / meta_p["onnx_file"]), providers=["CPUExecutionProvider"])
        lp = sp.run(["logits"], {"features": X})[0]
        lu = np.where((lp.argmax(1) == pc)[:, None], lp, lu)
    if fold:
        po = np.exp(lo)
        for f, t in fold.items():
            po[:, t] += po[:, f]
            po[:, f] = 0.0
        lo = np.log(np.maximum(po, 1e-12))
    rec = np.zeros(n, bool)
    rec[recorded] = True
    use_u = rec[lu.argmax(1)]
    if a.arbitrate:
        use_u &= lu.max(1) >= lo.max(1)
    ref = np.where(use_u[:, None], lu, lo)
    got = sc.run(["logits"], {"features": X})[0]
    err = float(np.abs(ref - got).max())
    print(f"wrote {a.out / onnx_name} ({(a.out / onnx_name).stat().st_size / 1e6:.1f} MB), {META}; "
          f"parity vs separate models on {len(X)} samples: max |diff| {err:.2e}; "
          f"rows routed to user-adapted model: {use_u.mean():.0%}")
    if err > 1e-4:
        raise SystemExit("combined model does not match the switch rule")


if __name__ == "__main__":
    main()
