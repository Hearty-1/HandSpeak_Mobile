# GCP deployment status (verified read-only, 2026-10-12)

Project `handspeak-96d8d`, region `asia-southeast1`, Cloud Run service **`handspeak-inference`**
(`https://handspeak-inference-xo2j6ffgta-as.a.run.app`), service account `handspeak-inference-sa@…`, 1 CPU / 1 GiB,
min 1 / max 5 instances, env `FIREBASE_PROJECT_ID`, `LOW_CONFIDENCE_THRESHOLD=0.5`.

| Revision | Created (UTC) | Tag | Traffic |
|---|---|---|---|
| `handspeak-inference-00016-yeb` | **2026-10-12 04:45** | `lupang-v9` → `https://lupang-v9---handspeak-inference-xo2j6ffgta-as.a.run.app` | **0 %** |
| `handspeak-inference-00014-yeh` | 2026-10-05 11:45 | `letters-jz` | **100 %** |
| `handspeak-inference-00012-juh` | 2026-10-04 18:49 | `calendar-v1` | 0 % |
| `handspeak-inference-00010-but` | 2026-10-04 07:25 | `lupang-v4` | 0 % |

**Is the current model deployed?**
* **Deployed as revision 00016 (`lupang-v9`) but NOT live**: it receives 0 % of traffic, so the app's base URL still gets
  revision 00014 (2026-10-05, older than even the 2026-10-07 v4 model). [V: `gcloud run services describe` / `revisions list`]
* Revision 00016 very likely contains the staged model: `inference-service/models/fsl_lupang_hinirang_v4.onnx` was replaced
  with the staged file (`763478f3…`, identical to `04_Models/current_staged`) before the 04:45 UTC (12:45 local) deploy, the
  previous production files are in `backups/lupang_prod_before_v9_deploy`, and the Dockerfile copies `models/`. [I — the container
  image itself was not opened]
* To verify: call `GET https://lupang-v9---…/v1/models` with a Firebase ID token (lists `raw_models`), or send a known capture to
  `/v1/predict_raw/lupang_hinirang` on the tagged URL and check `model_version` = `lupang-v4/palm_lupang_v9_switch`.
* To make it live: `gcloud run services update-traffic handspeak-inference --to-revisions handspeak-inference-00016-yeb=100`
  (rollback: `--to-revisions handspeak-inference-00014-yeh=100`). Not done — requires the Flutter changes below first.
