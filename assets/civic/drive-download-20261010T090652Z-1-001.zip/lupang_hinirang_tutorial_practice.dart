import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// --- DATA MODELS ---

class AnthemManifest {
  final String category;
  final String version;
  final String pipeline;
  final String modelFilename;
  final List<int> inputTensorShape;
  final int sampleFrames;
  final List<AnthemPhrase> phrases;

  AnthemManifest({
    required this.category,
    required this.version,
    required this.pipeline,
    required this.modelFilename,
    required this.inputTensorShape,
    required this.sampleFrames,
    required this.phrases,
  });

  factory AnthemManifest.fromJson(Map<String, dynamic> json) {
    return AnthemManifest(
      category: json['category'] ?? '',
      version: json['version'] ?? '2.0',
      pipeline: json['pipeline'] ?? '',
      modelFilename: json['model_filename'] ?? 'fsl_lupang_hinirang.onnx',
      inputTensorShape: List<int>.from(json['input_tensor_shape'] ?? [1, 818]),
      sampleFrames: json['sample_frames'] ?? 32,
      phrases: (json['phrases'] as List<dynamic>)
          .map((p) => AnthemPhrase.fromJson(p))
          .toList(),
    );
  }
}

class AnthemPhrase {
  final int id;
  final int index;
  final String folderCode;
  final String label;
  final String orientation;
  final String instruction;
  final double minEnergy;

  AnthemPhrase({
    required this.id,
    required this.index,
    required this.folderCode,
    required this.label,
    required this.orientation,
    required this.instruction,
    required this.minEnergy,
  });

  factory AnthemPhrase.fromJson(Map<String, dynamic> json) {
    return AnthemPhrase(
      id: json['id'] ?? 0,
      index: json['index'] ?? 0,
      folderCode: json['folder_code'] ?? '',
      label: json['label'] ?? '',
      orientation: json['orientation'] ?? 'upper_body',
      instruction: json['instruction'] ?? '',
      minEnergy: (json['min_energy'] as num?)?.toDouble() ?? 0.20,
    );
  }
}

// --- WIDGET IMPLEMENTATION ---

class LupangHinirangTutorialPracticeScreen extends StatefulWidget {
  const LupangHinirangTutorialPracticeScreen({Key? key}) : super(key: key);

  @override
  State<LupangHinirangTutorialPracticeScreen> createState() =>
      _LupangHinirangTutorialPracticeScreenState();
}

class _LupangHinirangTutorialPracticeScreenState
    extends State<LupangHinirangTutorialPracticeScreen> {
  AnthemManifest? _manifest;
  int _currentIndex = 0;
  bool _isLoading = true;
  bool _isEvaluating = false;

  // Placeholder evaluation results for UI preview
  String _evaluationFeedback = "Maghanda at isagawa ang kumpas...";
  double _lastConfidence = 0.0;
  bool _isMatch = false;

  @override
  void initState() {
    super.initState();
    _loadManifestData();
  }

  Future<void> _loadManifestData() async {
    try {
      final jsonString = await rootBundle.loadString(
        'assets/manifests/labels_lupang_hinirang.json',
      );
      final Map<String, dynamic> jsonData = json.decode(jsonString);
      setState(() {
        _manifest = AnthemManifest.fromJson(jsonData);
        _isLoading = false;
      });
    } catch (e) {
      debugPrint("Error loading Anthem manifest: $e");
      setState(() => _isLoading = false);
    }
  }

  void _nextPhrase() {
    if (_manifest != null && _currentIndex < _manifest!.phrases.length - 1) {
      setState(() {
        _currentIndex++;
        _resetFeedback();
      });
    }
  }

  void _previousPhrase() {
    if (_currentIndex > 0) {
      setState(() {
        _currentIndex--;
        _resetFeedback();
      });
    }
  }

  void _resetFeedback() {
    _evaluationFeedback = "Maghanda at isagawa ang kumpas...";
    _lastConfidence = 0.0;
    _isMatch = false;
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        backgroundColor: Color(0xFF121212),
        body: Center(child: CircularProgressIndicator(color: Colors.amber)),
      );
    }

    if (_manifest == null || _manifest!.phrases.isEmpty) {
      return const Scaffold(
        backgroundColor: Color(0xFF121212),
        body: Center(
          child: Text(
            "Hindi nahanap ang manifest data.",
            style: TextStyle(color: Colors.white70),
          ),
        ),
      );
    }

    final phrase = _manifest!.phrases[_currentIndex];

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E1E1E),
        title: Text(
          "Lupang Hinirang (${phrase.id}/${_manifest!.phrases.length})",
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: () => _showPipelineInfoDialog(context),
          ),
        ],
      ),
      body: Column(
        children: [
          // 1. Camera / Skeleton Viewport Container
          Expanded(
            flex: 5,
            child: Container(
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: _isMatch ? Colors.greenAccent : Colors.white12,
                  width: 2,
                ),
              ),
              child: Stack(
                children: [
                  // Camera Stream Placeholder
                  const Center(
                    child: Icon(
                      Icons.camera_front_outlined,
                      size: 80,
                      color: Colors.white24,
                    ),
                  ),

                  // Framing Guide HUD overlay (Upper body silhouette guide)
                  Positioned(
                    top: 16,
                    left: 16,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.accessibility_new,
                            size: 16,
                            color: Colors.amberAccent[200],
                          ),
                          const SizedBox(width: 6),
                          Text(
                            "Framing: ${phrase.orientation.replaceAll('_', ' ').toUpperCase()}",
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Real-time evaluation pill
                  Positioned(
                    bottom: 16,
                    left: 16,
                    right: 16,
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.85),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _isMatch
                              ? Colors.greenAccent
                              : Colors.white24,
                          width: 1,
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              _evaluationFeedback,
                              style: TextStyle(
                                color: _isMatch
                                    ? Colors.greenAccent
                                    : Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (_lastConfidence > 0)
                            Text(
                              "${(_lastConfidence * 100).toStringAsFixed(1)}%",
                              style: TextStyle(
                                color: _isMatch
                                    ? Colors.greenAccent
                                    : Colors.amberAccent,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // 2. Lyric and Instruction Card
          Expanded(
            flex: 4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              decoration: const BoxDecoration(
                color: Color(0xFF1A1A1A),
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    phrase.label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Tagubilin sa Pagsenyas:",
                    style: TextStyle(
                      color: Colors.amberAccent[200],
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Text(
                        phrase.instruction,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 14,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Navigation Controls
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ElevatedButton.icon(
                        onPressed: _currentIndex > 0 ? _previousPhrase : null,
                        icon: const Icon(Icons.arrow_back_ios, size: 14),
                        label: const Text("Bumalik"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2C2C2C),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                        ),
                      ),
                      ElevatedButton.icon(
                        onPressed: _currentIndex < _manifest!.phrases.length - 1
                            ? _nextPhrase
                            : null,
                        icon: const Icon(Icons.arrow_forward_ios, size: 14),
                        label: const Text("Susunod"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber[700],
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showPipelineInfoDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF222222),
        title: const Text(
          "Arkitektura ng Modelo",
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _dialogDetail("Pipeline", _manifest!.pipeline),
            _dialogDetail("Model File", _manifest!.modelFilename),
            _dialogDetail("Input Tensor", "${_manifest!.inputTensorShape}"),
            _dialogDetail("Required Frames", "${_manifest!.sampleFrames} frames"),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("OK", style: TextStyle(color: Colors.amberAccent)),
          ),
        ],
      ),
    );
  }

  Widget _dialogDetail(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontSize: 12, color: Colors.white70),
          children: [
            TextSpan(
              text: "$label: ",
              style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
            ),
            TextSpan(text: value),
          ],
        ),
      ),
    );
  }
}