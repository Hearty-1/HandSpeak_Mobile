import cv2
import mediapipe as mp
import numpy as np
import onnxruntime as ort
from pathlib import Path
from collections import defaultdict

MODEL_PATH = "mobile_deployment/fsl_lupang_hinirang.onnx"
DATA_DIR = Path("specialists/civic_observances/landmarks_lupang_hinirang")
RAW_DIR = Path("specialists/civic_observances/raw/lupang_hinirang")

session = ort.InferenceSession(MODEL_PATH)
input_name = session.get_inputs()[0].name
CLASSES = sorted([d.name for d in DATA_DIR.iterdir() if d.is_dir()])
CLASS_MAP = {name: idx for idx, name in enumerate(CLASSES)}

mp_holistic = mp.solutions.holistic
FACE_INDICES = [1, 33, 61, 199, 263, 291, 0, 17, 10, 152, 234, 454]
TARGET_FRAMES = 32

def extract_frame_landmarks(results):
    if results.pose_landmarks:
        pose = [[results.pose_landmarks.landmark[i].x,
                 results.pose_landmarks.landmark[i].y,
                 results.pose_landmarks.landmark[i].z] for i in range(11, 25)]
    else:
        pose = [[0.0, 0.0, 0.0]] * 14

    lh = [[lm.x, lm.y, lm.z] for lm in results.left_hand_landmarks.landmark] if results.left_hand_landmarks else [[0.0, 0.0, 0.0]] * 21
    rh = [[lm.x, lm.y, lm.z] for lm in results.right_hand_landmarks.landmark] if results.right_hand_landmarks else [[0.0, 0.0, 0.0]] * 21

    if results.face_landmarks:
        face = [[results.face_landmarks.landmark[i].x,
                 results.face_landmarks.landmark[i].y,
                 results.face_landmarks.landmark[i].z] for i in FACE_INDICES]
    else:
        face = [[0.0, 0.0, 0.0]] * 12

    return np.array(pose + lh + rh + face, dtype=np.float32)

def extract_holistic_features(clip_32_68_3):
    shoulder_dist = np.linalg.norm(clip_32_68_3[:, 0, :] - clip_32_68_3[:, 1, :], axis=-1, keepdims=True) + 1e-6
    center_torso = (clip_32_68_3[:, 0:1, :] + clip_32_68_3[:, 1:2, :]) / 2.0
    norm = (clip_32_68_3 - center_torso) / np.expand_dims(shoulder_dist, axis=-1)

    lh_speeds = np.linalg.norm(np.diff(norm[:, 14:35, :], axis=0), axis=-1)
    rh_speeds = np.linalg.norm(np.diff(norm[:, 35:56, :], axis=0), axis=-1)
    total_energy_lh = float(np.sum(lh_speeds))
    total_energy_rh = float(np.sum(rh_speeds))

    p_start = norm[0:4].mean(axis=0).flatten()
    p_mid = norm[14:18].mean(axis=0).flatten()
    p_end = norm[28:32].mean(axis=0).flatten()
    delta_movement = p_end - p_start

    features = np.concatenate([
        p_start,
        p_mid,
        p_end,
        delta_movement,
        [total_energy_lh, total_energy_rh]
    ])
    return features.astype(np.float32)

def process_clip(video_path, holistic):
    cap = cv2.VideoCapture(str(video_path))
    sequence = []
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = holistic.process(rgb)
        if results.pose_landmarks or results.left_hand_landmarks or results.right_hand_landmarks:
            sequence.append(extract_frame_landmarks(results))
    cap.release()

    if len(sequence) < 10:
        return None

    arr = np.array(sequence, dtype=np.float32)
    indices = np.linspace(0, arr.shape[0] - 1, TARGET_FRAMES).astype(int)
    return arr[indices]

def main():
    folders = sorted([d for d in RAW_DIR.iterdir() if d.is_dir()])
    
    total_clips = 0
    correct_clips = 0
    per_class_results = defaultdict(lambda: {"total": 0, "correct": 0})
    failed_clips = []

    print(f"Beginning batch evaluation across all {len(folders)} classes...\n")

    with mp_holistic.Holistic(
        static_image_mode=False,
        model_complexity=1,
        smooth_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    ) as holistic:
        for folder in folders:
            expected_class = folder.name
            video_files = list(folder.glob("*.mp4")) + list(folder.glob("*.mov")) + list(folder.glob("*.avi"))

            print(f"Testing {expected_class:<35} ({len(video_files)} clips)...", end="", flush=True)
            folder_correct = 0

            for vpath in video_files:
                clip32 = process_clip(vpath, holistic)
                if clip32 is None:
                    continue

                feats = extract_holistic_features(clip32)
                outputs = session.run(None, {input_name: feats.reshape(1, -1)})
                pred_idx = int(outputs[0][0])
                predicted_class = CLASSES[pred_idx]

                total_clips += 1
                per_class_results[expected_class]["total"] += 1

                if predicted_class == expected_class:
                    correct_clips += 1
                    folder_correct += 1
                    per_class_results[expected_class]["correct"] += 1
                else:
                    failed_clips.append((expected_class, vpath.name, predicted_class))

            acc = (folder_correct / len(video_files) * 100) if video_files else 0.0
            print(f" [{folder_correct}/{len(video_files)}] ({acc:.1f}%)")

    overall_acc = (correct_clips / total_clips * 100) if total_clips else 0.0
    print("\n" + "="*60)
    print(f"FINAL BATCH EVALUATION REPORT")
    print("="*60)
    print(f"Total Valid Clips Evaluated : {total_clips}")
    print(f"Correctly Predicted Clips   : {correct_clips}")
    print(f"Overall Accuracy            : {overall_acc:.2f}%\n")

    if failed_clips:
        print("Misclassified Clips Log:")
        for exp, fname, pred in failed_clips:
            print(f" - [{exp}] {fname} -> predicted as [{pred}]")
    else:
        print("All clips were classified correctly!")

if __name__ == "__main__":
    main()
