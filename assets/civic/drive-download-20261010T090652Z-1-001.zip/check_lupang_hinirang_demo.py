import cv2
import mediapipe as mp
import numpy as np
from collections import deque
import onnxruntime as ort
import time
from pathlib import Path

MODEL_PATH = "mobile_deployment/fsl_lupang_hinirang.onnx"
DATA_DIR = Path("specialists/civic_observances/landmarks_lupang_hinirang")

session = ort.InferenceSession(MODEL_PATH)
input_name = session.get_inputs()[0].name

# Kunin ang eksaktong pagkakasunod-sunod ng 22 klase
CLASSES = sorted([d.name for d in DATA_DIR.iterdir() if d.is_dir()])

mp_holistic = mp.solutions.holistic
mp_draw = mp.solutions.drawing_utils

FACE_INDICES = [1, 33, 61, 199, 263, 291, 0, 17, 10, 152, 234, 454]

def extract_frame_landmarks(results):
    if results.pose_landmarks:
        pose = [[results.pose_landmarks.landmark[i].x,
                 results.pose_landmarks.landmark[i].y,
                 results.pose_landmarks.landmark[i].z] for i in range(11, 25)]
    else:
        pose = [[0.0, 0.0, 0.0]] * 14

    lh = [[lm.x, lm.y, lm.z] for lm in results.left_hand_landmarks.landmark] if results.left_hand_landmarks else [[0.0, 0.0, 0.0]] * 21
    rh = [[lm.x, lm.y, lm.z] for lm in results.right_hand_landmarks.landmark] if results.right_hand_landmarks else [[0.0, 0.0, 0.0]] * 21

    if results.face_landmarks:
        face = [[results.face_landmarks.landmark[i].x,
                 results.face_landmarks.landmark[i].y,
                 results.face_landmarks.landmark[i].z] for i in FACE_INDICES]
    else:
        face = [[0.0, 0.0, 0.0]] * 12

    return np.array(pose + lh + rh + face, dtype=np.float32)

def extract_holistic_features(clip_32_68_3):
    shoulder_dist = np.linalg.norm(clip_32_68_3[:, 0, :] - clip_32_68_3[:, 1, :], axis=-1, keepdims=True) + 1e-6
    center_torso = (clip_32_68_3[:, 0:1, :] + clip_32_68_3[:, 1:2, :]) / 2.0
    norm = (clip_32_68_3 - center_torso) / np.expand_dims(shoulder_dist, axis=-1)

    lh_speeds = np.linalg.norm(np.diff(norm[:, 14:35, :], axis=0), axis=-1)
    rh_speeds = np.linalg.norm(np.diff(norm[:, 35:56, :], axis=0), axis=-1)
    total_energy_lh = float(np.sum(lh_speeds))
    total_energy_rh = float(np.sum(rh_speeds))

    p_start = norm[0:4].mean(axis=0).flatten()
    p_mid = norm[14:18].mean(axis=0).flatten()
    p_end = norm[28:32].mean(axis=0).flatten()
    delta_movement = p_end - p_start

    features = np.concatenate([
        p_start,
        p_mid,
        p_end,
        delta_movement,
        [total_energy_lh, total_energy_rh]
    ])
    return features.astype(np.float32), (total_energy_lh + total_energy_rh)

def main():
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    buffer = deque(maxlen=32)

    pred_display = "---"
    conf_display = 0.0
    status_msg = "Pumwesto sa tapat ng camera upang makita ang katawan at mga kamay"
    latch_until = 0.0

    with mp_holistic.Holistic(
        static_image_mode=False,
        model_complexity=1,
        smooth_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    ) as holistic:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            now = time.time()
            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = holistic.process(rgb)

            # I-render ang skeleton visualizer
            if results.pose_landmarks:
                mp_draw.draw_landmarks(frame, results.pose_landmarks, mp_holistic.POSE_CONNECTIONS)
            if results.left_hand_landmarks:
                mp_draw.draw_landmarks(frame, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS)
            if results.right_hand_landmarks:
                mp_draw.draw_landmarks(frame, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS)

            if results.pose_landmarks or results.left_hand_landmarks or results.right_hand_landmarks:
                buffer.append(extract_frame_landmarks(results))

                if now > latch_until and len(buffer) == 32:
                    raw_clip = np.array(buffer, dtype=np.float32)
                    feats, total_energy = extract_holistic_features(raw_clip)

                    if total_energy < 0.25:
                        status_msg = "Masyadong banayad ang kumpas; isagawa nang buo ang sign."
                    else:
                        outputs = session.run(None, {input_name: feats.reshape(1, -1)})
                        pred_idx = int(outputs[0][0])
                        prob_map = outputs[1][0]
                        conf = prob_map.get(pred_idx, 0.0)

                        if conf >= 0.65:
                            pred_display = CLASSES[pred_idx]
                            conf_display = conf * 100.0
                            status_msg = f"Na-detect: {pred_display} ({conf_display:.1f}%)"
                            latch_until = now + 1.6
                            buffer.clear()
                        else:
                            status_msg = f"Hindi tiyak ang kumpas (Confidence: {conf * 100.0:.1f}%)"
            else:
                if now > latch_until:
                    buffer.clear()
                    pred_display = "---"
                    status_msg = "Walang taong nakikita sa camera"

            # UI HUD Overlay
            cv2.rectangle(frame, (15, 15), (700, 115), (20, 20, 20), -1)
            cv2.rectangle(frame, (15, 15), (700, 115), (80, 80, 80), 1)

            cv2.putText(frame, f"Lupang Hinirang Line: {pred_display}", (25, 55),
                        cv2.FONT_HERSHEY_DUPLEX, 0.75, (0, 255, 128), 2)
            cv2.putText(frame, f"Status: {status_msg}", (25, 90),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.48, (220, 220, 220), 1)

            cv2.imshow("FSL Lupang Hinirang Live Evaluator", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
