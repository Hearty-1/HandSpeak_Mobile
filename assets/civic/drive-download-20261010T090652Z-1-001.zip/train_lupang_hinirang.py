import warnings
warnings.filterwarnings("ignore")

import joblib
import numpy as np
from pathlib import Path
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType

DATA_DIR = Path("specialists/civic_observances/landmarks_lupang_hinirang")
MODEL_DIR = Path("specialists/civic_observances/models")
MOBILE_DIR = Path("mobile_deployment")

def extract_holistic_features(clip_32_68_3):
    # clip shape: (32 frames, 68 landmarks, 3 coordinates)
    # Pose: 0-13, Left Hand: 14-34, Right Hand: 35-55, Face: 56-67
    
    # Normalization batay sa distansya ng balikat (Pose 11 at 12 -> indices 0 at 1)
    shoulder_dist = np.linalg.norm(clip_32_68_3[:, 0, :] - clip_32_68_3[:, 1, :], axis=-1, keepdims=True) + 1e-6
    center_torso = (clip_32_68_3[:, 0:1, :] + clip_32_68_3[:, 1:2, :]) / 2.0
    
    norm = (clip_32_68_3 - center_torso) / np.expand_dims(shoulder_dist, axis=-1)

    # 1. Kinetic energy ng magkabilang kamay
    lh_speeds = np.linalg.norm(np.diff(norm[:, 14:35, :], axis=0), axis=-1)
    rh_speeds = np.linalg.norm(np.diff(norm[:, 35:56, :], axis=0), axis=-1)
    
    total_energy_lh = float(np.sum(lh_speeds))
    total_energy_rh = float(np.sum(rh_speeds))

    # 2. Key Phase Geometry (Simula, Gitna, at Katapusan ng kumpas)
    p_start = norm[0:4].mean(axis=0).flatten()
    p_mid = norm[14:18].mean(axis=0).flatten()
    p_end = norm[28:32].mean(axis=0).flatten()

    # 3. Dynamic delta vectors
    delta_movement = p_end - p_start

    features = np.concatenate([
        p_start,
        p_mid,
        p_end,
        delta_movement,
        [total_energy_lh, total_energy_rh]
    ])
    return features.astype(np.float32)

def augment_holistic(coords):
    # Time warp at banayad na spatial noise
    indices = np.sort(np.random.choice(32, 32, replace=True))
    warped = coords[indices]
    noise = np.random.normal(0, 0.003, coords.shape).astype(np.float32)
    return warped + noise

def main():
    X_raw, y_raw = [], []
    classes = sorted([d.name for d in DATA_DIR.iterdir() if d.is_dir()])
    class_map = {name: idx for idx, name in enumerate(classes)}

    for folder_name in classes:
        folder = DATA_DIR / folder_name
        label = class_map[folder_name]
        for npy_file in folder.glob("*.npy"):
            arr = np.load(npy_file)
            X_raw.append(arr)
            y_raw.append(label)

    if not X_raw:
        print("[ERROR] Walang landmark files na natagpuan. Tiyaking tapos na ang extract_lupang_hinirang.py.")
        return

    X, y = [], []
    for data, label in zip(X_raw, y_raw):
        X.append(extract_holistic_features(data))
        y.append(label)
        # Augmentation upang maging matatag ang modelo sa kaunting dataset
        for _ in range(3):
            aug = augment_holistic(data)
            X.append(extract_holistic_features(aug))
            y.append(label)

    X = np.array(X, dtype=np.float32)
    y = np.array(y, dtype=np.int32)

    print(f"Dataset compiled: {X.shape[0]} samples. Feature vector size: {X.shape[1]}")
    print(f"Kabuuang bilang ng mga klase: {len(classes)}")

    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    clf = ExtraTreesClassifier(n_estimators=250, max_depth=18, min_samples_split=2, random_state=42)

    scores = cross_val_score(clf, X, y, cv=skf, scoring="accuracy")
    print(f"\n--- 5-Fold Cross-Validation Accuracy (Lupang Hinirang 22 Lines) ---")
    print(f"Mean Accuracy: {scores.mean() * 100:.2f}% (+/- {scores.std() * 100:.2f}%)")

    clf.fit(X, y)

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    MOBILE_DIR.mkdir(parents=True, exist_ok=True)

    joblib_path = MODEL_DIR / "lupang_hinirang_holistic.joblib"
    joblib.dump(clf, joblib_path)
    print(f"[SAVED] Na-save ang model sa: {joblib_path}")

    # Pag-export sa ONNX
    initial_type = [("float_input", FloatTensorType([None, X.shape[1]]))]
    onnx_model = convert_sklearn(clf, initial_types=initial_type, target_opset=15)

    onnx_path = MOBILE_DIR / "fsl_lupang_hinirang.onnx"
    with open(onnx_path, "wb") as f:
        f.write(onnx_model.SerializeToString())
    print(f"[TAGUMPAY] Na-export ang ONNX sa: {onnx_path}")

if __name__ == "__main__":
    main()
