"""Shared pipeline for the Lupang Hinirang FSL recognizer.

extract_lupang_dataset.py, train_lupang_model.py and live_lupang_engine.py all
import from here, so landmark capture, feature computation, mirroring and the
model are defined exactly once (this is what guarantees live/offline parity).

Coordinate conventions
----------------------
* MediaPipe always runs on the UNFLIPPED camera frame, which is the same
  third-person view as the training videos. The live engine flips only the
  display. Mirror augmentation additionally makes the model flip-invariant.
* MediaPipe x/y are normalised to frame width/height separately; x (and hand
  z, which shares x's scale) are multiplied by the aspect ratio w/h, so
  distances are isotropic on portrait (576x1024) and landscape (1920x1080)
  sources alike.
* Mirroring == negate x, swap left/right (hands, shoulders, elbows, wrists).
  MIRROR_PERM / MIRROR_SIGN do this exactly in feature space; self_test()
  verifies it against mirroring the raw landmarks and recomputing features.

Per-frame vector sizes (see static_features):
  per hand (x2) ........................................ 76
    wrist-relative shape, 20 pts x (x,y) / palm span ... 40
    present flag ....................................... 1
    anchors / shoulder span: wrist-mid_shoulder,
      wrist-nose, wrist-sternum, wrist-ipsi shoulder,
      wrist-contra shoulder, index tip-sternum (x,y) ... 12
    palm span / shoulder span .......................... 1
    finger curl cosines (5 fingers x 3 joints) ......... 15
    finger spread cosines (4 adjacent pairs) ........... 4
    palm normal (unit 3D) .............................. 3
  body: L/R wrist, L/R elbow, nose - mid_shoulder ...... 10
  body present flag .................................... 1
  => static S = 163
  velocity  dx_t = x_t - x_{t-1} of 16 trajectory channels
            + per-hand handshape change speed ......... 18
  => FEATURE_DIM = 181, model input (T=32, 181)

Run `python lupang_common.py` to execute the self-tests.
"""
import re
from pathlib import Path

import numpy as np
from scipy.interpolate import interp1d

try:  # PyTorch is needed for training / the local live engine only. The
    import torch  # Cloud Run inference service runs the ONNX export and ships
    import torch.nn as nn  # without it; everything except the model works then.
except ImportError:
    torch = None
    nn = None

FEATURE_VERSION = "lupang-v4"
T = 32
RAW_DIR = Path("specialists/civic_observances/raw/lupang_hinirang")

CLASS_NAMES = [
    "Bayang magiliw", "Perlas ng Silanganan", "Alab ng puso",
    "Sa dibdib mo'y buhay", "Lupang hinirang", "Duyan ka ng magiting",
    "Sa manlulupig", "Di ka pasisiil", "Sa dagat at bundok",
    "Sa simoy at sa langit", "May dilag ang tula at awit",
    "Sa paglayang minamahal", "Ang kislap ng watawat mo'y",
    "Tagumpay na nagniningning", "Ang bituin at araw niya",
    "Kailan pa ma'y di magdidilim", "Lupa ng araw ng luwalhati't pagsinta",
    "Buhay ay langit sa piling mo", "Aming ligaya",
    "Na pag may mang-aapi", "Ang mamatay", "Nang dahil sa 'yo",
    "INVALID_GESTURE",
]
NUM_CLASSES = len(CLASS_NAMES)
INVALID_IDX = NUM_CLASSES - 1

# Identical MediaPipe settings for offline extraction and live capture.
HOLISTIC_KWARGS = dict(
    static_image_mode=False,
    model_complexity=1,
    smooth_landmarks=True,
    min_detection_confidence=0.35,   # lowered from 0.5: fewer hand drops at ~20 fps / motion blur
    min_tracking_confidence=0.35,
)
MAX_FRAME_SIDE = 960      # frames are downscaled to this before MediaPipe
MAX_GAP_S = 0.5           # pose dropouts (and hand gaps without a pose wrist) bridged up to this
HAND_HOLD_S = 1.0         # a lost hand keeps its last shape, riding on the pose wrist, this long
ONE_HAND_STRONG = 0.60    # one-hand sign: one hand tracked in >= 60 % of active frames ...
ONE_HAND_WEAK = 0.25      # ... and the other in < 25 % -> the other is treated as resting/absent
VIS_MIN = 0.5             # pose points below this MediaPipe visibility are repaired
NOSE_JUMP_S = 0.6         # nose further than this (shoulder spans) from its sequence median
                          # = pulled onto a covering hand -> treated as occluded
NOSE_UP_S = 0.59          # torso fallback: nose sits 0.59 S above mid-shoulder (data median)
TOP_EDGE = 0.05           # a hand whose highest landmark is within 5 % of the top edge ...
EDGE_HOLD_S = 2.0         # ... and is then lost is held this long (it left the frame upward)
MIN_ACTIVE_FRAMES = 8     # after trimming, fewer frames than this -> reject
STERNUM_DROP = 0.5        # sternum = mid-shoulder + 0.5*S along the torso axis

# ---------------------------------------------------------------------------
# Raw per-frame landmark vector (what is captured from MediaPipe)
# ---------------------------------------------------------------------------
# pose (x,y): nose, L/R shoulder, L/R elbow, L/R wrist  (MediaPipe indices)
POSE_IDS = (0, 11, 12, 13, 14, 15, 16)
P_NOSE, P_LSH, P_RSH, P_LEL, P_REL, P_LWR, P_RWR = range(7)
POSE_MIRROR = [P_NOSE, P_RSH, P_LSH, P_REL, P_LEL, P_RWR, P_LWR]

RAW_POSE = slice(0, 14)        # 7 x (x, y)
RAW_LH = slice(14, 77)         # 21 x (x, y, z)
RAW_RH = slice(77, 140)        # 21 x (x, y, z)
RAW_FLAG_POSE, RAW_FLAG_LH, RAW_FLAG_RH = 140, 141, 142
RAW_VIS = slice(143, 150)      # MediaPipe visibility of the 7 pose points
RAW_DIM = 150

# Finger chains (wrist -> MCP -> PIP -> DIP -> TIP) in MediaPipe hand indices.
FINGERS = {
    "thumb": (0, 1, 2, 3, 4),
    "index": (0, 5, 6, 7, 8),
    "middle": (0, 9, 10, 11, 12),
    "ring": (0, 13, 14, 15, 16),
    "pinky": (0, 17, 18, 19, 20),
}
FINGER_ORDER = ("thumb", "index", "middle", "ring", "pinky")


def prepare_frame(frame_bgr):
    """Downscale (aspect preserved) and convert to RGB. Returns (rgb, aspect)."""
    import cv2
    h, w = frame_bgr.shape[:2]
    scale = MAX_FRAME_SIDE / max(h, w)
    if scale < 1.0:
        frame_bgr = cv2.resize(frame_bgr, (int(round(w * scale)), int(round(h * scale))),
                               interpolation=cv2.INTER_AREA)
    rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    rgb.flags.writeable = False
    return rgb, w / float(h)


def raw_from_results(results, aspect):
    """MediaPipe Holistic results -> fixed-layout raw vector (RAW_DIM,)."""
    raw = np.zeros(RAW_DIM, dtype=np.float32)
    if results.pose_landmarks:
        lm = results.pose_landmarks.landmark
        raw[RAW_POSE] = np.array([[lm[i].x * aspect, lm[i].y] for i in POSE_IDS],
                                 dtype=np.float32).ravel()
        raw[RAW_VIS] = np.array([lm[i].visibility for i in POSE_IDS], dtype=np.float32)
        raw[RAW_FLAG_POSE] = 1.0
    for sl, flag, hand in ((RAW_LH, RAW_FLAG_LH, results.left_hand_landmarks),
                           (RAW_RH, RAW_FLAG_RH, results.right_hand_landmarks)):
        if hand:
            raw[sl] = np.array([[p.x * aspect, p.y, p.z * aspect] for p in hand.landmark],
                               dtype=np.float32).ravel()
            raw[flag] = 1.0
    return raw


def raw_from_arrays(pose=None, left_hand=None, right_hand=None, aspect=1.0):
    """Landmark arrays -> fixed-layout raw vector (RAW_DIM,); identical to
    raw_from_results for callers that receive landmarks as numbers (e.g. the
    inference service). pose: (33, >=3) MediaPipe pose landmarks [x, y,
    visibility]; hands: (21, >=3) [x, y, z]. All in MediaPipe normalised image
    coordinates of the UNMIRRORED frame; None = not detected."""
    raw = np.zeros(RAW_DIM, dtype=np.float32)
    if pose is not None:
        pose = np.asarray(pose, dtype=np.float32)
        pts = pose[list(POSE_IDS)]
        raw[RAW_POSE] = np.stack([pts[:, 0] * aspect, pts[:, 1]], axis=1).ravel()
        raw[RAW_VIS] = pts[:, 2]
        raw[RAW_FLAG_POSE] = 1.0
    for sl, flag, hand in ((RAW_LH, RAW_FLAG_LH, left_hand), (RAW_RH, RAW_FLAG_RH, right_hand)):
        if hand is not None:
            h = np.asarray(hand, dtype=np.float32)[:, :3]
            raw[sl] = np.stack([h[:, 0] * aspect, h[:, 1], h[:, 2] * aspect], axis=1).ravel()
            raw[flag] = 1.0
    return raw


def mirror_raw(raw):
    """Horizontal mirror of raw vectors (..., RAW_DIM)."""
    out = raw.copy()
    lead = raw.shape[:-1]
    pose = raw[..., RAW_POSE].reshape(*lead, 7, 2)[..., POSE_MIRROR, :].copy()
    lh = raw[..., RAW_LH].reshape(*lead, 21, 3).copy()
    rh = raw[..., RAW_RH].reshape(*lead, 21, 3).copy()
    for arr in (pose, lh, rh):
        arr[..., 0] *= -1.0
    out[..., RAW_POSE] = pose.reshape(*lead, 14)
    out[..., RAW_LH] = rh.reshape(*lead, 63)
    out[..., RAW_RH] = lh.reshape(*lead, 63)
    out[..., RAW_FLAG_LH] = raw[..., RAW_FLAG_RH]
    out[..., RAW_FLAG_RH] = raw[..., RAW_FLAG_LH]
    out[..., RAW_VIS] = raw[..., RAW_VIS][..., POSE_MIRROR]
    return out


def extract_raw_from_video(path):
    """Run Holistic over a whole video with a fresh tracker.

    Returns (raw (N, RAW_DIM), timestamps (N,) in seconds).
    """
    import cv2
    import mediapipe as mp
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise IOError(f"cannot open video {path}")
    fps = cap.get(cv2.CAP_PROP_FPS)
    if not fps or fps < 1:
        fps = 30.0
    raws, ts = [], []
    try:
        with mp.solutions.holistic.Holistic(**HOLISTIC_KWARGS) as holistic:
            idx = 0
            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                rgb, aspect = prepare_frame(frame)
                raws.append(raw_from_results(holistic.process(rgb), aspect))
                ts.append(idx / fps)
                idx += 1
    finally:
        cap.release()
    return np.array(raws, dtype=np.float32).reshape(-1, RAW_DIM), np.array(ts, dtype=np.float64)


# ---------------------------------------------------------------------------
# Sequence clean-up: trim idle edges, bridge short detection dropouts
# ---------------------------------------------------------------------------
def _fill_block(raw, ts, cols, flag_col):
    """Interpolate a whole block (pose / one hand) over missing frames.
    Returns the number of frames repaired."""
    present = raw[:, flag_col] > 0.5
    idx = np.flatnonzero(present)
    if len(idx) == 0 or len(idx) == len(raw):
        return 0
    filled = 0
    for m in np.flatnonzero(~present):
        k = np.searchsorted(idx, m)
        prev = idx[k - 1] if k > 0 else None
        nxt = idx[k] if k < len(idx) else None
        if prev is not None and nxt is not None:
            if ts[nxt] - ts[prev] > MAX_GAP_S:
                continue
            a = (ts[m] - ts[prev]) / max(ts[nxt] - ts[prev], 1e-9)
            raw[m, cols] = (1 - a) * raw[prev, cols] + a * raw[nxt, cols]
        elif prev is not None and ts[m] - ts[prev] <= MAX_GAP_S / 2:
            raw[m, cols] = raw[prev, cols]
        elif nxt is not None and ts[nxt] - ts[m] <= MAX_GAP_S / 2:
            raw[m, cols] = raw[nxt, cols]
        else:
            continue
        raw[m, flag_col] = 1.0
        filled += 1
    return filled


def _fill_hand(raw, ts, sl, flag_col, pose_wrist):
    """Landmark memory for a hand that MediaPipe lost (blur, occlusion, edge
    of frame). For a missing frame within HAND_HOLD_S of a detection
    (HAND_HOLD_S / 2 on one side only), the hand SHAPE (landmarks relative to
    its own wrist) is interpolated / held from the neighbouring detections,
    and its WRIST is placed at the pose wrist plus the interpolated
    hand-wrist-to-pose-wrist offset, so the hand keeps moving with the arm
    instead of freezing. Without a pose wrist, gaps up to MAX_GAP_S are
    linearly interpolated. Returns the number of frames filled."""
    n = len(raw)
    present = raw[:, flag_col] > 0.5
    idx = np.flatnonzero(present)
    if len(idx) == 0 or len(idx) == n:
        return 0
    h = raw[:, sl].reshape(n, 21, 3).copy()
    pw = raw[:, 2 * pose_wrist:2 * pose_wrist + 2]
    pose_ok = raw[:, RAW_FLAG_POSE] > 0.5
    filled = 0
    at_top = h[:, :, 1].min(axis=1) < TOP_EDGE        # hand touching the top of the frame
    for m in np.flatnonzero(~present):
        k = np.searchsorted(idx, m)
        prev = idx[k - 1] if k > 0 else None
        nxt = idx[k] if k < len(idx) else None
        # A hand that was last seen at the top edge has left the frame upward
        # (e.g. overhead signs): hold it longer instead of dropping it.
        hold = EDGE_HOLD_S if prev is not None and at_top[prev] else HAND_HOLD_S
        if prev is not None and nxt is not None and ts[nxt] - ts[prev] <= 2 * hold \
                and min(ts[m] - ts[prev], ts[nxt] - ts[m]) <= hold:
            a = (ts[m] - ts[prev]) / max(ts[nxt] - ts[prev], 1e-9)
            src = [(prev, 1 - a), (nxt, a)]
        elif prev is not None and ts[m] - ts[prev] <= (hold if at_top[prev] else hold / 2):
            src = [(prev, 1.0)]
        elif nxt is not None and ts[nxt] - ts[m] <= HAND_HOLD_S / 2:
            src = [(nxt, 1.0)]
        else:
            continue
        shape = sum(wt * (h[j] - h[j, 0]) for j, wt in src)
        wrist = sum(wt * h[j, 0] for j, wt in src)
        if pose_ok[m] and all(pose_ok[j] for j, _ in src):
            wrist[:2] = pw[m] + sum(wt * (h[j, 0, :2] - pw[j]) for j, wt in src)
        elif len(src) < 2 or ts[src[1][0]] - ts[src[0][0]] > MAX_GAP_S:
            continue
        h[m] = shape + wrist
        raw[m, flag_col] = 1.0
        filled += 1
    raw[:, sl] = h.reshape(n, 63)
    return filled


def _resting_hand(raw):
    """One-handed signing: returns "left"/"right" for the hand that is barely
    tracked (< ONE_HAND_WEAK) while the other is tracked well
    (>= ONE_HAND_STRONG), else None."""
    lh = float((raw[:, RAW_FLAG_LH] > 0.5).mean())
    rh = float((raw[:, RAW_FLAG_RH] > 0.5).mean())
    if rh >= ONE_HAND_STRONG and lh < ONE_HAND_WEAK:
        return "left"
    if lh >= ONE_HAND_STRONG and rh < ONE_HAND_WEAK:
        return "right"
    return None


def _repair_pose_points(raw, ts):
    """Occlusion memory for individual pose points.

    When the face is covered (nose) or a wrist / elbow leaves the frame,
    MediaPipe Pose keeps returning a low-visibility guess for that point,
    which corrupts every anchor built on it. Each point whose visibility is
    < VIS_MIN is replaced by linear interpolation between the neighbouring
    visible frames, or holds the last / next visible value at the edges.
    Pose anchors move slowly relative to the torso, so no gap-length limit is
    applied. A point never visible in the capture keeps MediaPipe's estimate.
    Returns {point name: frames repaired}.
    """
    names = ("nose", "l_shoulder", "r_shoulder", "l_elbow", "r_elbow", "l_wrist", "r_wrist")
    pose_ok = raw[:, RAW_FLAG_POSE] > 0.5
    vis = raw[:, RAW_VIS]
    repaired = {}
    nose_bad = _nose_jumps(raw, pose_ok)
    for j, name in enumerate(names):
        good = pose_ok & (vis[:, j] >= VIS_MIN)
        if j == P_NOSE:
            good &= ~nose_bad
        bad = np.flatnonzero(pose_ok & ~good)
        if len(bad) == 0 or not good.any():
            continue
        idx = np.flatnonzero(good)
        for col in (2 * j, 2 * j + 1):
            raw[bad, col] = np.interp(ts[bad], ts[idx], raw[idx, col])
        raw[bad, RAW_VIS.start + j] = VIS_MIN
        repaired[name] = int(len(bad))
    # Face covered for the whole capture: no trustworthy nose to interpolate
    # from, so place it on the torso axis above the mid-shoulder point.
    nose_good = pose_ok & (vis[:, P_NOSE] >= VIS_MIN) & ~nose_bad
    if pose_ok.any() and not nose_good.any():
        rows = np.flatnonzero(pose_ok)
        pose = raw[rows, RAW_POSE].reshape(-1, 7, 2)
        sv = pose[:, P_LSH] - pose[:, P_RSH]
        span = np.linalg.norm(sv, axis=1, keepdims=True) + 1e-6
        up = np.stack([sv[:, 1], -sv[:, 0]], axis=1) / span
        mid = (pose[:, P_LSH] + pose[:, P_RSH]) / 2.0
        raw[rows, 0:2] = mid + NOSE_UP_S * span * up
        repaired["nose_torso_fallback"] = int(len(rows))
    return repaired


def _nose_jumps(raw, pose_ok):
    """Frames where the nose is far from where it usually sits relative to the
    shoulders: MediaPipe has snapped it onto a hand covering the face."""
    bad = np.zeros(len(raw), dtype=bool)
    rows = np.flatnonzero(pose_ok)
    if len(rows) < 3:
        return bad
    pose = raw[rows, RAW_POSE].reshape(-1, 7, 2)
    mid = (pose[:, P_LSH] + pose[:, P_RSH]) / 2.0
    span = np.linalg.norm(pose[:, P_LSH] - pose[:, P_RSH], axis=1, keepdims=True) + 1e-6
    rel = (pose[:, P_NOSE] - mid) / span
    dev = np.linalg.norm(rel - np.median(rel, axis=0), axis=1)
    bad[rows] = dev > NOSE_JUMP_S
    return bad


def clean_sequence(raw, ts, stats=None):
    """Trim frames before the first / after the last hand detection, repair
    occluded pose points and interpolate short dropouts.
    Returns (raw, ts) or None if too little signal. If `stats` is a dict it
    receives repair counts for diagnostics."""
    raw = np.asarray(raw, dtype=np.float32).copy()
    ts = np.asarray(ts, dtype=np.float64)
    if len(raw) == 0:
        return None
    any_hand = (raw[:, RAW_FLAG_LH] > 0.5) | (raw[:, RAW_FLAG_RH] > 0.5)
    hit = np.flatnonzero(any_hand)
    if len(hit) == 0:
        return None
    raw, ts = raw[hit[0]:hit[-1] + 1], ts[hit[0]:hit[-1] + 1]
    if len(raw) < MIN_ACTIVE_FRAMES:
        return None
    # One-handed sign: the barely-tracked hand is resting / out of view. It is
    # marked absent for the whole sequence (the same representation the model
    # sees for one-hand training samples) instead of being filled with guesses.
    resting = _resting_hand(raw)
    if resting is not None:
        sl, flag = (RAW_LH, RAW_FLAG_LH) if resting == "left" else (RAW_RH, RAW_FLAG_RH)
        raw[:, sl] = 0.0
        raw[:, flag] = 0.0
    points = _repair_pose_points(raw, ts)
    pose_cols = np.r_[np.r_[RAW_POSE], np.r_[RAW_VIS]]
    n_pose = _fill_block(raw, ts, pose_cols, RAW_FLAG_POSE)
    n_lh = _fill_hand(raw, ts, RAW_LH, RAW_FLAG_LH, P_LWR)
    n_rh = _fill_hand(raw, ts, RAW_RH, RAW_FLAG_RH, P_RWR)
    if stats is not None:
        stats.update(pose_points_repaired=points, pose_frames_filled=n_pose,
                     left_hand_frames_filled=n_lh, right_hand_frames_filled=n_rh,
                     resting_hand=resting)
    return raw, ts


# ---------------------------------------------------------------------------
# Feature definition
# ---------------------------------------------------------------------------
def _xy(name):
    return [name + ".x", name + ".y"]


def _static_names():
    names = []
    for s in ("L", "R"):
        for j in range(1, 21):
            names += _xy(f"{s}.shape.{j:02d}")
        names.append(f"{s}.present")
        for a in ("wrist_mid", "wrist_nose", "wrist_sternum", "wrist_ipsi",
                  "wrist_contra", "index_sternum"):
            names += _xy(f"{s}.{a}")
        names.append(f"{s}.palm_scale")
        for f in FINGER_ORDER:
            names += [f"{s}.curl.{f}.{j}" for j in range(3)]
        names += [f"{s}.spread.{k}" for k in range(4)]
        names += [f"{s}.palm_normal.nx", f"{s}.palm_normal.ny", f"{s}.palm_normal.nz"]
    for part in ("wr", "el"):
        for s in ("L", "R"):
            names += _xy(f"body.{part}.{s}")
    names += _xy("body.nose")
    names.append("body.present")
    return names


STATIC_NAMES = _static_names()
S_DIM = len(STATIC_NAMES)
_SIDX = {n: i for i, n in enumerate(STATIC_NAMES)}

# Trajectory channels whose first-order velocity is appended.
VEL_SOURCES = []
for _s in ("L", "R"):
    VEL_SOURCES += _xy(f"{_s}.wrist_mid") + _xy(f"{_s}.index_sternum")
for _part in ("wr", "el"):
    for _s in ("L", "R"):
        VEL_SOURCES += _xy(f"body.{_part}.{_s}")
VEL_SRC_IDX = np.array([_SIDX[n] for n in VEL_SOURCES])
SHAPE_IDX = {s: np.array([i for i, n in enumerate(STATIC_NAMES) if n.startswith(f"{s}.shape.")])
             for s in ("L", "R")}

FEATURE_NAMES = (STATIC_NAMES + ["vel." + n for n in VEL_SOURCES]
                 + ["vel.L.shape_speed", "vel.R.shape_speed"])
FEATURE_DIM = len(FEATURE_NAMES)


def _mirror_name(name):
    return ".".join({"L": "R", "R": "L"}.get(p, p) for p in name.split("."))


def _mirror_sign(name):
    # x coordinates flip sign. A palm normal n = a x b of mirrored vectors
    # becomes (Ma) x (Mb) = det(M) M (a x b) = (nx, -ny, -nz) for M=diag(-1,1,1).
    # Cosines (curl / spread), flags and scales are reflection invariant.
    if name.endswith(".x") or name.endswith(".ny") or name.endswith(".nz"):
        return -1.0
    return 1.0


def _mirror_tables(names):
    pos = {n: i for i, n in enumerate(names)}
    perm = np.array([pos[_mirror_name(n)] for n in names])
    sign = np.array([_mirror_sign(n) for n in names], dtype=np.float32)
    return perm, sign


MIRROR_PERM, MIRROR_SIGN = _mirror_tables(FEATURE_NAMES)


def mirror_features(x):
    """Mirror full feature sequences (..., FEATURE_DIM)."""
    return x[..., MIRROR_PERM] * MIRROR_SIGN


def static_index(pred):
    """Indices of static channels whose name satisfies pred(name)."""
    return np.array([i for i, n in enumerate(STATIC_NAMES) if pred(n)], dtype=np.int64)


def _unit(v, eps=1e-8):
    return v / (np.linalg.norm(v, axis=-1, keepdims=True) + eps)


def hand_morphology(h3):
    """h3 (N, 21, 3) -> curl (N, 15), spread (N, 4), palm normal (N, 3).

    curl:   cos between consecutive bones of each finger chain
            (wrist->MCP, MCP->PIP, PIP->DIP, DIP->TIP): 1 = straight, <0 = bent.
    spread: cos between the MCP->TIP directions of adjacent fingers.
    normal: unit((h5 - h0) x (h17 - h0)), palm facing direction.
    """
    curls, dirs = [], []
    for f in FINGER_ORDER:
        c = FINGERS[f]
        bones = _unit(np.stack([h3[:, c[i + 1]] - h3[:, c[i]] for i in range(4)], axis=1))
        curls.append(np.sum(bones[:, :-1] * bones[:, 1:], axis=-1))   # (N, 3)
        dirs.append(_unit(h3[:, c[4]] - h3[:, c[1]]))
    curl = np.concatenate(curls, axis=1)
    spread = np.stack([np.sum(dirs[k] * dirs[k + 1], axis=-1) for k in range(4)], axis=1)
    normal = _unit(np.cross(h3[:, 5] - h3[:, 0], h3[:, 17] - h3[:, 0]))
    return curl, spread, normal


def static_features(raw):
    """Per-frame static features: raw (N, RAW_DIM) -> (N, S_DIM=163)."""
    raw = np.asarray(raw, dtype=np.float32)
    n = len(raw)
    pose = raw[:, RAW_POSE].reshape(n, 7, 2)
    shoulder_vec = pose[:, P_LSH] - pose[:, P_RSH]
    span = np.linalg.norm(shoulder_vec, axis=1)                    # S = ||p11 - p12||
    pose_ok = (raw[:, RAW_FLAG_POSE] > 0.5) & (span > 1e-3)
    span = np.where(pose_ok, span, 1.0)[:, None]
    mid = (pose[:, P_LSH] + pose[:, P_RSH]) / 2.0
    # Torso "down" axis = shoulder line rotated 90 deg; sternum sits below mid.
    down = np.stack([-shoulder_vec[:, 1], shoulder_vec[:, 0]], axis=1) / span
    sternum = mid + STERNUM_DROP * span * down

    out = []
    for sl, flag, ipsi, contra in ((RAW_LH, RAW_FLAG_LH, P_LSH, P_RSH),
                                   (RAW_RH, RAW_FLAG_RH, P_RSH, P_LSH)):
        h3 = raw[:, sl].reshape(n, 21, 3)
        h = h3[..., :2]
        wrist = h[:, 0]
        palm = np.linalg.norm(h[:, 9] - wrist, axis=1)             # ||h9 - h0||
        ok = (raw[:, flag] > 0.5) & (palm > 1e-4)
        okc = ok[:, None]
        shape = (h[:, 1:] - wrist[:, None]) / np.where(ok, palm, 1.0)[:, None, None]
        shape = np.where(okc, shape.reshape(n, 40), 0.0)
        anchors = np.concatenate([
            (wrist - mid) / span,
            (wrist - pose[:, P_NOSE]) / span,
            (wrist - sternum) / span,
            (wrist - pose[:, ipsi]) / span,
            (wrist - pose[:, contra]) / span,
            (h[:, 8] - sternum) / span,
            palm[:, None] / span,
        ], axis=1)
        anchors = np.where((ok & pose_ok)[:, None], anchors, 0.0)
        curl, spread, normal = hand_morphology(h3)
        morph = np.where(okc, np.concatenate([curl, spread, normal], axis=1), 0.0)
        out += [shape, okc.astype(np.float32), anchors, morph]

    body = np.concatenate([(pose[:, i] - mid) / span
                           for i in (P_LWR, P_RWR, P_LEL, P_REL, P_NOSE)], axis=1)
    body = np.where(pose_ok[:, None], body, 0.0)
    out += [body, pose_ok[:, None].astype(np.float32)]
    return np.concatenate(out, axis=1).astype(np.float32)


def resample(frames, ts=None, length=T):
    """Linear temporal resampling of (N, C) to (length, C) over normalised time."""
    frames = np.asarray(frames, dtype=np.float32)
    if len(frames) == 1:
        return np.repeat(frames, length, axis=0)
    u = None
    if ts is not None:
        ts = np.asarray(ts, dtype=np.float64)
        if np.all(np.diff(ts) > 0):
            u = (ts - ts[0]) / (ts[-1] - ts[0])
    if u is None:
        u = np.linspace(0.0, 1.0, len(frames))
    return interp1d(u, frames, axis=0, kind="linear")(np.linspace(0.0, 1.0, length)).astype(np.float32)


def _delta(x):
    """Backward difference along time: d_t = x_t - x_{t-1}, d_0 = 0."""
    return np.diff(x, axis=-2, prepend=x[..., :1, :])


def add_velocity(static):
    """(..., T, S_DIM) -> (..., T, FEATURE_DIM): append dx_t of trajectory
    channels and per-hand handshape change speed ||d shape_t||."""
    static = np.asarray(static, dtype=np.float32)
    vel = _delta(static[..., VEL_SRC_IDX])
    speeds = [np.linalg.norm(_delta(static[..., SHAPE_IDX[s]]), axis=-1, keepdims=True)
              for s in ("L", "R")]
    return np.concatenate([static, vel] + speeds, axis=-1).astype(np.float32)


def sequence_static_frames(raw, ts, stats=None):
    """Clean a raw capture and compute per-frame static features.
    Returns (static (N, S_DIM), ts) or None."""
    cleaned = clean_sequence(raw, ts, stats)
    if cleaned is None:
        return None
    raw_c, ts_c = cleaned
    return static_features(raw_c), ts_c


def build_sequence(raw, ts):
    """THE pipeline used for both training data and live inference:
    raw capture (N, 150) -> clean -> static (N, 163) -> resample (32, 163)
    -> + velocity -> (32, 181). Returns None if no usable hand signal."""
    out = sequence_static_frames(raw, ts)
    if out is None:
        return None
    static, ts_c = out
    return add_velocity(resample(static, ts_c))


def source_id(filename):
    """Signer/source video id from a clip filename."""
    stem = Path(filename).stem
    m = re.match(r"^(SRC\d+)_", stem)
    return m.group(1) if m else stem[:11]  # YouTube ids are 11 chars


# ---------------------------------------------------------------------------
# Open-set rejection gate (shared by live engine and validation report)
# ---------------------------------------------------------------------------
# Order of checks in the live engine:
#   1. duration gate      on the RAW active segment, before any resampling
#   2. kinematic gate     on the resampled (32, 181) sequence, before the model
#   3. probability gate   on the classifier output
# Kinematic thresholds marked (calibrated) are recomputed from the training
# phrases by calibrate_kinematics() and stored in the checkpoint; the values
# here are fall-backs only.
GATE_DEFAULTS = dict(
    min_raw_frames=22,      # active frames at >= 30 fps (scaled down on slower cameras)
    min_duration_s=0.75,    # global floor on active (hands-visible) duration
    class_min_duration=None,  # (calibrated) per-phrase floor, checked after classification
    min_energy=1.3,         # (calibrated) primary-wrist path length, shoulder spans
    min_phase_frac=0.03,    # (calibrated) each of 3 phases' share of the motion
    min_tortuosity=1.48,    # (calibrated) path length / start-end distance
    min_conf=0.65,          # top-1 probability
    min_margin=0.20,        # top-1 minus top-2 probability
    min_margin_vs_invalid=0.20,  # ... when top-2 is INVALID_GESTURE (same as min_margin: strict mode)
    solid_energy_factor=1.5,     # "solid motion" = energy >= 1.5 x min_energy
    max_entropy=0.50,       # normalised entropy H(p) / log(C)
)
CLASS_DURATION_FRACTION = 0.75    # fragment gate: >= 75 % of the phrase's median reference duration
# Per-phrase floor overrides in seconds, {class index: floor}. Empty in strict
# mode (the former "Aming ligaya" 0.80 s override let fragments through, and the
# user's own Aming ligaya takes run 2.15-3.0 s, above its 75 % floor).
CLASS_DURATION_OVERRIDES = {}
ENERGY_CALIB_FRACTION = 0.6       # min_energy     = 0.6  x 2nd percentile of real phrases
PHASE_CALIB_FRACTION = 0.7        # min_phase_frac = 0.7  x 2nd percentile
TORTUOSITY_CALIB_FRACTION = 0.85  # min_tortuosity = 0.85 x 2nd percentile

# Phase windows on the 32-frame sequence (inclusive frame ranges).
PHASES = ((0, 10), (11, 21), (22, 31))

REJECT_TEXT = {
    "NO_HANDS": "No hands detected",
    "TOO_SHORT": "Gesture Too Short (Signed only a fragment/word)",
    "FRAGMENT_DURATION": "Fragment: shorter than 75% of this phrase's reference duration",
    "LOW_MOTION": "Insufficient motion (static / no sign)",
    "PHASE_IMBALANCE": "Phase imbalance (started at end-pose / held)",
    "SINGLE_STROKE": "Single stroke, no inflection (one word only)",
    "INVALID_CLASS": "Classified as INVALID_GESTURE",
    "LOW_CONFIDENCE": "Low confidence",
    "SMALL_MARGIN": "Small top-1 / top-2 margin",
    "HIGH_ENTROPY": "Probability too dispersed (high entropy)",
}


class Check(tuple):
    """One gate condition: (code, label, value, threshold, op, passed, text)."""
    __slots__ = ()

    def __new__(cls, code, label, value, thr, op, passed, text=None):
        if text is None:
            text = f"{value:.2f}" + (f" (need {op} {thr:.2f})" if thr is not None else "")
        return super().__new__(cls, (code, label, value, thr, op, bool(passed), text))

    code = property(lambda self: self[0])
    label = property(lambda self: self[1])
    value = property(lambda self: self[2])
    thr = property(lambda self: self[3])
    op = property(lambda self: self[4])
    passed = property(lambda self: self[5])
    text = property(lambda self: self[6])


_FIDX = {n: i for i, n in enumerate(FEATURE_NAMES)}


def build_sequence_with_info(raw, ts):
    """build_sequence plus raw timing of the ACTIVE segment (after idle
    trimming, before resampling). Returns (seq, info) or (None, info)."""
    stats = {}
    out = sequence_static_frames(raw, ts, stats)
    if out is None:
        return None, {"active_frames": 0, "duration_s": 0.0, "fps": 0.0, "repairs": stats}
    static, ts_c = out
    n = len(static)
    dur = float(ts_c[-1] - ts_c[0])
    fps = (n - 1) / dur if dur > 0 else 0.0
    return add_velocity(resample(static, ts_c)), {"active_frames": n, "duration_s": dur,
                                                  "fps": fps, "repairs": stats}


def duration_gate(info, cfg):
    """Pre-resampling check. Resampling to 32 frames would stretch a single
    word over the whole window, so short captures are rejected here.
    The frame requirement is min_raw_frames at >= 30 fps; on a slower camera
    it is scaled to the same duration (ceil(min_duration_s x fps))."""
    n, dur, fps = info["active_frames"], info["duration_s"], info["fps"]
    need = int(cfg["min_raw_frames"])
    if 0 < fps < 30.0:
        need = min(need, int(np.ceil(cfg["min_duration_s"] * fps)))
    min_dur = cfg["min_duration_s"]
    return [
        Check("TOO_SHORT", "Raw frames", n, need, ">=", n >= need,
              f"{n} (need >= {need} @ {fps:.0f} fps)"),
        Check("TOO_SHORT", "Duration", dur, min_dur, ">=", dur >= min_dur,
              f"{dur:.2f}s (need >= {min_dur:.2f}s)"),
    ]


def kinematics(seq):
    """Trajectory statistics of the primary hand on a (T, FEATURE_DIM) sequence.

    w_t: wrist position (shoulder-span units, relative to mid-shoulder) from
         the hand landmarks when tracked, else from the pose wrist.
    energy      E = sum_{t=1}^{T-1} ||w_t - w_{t-1}||_2 (primary = larger-E hand)
    phase_frac  share of the motion inside each window of PHASES (steps that
                bridge two windows are excluded; shares sum to 1)
    tortuosity  E / ||w_{T-1} - w_0||: ~1 for one straight stroke (a single
                word stretched over the window), larger when the trajectory
                turns or returns, as multi-word phrases do.
    """
    best = None
    for s in ("L", "R"):
        hand_w = seq[:, [_FIDX[f"{s}.wrist_mid.x"], _FIDX[f"{s}.wrist_mid.y"]]]
        pose_w = seq[:, [_FIDX[f"body.wr.{s}.x"], _FIDX[f"body.wr.{s}.y"]]]
        hand_ok = seq[:, _FIDX[f"{s}.present"]] > 0.5
        pose_ok = seq[:, _FIDX["body.present"]] > 0.5
        w = np.where(hand_ok[:, None], hand_w, pose_w)
        valid = hand_ok | pose_ok
        step = np.linalg.norm(np.diff(w, axis=0), axis=1) * (valid[1:] & valid[:-1])
        e = float(step.sum())
        if best is None or e > best["energy"]:
            phase = np.array([step[a:b].sum() for a, b in PHASES])
            total = phase.sum()
            frac = phase / total if total > 1e-6 else np.zeros(len(PHASES))
            net = float(np.linalg.norm(w[-1] - w[0]))
            best = {"energy": e, "primary": s, "phase_frac": frac,
                    "tortuosity": e / max(net, 1e-3)}
    return best


def calibrate_kinematics(seqs):
    """Kinematic thresholds from real (positive) training sequences."""
    k = [kinematics(s) for s in seqs]
    energy = np.array([d["energy"] for d in k])
    phase = np.array([d["phase_frac"].min() for d in k])
    tort = np.array([d["tortuosity"] for d in k])
    return {
        "min_energy": float(ENERGY_CALIB_FRACTION * np.percentile(energy, 2)),
        "min_phase_frac": float(PHASE_CALIB_FRACTION * np.percentile(phase, 2)),
        "min_tortuosity": float(TORTUOSITY_CALIB_FRACTION * np.percentile(tort, 2)),
    }


def format_gate(cfg):
    """One-line human-readable gate summary."""
    parts = []
    for k, v in cfg.items():
        if isinstance(v, (bool, str)) or v is None and k != "class_min_duration":
            parts.append(f"{k}={v}")
        elif k == "class_min_duration":
            if v:
                nz = [x for x in v if x > 0]
                parts.append(f"class_min_duration={min(nz):.2f}-{max(nz):.2f}s" if nz else "class_min_duration=off")
            else:
                parts.append("class_min_duration=off")
        else:
            parts.append(f"{k}={v:.3g}")
    return ", ".join(parts)


def calibrate_class_durations(durations, labels, num_classes=NUM_CLASSES):
    """FRAGMENT_DURATION gate thresholds: per phrase, CLASS_DURATION_FRACTION
    (75 %) x the MEDIAN active duration of that phrase's training clips
    (0 = no floor). On the dataset this rejects 97 % of first-half and of
    last-half fragments, at the cost of ~6 % of complete clips signed faster
    than 75 % of the typical speed."""
    out = [0.0] * num_classes
    for c in range(num_classes):
        d = durations[(labels == c) & np.isfinite(durations)]
        if c != INVALID_IDX and len(d):
            out[c] = float(CLASS_DURATION_FRACTION * np.median(d))
    return apply_class_duration_overrides(out)


def apply_class_duration_overrides(floors):
    """Apply CLASS_DURATION_OVERRIDES to a per-phrase floor list."""
    if not floors:
        return floors
    floors = list(floors)
    for c, v in CLASS_DURATION_OVERRIDES.items():
        floors[c] = float(v)
    return floors


def class_duration_check(top_idx, info, cfg):
    """FRAGMENT_DURATION gate, after classification (the floor depends on
    which phrase was recognised): a phrase typically signed in 2.4 s cannot
    have been completed in 1.2 s; that is one word or half the line."""
    floors = cfg.get("class_min_duration")
    if not floors or info is None:
        return []
    need = float(floors[top_idx])
    dur = info["duration_s"]
    return [Check("FRAGMENT_DURATION", "Phrase duration", dur, need, ">=", dur >= need,
                  f"{dur:.2f}s (this phrase needs >= {need:.2f}s = 75% of typical)")]


def normalized_entropy(probs):
    p = np.clip(np.asarray(probs, dtype=np.float64), 1e-12, 1.0)
    return float(-(p * np.log(p)).sum() / np.log(len(p)))


def kinematic_gate(seq, cfg):
    """Pre-classifier trajectory checks. Returns (checks, kinematics dict)."""
    k = kinematics(seq)
    frac = k["phase_frac"]
    pf = cfg["min_phase_frac"]
    phase_text = " / ".join(f"{f * 100:.0f}%" for f in frac) + f" (each >= {pf * 100:.0f}%)"
    return [
        Check("LOW_MOTION", "Motion energy", k["energy"], cfg["min_energy"], ">=",
              k["energy"] >= cfg["min_energy"]),
        Check("PHASE_IMBALANCE", "Phase balance", float(frac.min()), pf, ">=",
              frac.min() >= pf, phase_text),
        Check("SINGLE_STROKE", "Inflection", k["tortuosity"], cfg["min_tortuosity"], ">=",
              k["tortuosity"] >= cfg["min_tortuosity"]),
    ], k


def probability_gate(probs, cfg, kin=None):
    """Post-classifier checks. `kin` (from kinematics()) enables the relaxed
    margin when the runner-up is INVALID_GESTURE: a real phrase with
    p >= min_conf and clearly sign-like motion only has to beat INVALID by
    min_margin_vs_invalid, while phrase-vs-phrase still needs min_margin."""
    order = np.argsort(probs)[::-1]
    p1, p2 = float(probs[order[0]]), float(probs[order[1]])
    h = normalized_entropy(probs)
    need_margin = cfg["min_margin"]
    relaxed = (int(order[1]) == INVALID_IDX and int(order[0]) != INVALID_IDX and p1 >= cfg["min_conf"]
               and kin is not None and kin["energy"] >= cfg["solid_energy_factor"] * cfg["min_energy"])
    if relaxed:
        need_margin = cfg["min_margin_vs_invalid"]
    margin_text = f"{p1 - p2:.2f} (need >= {need_margin:.2f}{' vs INVALID' if relaxed else ''})"
    return [
        Check("INVALID_CLASS", "INVALID prob", float(probs[INVALID_IDX]), None, "",
              int(order[0]) != INVALID_IDX),
        Check("LOW_CONFIDENCE", "Confidence", p1, cfg["min_conf"], ">=", p1 >= cfg["min_conf"]),
        Check("SMALL_MARGIN", "Margin", p1 - p2, need_margin, ">=", p1 - p2 >= need_margin, margin_text),
        Check("HIGH_ENTROPY", "Entropy", h, cfg["max_entropy"], "<=", h <= cfg["max_entropy"]),
    ]


def failed_codes(checks):
    out = []
    for c in checks:
        if not c.passed and c.code not in out:
            out.append(c.code)
    return out


def gate_decision(seq, probs, cfg, info=None):
    """Full multi-condition decision. `info` (from build_sequence_with_info)
    enables the raw duration gate; `probs` may be None if the classifier was
    skipped. Returns (accepted, failed codes, checks)."""
    checks = duration_gate(info, cfg) if info is not None else []
    kin_checks, kin = kinematic_gate(seq, cfg)
    checks += kin_checks
    if probs is not None:
        checks += probability_gate(probs, cfg, kin)
        checks += class_duration_check(int(np.argmax(probs)), info, cfg)
    failed = failed_codes(checks)
    return (probs is not None and not failed), failed, checks


def evaluate_capture(raw, ts, predict_probs, cfg):
    """THE decision used by the live engine and the inference service.

    raw (N, RAW_DIM), ts (N,) seconds; predict_probs(batch (B, T, F)) -> (B, C)
    softmax probabilities. Runs: build sequence -> duration gate -> kinematic
    gate -> classifier (mean of sequence and its mirror) -> probability and
    phrase-duration gates. The classifier is skipped when a pre-check fails.
    Returns dict(accepted, failed codes, checks, probs or None, info, seq)."""
    seq, info = build_sequence_with_info(raw, ts)
    out = {"accepted": False, "failed": [], "checks": [], "probs": None, "info": info, "seq": seq}
    if seq is None:
        out["failed"] = ["NO_HANDS"]
        return out
    pre = duration_gate(info, cfg) + kinematic_gate(seq, cfg)[0]
    out["checks"] = pre
    if not all(c.passed for c in pre):
        out["failed"] = failed_codes(pre)
        return out
    probs = np.asarray(predict_probs(np.stack([seq, mirror_features(seq)]))).mean(axis=0)
    accepted, failed, checks = gate_decision(seq, probs, cfg, info)
    out.update(accepted=accepted, failed=failed, checks=checks, probs=probs)
    return out


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
if nn is not None:
    class FullSequenceConvBiLSTM(nn.Module):
        """(B, 32, 181) -> standardise -> Conv1d x2 (BN, ReLU, Dropout)
        -> 2-layer BiLSTM (B, 32, 2H) -> temporal pooling -> Dense(128) -> Dense(64)
        -> Linear(23).

        pooling="halves" (default): mean over t=1..16 and t=17..32 separately,
        concatenated (B, 4H). The head therefore sees WHEN things happen, so a
        chest hold at the end cannot stand in for the whole phrase the way it can
        under one global average. pooling="mean": single global average (B, 2H).

        Feature mean/std are stored as buffers so the checkpoint is self-contained.
        """

        def __init__(self, in_features=FEATURE_DIM, num_classes=NUM_CLASSES,
                     conv_channels=128, hidden=128, lstm_dropout=0.3, head_dropout=0.4,
                     pooling="halves"):
            super().__init__()
            if pooling not in ("halves", "mean"):
                raise ValueError(f"unknown pooling {pooling!r}")
            self.pooling = pooling
            self.register_buffer("feat_mean", torch.zeros(in_features))
            self.register_buffer("feat_std", torch.ones(in_features))
            self.conv = nn.Sequential(
                nn.Conv1d(in_features, conv_channels, kernel_size=5, padding=2),
                nn.BatchNorm1d(conv_channels),
                nn.ReLU(),
                nn.Dropout(0.2),
                nn.Conv1d(conv_channels, conv_channels, kernel_size=3, padding=1),
                nn.BatchNorm1d(conv_channels),
                nn.ReLU(),
                nn.Dropout(0.2),
            )
            self.lstm = nn.LSTM(conv_channels, hidden, num_layers=2, batch_first=True,
                                bidirectional=True, dropout=lstm_dropout)
            self.head = nn.Sequential(
                nn.Linear(hidden * (4 if pooling == "halves" else 2), 128),
                nn.ReLU(),
                nn.Dropout(head_dropout),
                nn.Linear(128, 64),
                nn.ReLU(),
                nn.Dropout(head_dropout * 0.75),
                nn.Linear(64, num_classes),
            )

        def forward(self, x):
            x = (x - self.feat_mean) / self.feat_std
            x = self.conv(x.transpose(1, 2)).transpose(1, 2)
            out, _ = self.lstm(x)
            if self.pooling == "halves":
                half = out.shape[1] // 2
                feat = torch.cat([out[:, :half].mean(dim=1), out[:, half:].mean(dim=1)], dim=1)
            else:
                feat = out.mean(dim=1)
            return self.head(feat)


def save_checkpoint(path, model, config, metrics=None):
    torch.save({
        "state_dict": model.state_dict(),
        "config": config,
        "class_names": CLASS_NAMES,
        "feature_version": FEATURE_VERSION,
        "feature_names": FEATURE_NAMES,
        "T": T,
        "metrics": metrics or {},
    }, path)


def load_model(path, device="cpu"):
    if torch is None:
        raise ImportError("load_model needs PyTorch; the inference service uses the ONNX export instead")
    ckpt = torch.load(path, map_location=device, weights_only=False)
    if not isinstance(ckpt, dict) or "feature_version" not in ckpt:
        raise ValueError(f"{path} is not a {FEATURE_VERSION} checkpoint "
                         f"(train it with train_lupang_model.py)")
    if ckpt["feature_version"] != FEATURE_VERSION or ckpt["feature_names"] != FEATURE_NAMES:
        raise ValueError(f"{path} uses feature set {ckpt['feature_version']!r}, code is "
                         f"{FEATURE_VERSION!r}; re-run extraction and training.")
    config = dict(ckpt["config"])
    config.setdefault("pooling", "mean")      # checkpoints saved before segment pooling
    model = FullSequenceConvBiLSTM(**config).to(device)
    model.load_state_dict(ckpt["state_dict"])
    model.eval()
    return model, ckpt


# ---------------------------------------------------------------------------
# Self-tests
# ---------------------------------------------------------------------------
def _clear_absent(raw):
    raw[:, RAW_LH][raw[:, RAW_FLAG_LH] < 0.5] = 0.0
    raw[:, RAW_RH][raw[:, RAW_FLAG_RH] < 0.5] = 0.0
    return raw


def _transform_raw(raw, sx=1.0, s=1.0, dx=0.0, dy=0.0):
    """Scale all coords by s (x additionally by sx), translate x/y."""
    out = raw.copy()
    n = len(raw)
    pose = out[:, RAW_POSE].reshape(n, 7, 2)
    pose[..., 0] = pose[..., 0] * s * sx + dx
    pose[..., 1] = pose[..., 1] * s + dy
    out[:, RAW_POSE] = pose.reshape(n, 14)
    for sl in (RAW_LH, RAW_RH):
        h = out[:, sl].reshape(n, 21, 3)
        h[..., 0] = h[..., 0] * s * sx + dx
        h[..., 1] = h[..., 1] * s + dy
        h[..., 2] = h[..., 2] * s * abs(sx)
        out[:, sl] = h.reshape(n, 63)
    return _clear_absent(out)


def _synthetic_raw(rng, n=40):
    raw = np.zeros((n, RAW_DIM), dtype=np.float32)
    t = np.linspace(0, 1, n)[:, None]
    pose = np.array([[0.70, 0.30], [0.85, 0.55], [0.55, 0.55], [0.90, 0.80],
                     [0.50, 0.80], [0.80, 0.70], [0.60, 0.70]], dtype=np.float32)
    raw[:, RAW_POSE] = (pose[None] + 0.01 * rng.standard_normal((n, 7, 2))).reshape(n, 14)
    for sl, c in ((RAW_LH, [0.8, 0.7, 0.0]), (RAW_RH, [0.6, 0.7, 0.0])):
        hand = np.array(c) + 0.05 * rng.standard_normal((21, 3))
        traj = np.concatenate([0.2 * np.sin(3 * t), 0.15 * t, 0.02 * t], axis=1)
        raw[:, sl] = (hand[None] + traj[:, None]).reshape(n, 63)
    raw[:, [RAW_FLAG_POSE, RAW_FLAG_LH, RAW_FLAG_RH]] = 1.0
    raw[:, RAW_VIS] = 1.0
    raw[5:9, RAW_FLAG_LH] = 0.0          # short dropout (should be bridged)
    raw[20:, RAW_FLAG_RH] = 0.0          # long dropout (should stay absent)
    return _clear_absent(raw)


def self_test():
    assert np.array_equal(MIRROR_PERM[MIRROR_PERM], np.arange(FEATURE_DIM)), "mirror not an involution"
    rng = np.random.default_rng(0)
    raw = _synthetic_raw(rng)
    ts = np.arange(len(raw)) / 30.0
    x = build_sequence(raw, ts)
    assert x.shape == (T, FEATURE_DIM) and np.isfinite(x).all()

    # Feature-space mirror == recomputing features on the mirrored scene
    # (mirror about an arbitrary vertical axis).
    x_m = build_sequence(_transform_raw(mirror_raw(raw), dx=1.7), ts)
    err = np.abs(mirror_features(x) - x_m).max()
    assert err < 1e-4, f"mirror mismatch {err}"

    # Translation / uniform scale invariance.
    x_s = build_sequence(_transform_raw(raw, s=1.6, dx=0.3, dy=-0.2), ts)
    assert np.abs(x_s - x).max() < 1e-4, "not scale/translation invariant"

    # Curl of a straight finger is ~1, of a folded finger negative.
    h = np.zeros((1, 21, 3), dtype=np.float32)
    for f in FINGER_ORDER:
        c = FINGERS[f]
        for k, j in enumerate(c[1:], start=1):
            h[0, j] = [0.1 * FINGER_ORDER.index(f), -0.2 * k, 0.0]
    curl, _, normal = hand_morphology(h)
    assert curl[0].reshape(5, 3)[:, 1:].min() > 0.99   # PIP/DIP joints straight
    h[0, 8] = h[0, 6]                     # fold index tip back to PIP
    assert hand_morphology(h)[0][0, 5] < 0

    # Kinematic gate: a frozen hand has ~0 energy, a hold at the end ~0 ratio.
    frozen = np.repeat(x[:1], T, axis=0)
    assert kinematics(frozen)["energy"] < 1e-6
    tail_hold = x.copy()
    tail_hold[PHASES[2][0] - 1:] = x[PHASES[2][0] - 1]
    assert kinematics(tail_hold)["phase_frac"][2] < 1e-6
    straight = np.zeros_like(x)
    straight[:, _FIDX["L.present"]] = straight[:, _FIDX["body.present"]] = 1.0
    straight[:, _FIDX["L.wrist_mid.x"]] = np.linspace(0, 1, T)
    assert abs(kinematics(straight)["tortuosity"] - 1.0) < 1e-3
    _, info = build_sequence_with_info(raw, ts)
    assert info["active_frames"] == len(raw) and abs(info["fps"] - 30.0) < 1e-6
    short = duration_gate({"active_frames": 20, "duration_s": 0.66, "fps": 30.0}, GATE_DEFAULTS)
    assert not any(c.passed for c in short)
    slow_cam = duration_gate({"active_frames": 23, "duration_s": 1.5, "fps": 15.0}, GATE_DEFAULTS)
    assert all(c.passed for c in slow_cam)
    assert kinematics(x)["energy"] > 0.1

    # Occluded nose: low-visibility garbage is replaced by interpolation.
    occ = raw.copy()
    occ[10:15, 0:2] = [5.0, -5.0]
    occ[10:15, RAW_VIS.start] = 0.1
    stats = {}
    fixed, _ = clean_sequence(occ, ts, stats)
    expect = np.array([np.interp(ts[10:15], ts[[9, 15]], raw[[9, 15], c]) for c in (0, 1)]).T
    assert np.abs(fixed[10:15, 0:2] - expect).max() < 1e-5
    assert stats["pose_points_repaired"] == {"nose": 5}
    _, info2 = build_sequence_with_info(raw, ts)
    floors = [0.0] * NUM_CLASSES
    floors[0] = 2.0
    assert not class_duration_check(0, info2, {"class_min_duration": floors})[0].passed

    # Lost hand rides on the pose wrist instead of freezing.
    ride = raw.copy()
    ride[:, 2 * P_LWR:2 * P_LWR + 2] = ride[:, RAW_LH][:, 0:2]     # pose wrist == hand wrist
    ride[12:20, 2 * P_LWR] += 0.3                                   # arm moves while hand is lost
    ride[12:20, RAW_LH] = 0.0
    ride[12:20, RAW_FLAG_LH] = 0.0
    fixed, _ = clean_sequence(ride, ts)
    assert fixed[12:20, RAW_FLAG_LH].min() == 1.0
    assert np.abs(fixed[12:20, RAW_LH.start] - ride[12:20, 2 * P_LWR]).max() < 1e-5
    # One-handed sign: a barely tracked hand is dropped, not filled.
    one = raw.copy()
    one[:, RAW_FLAG_RH] = 0.0
    one[::10, RAW_FLAG_RH] = 1.0                                    # 10 % detections
    stats = {}
    fixed, _ = clean_sequence(one, ts, stats)
    assert stats["resting_hand"] == "right" and fixed[:, RAW_FLAG_RH].max() == 0.0

    # Nose snapped onto a covering hand (visibility still high) is repaired.
    jump = raw.copy()
    jump[10:14, 0:2] += [0.0, 0.5]                                  # ~1.7 S downward
    stats = {}
    fixed, _ = clean_sequence(jump, ts, stats)
    assert np.abs(fixed[10:14, 0:2] - raw[10:14, 0:2]).max() < 0.05
    assert stats["pose_points_repaired"].get("nose") == 4
    # Face covered throughout: nose falls back to the torso axis.
    hidden = raw.copy()
    hidden[:, RAW_VIS.start] = 0.0
    stats = {}
    fixed, _ = clean_sequence(hidden, ts, stats)
    assert stats["pose_points_repaired"]["nose_torso_fallback"] == len(raw)
    assert np.isfinite(fixed[:, 0:2]).all()
    # A hand that leaves through the top edge is held for up to EDGE_HOLD_S.
    top = raw.copy()
    top[20:, RAW_RH] = top[19, RAW_RH]                              # right hand stays visible
    top[20:, RAW_FLAG_RH] = 1.0
    lh = top[:, RAW_LH].reshape(len(top), 21, 3)
    lh[:, :, 1] -= lh[29, :, 1].min() - 0.01                        # frame 29 touches the top
    top[:, RAW_LH] = lh.reshape(len(top), 63)
    top[30:, RAW_FLAG_LH] = 0.0                                     # then lost for 2.0 s
    top[30:, RAW_LH] = 0.0
    ts5 = np.arange(len(top)) / 5.0
    fixed, _ = clean_sequence(top, ts5)
    assert fixed[30:, RAW_FLAG_LH].min() == 1.0
    top_mid = top.copy()                                            # same loss, not at the edge
    top_mid[:, RAW_LH] = raw[:, RAW_LH]
    top_mid[30:, RAW_LH] = 0.0
    fixed, _ = clean_sequence(top_mid, ts5)
    assert fixed[33:, RAW_FLAG_LH].max() == 0.0                     # normal 0.5 s one-sided hold
    assert apply_class_duration_overrides([1.0] * NUM_CLASSES) == [1.0] * NUM_CLASSES   # strict: none

    # raw_from_arrays == raw_from_results for the same landmarks.
    from types import SimpleNamespace as NS
    rng2 = np.random.default_rng(3)
    pose33 = rng2.random((33, 4)).astype(np.float32)
    lh21 = rng2.random((21, 3)).astype(np.float32)
    res = NS(pose_landmarks=NS(landmark=[NS(x=a, y=b, z=c, visibility=v) for a, b, c, v in pose33]),
             left_hand_landmarks=NS(landmark=[NS(x=a, y=b, z=c) for a, b, c in lh21]),
             right_hand_landmarks=None)
    a = raw_from_results(res, 1.25)
    b = raw_from_arrays(pose33[:, [0, 1, 3]], lh21, None, 1.25)
    assert np.allclose(a, b), "raw_from_arrays differs from raw_from_results"

    st, _ = sequence_static_frames(raw, ts)
    assert st[5:9, _SIDX["L.present"]].min() == 1.0
    assert st[-1, _SIDX["R.present"]] == 0.0
    print(f"self-test OK: FEATURE_DIM={FEATURE_DIM} (static {S_DIM} + velocity "
          f"{FEATURE_DIM - S_DIM}), mirror err={err:.2e}")


if __name__ == "__main__":
    self_test()
