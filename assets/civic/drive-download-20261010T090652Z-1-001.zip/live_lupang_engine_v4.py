"""Live Lupang Hinirang FSL recognizer with multi-condition open-set rejection.

    python live_lupang_engine.py [--model palm_lupang_best.pt] [--camera 0]
                                 [--min-raw-frames 30] [--min-duration 1.0]
                                 [--min-phase-frac F] [--min-tortuosity R] [--min-energy E]
                                 [--min-conf 0.65] [--min-margin 0.20] [--max-entropy 0.50]
    python live_lupang_engine.py --video path/to/clip.mp4     # offline check of one clip

Controls: SPACE = start recording / stop and predict, Q or ESC = quit.
--debug prints, per attempt: recording length / fps, left/right hand detection
rates, occlusion repairs, every gate value vs threshold, top-1 / top-2 /
margin / entropy and the first gate that failed.

Decision pipeline after the second SPACE press (all in lupang_common):
  0. No hands in the recording                                  -> REJECTED
  1. Duration gate on the RAW active segment (idle edges trimmed),
     BEFORE resampling, so a single word cannot be time-stretched
     into a "full phrase":
       active frames >= 30 (scaled to 1.2 s worth on cameras < 30 fps)
       active duration >= 1.2 s                                 else TOO SHORT
  2. buffer -> build_sequence -> (32, 181)   (same code as training)
  3. Kinematic gate on the 32-frame sequence, BEFORE the network:
       E = sum_t ||w_t - w_{t-1}||  (primary wrist, shoulder spans)  >= min_energy
       Phase balance: frames 0-10 / 11-21 / 22-31 each carry
         >= min_phase_frac of the motion                        (tail hijack)
       Inflection: E / ||w_31 - w_0|| >= min_tortuosity         (single stroke)
  4. Classifier (probabilities averaged over the sequence and its mirror)
  5. Probability gate: top-1 not INVALID, top-1 >= min_conf,
     top-1 - top-2 >= min_margin, normalised entropy <= max_entropy.
Calibrated thresholds come from the checkpoint; command-line values override.

MediaPipe sees the UNFLIPPED camera frame (same viewpoint as the training
videos); only the display is mirrored.
"""
import argparse
import sys
import time

import cv2
import numpy as np
import torch

import lupang_common as lc

WINDOW = "Lupang Hinirang - FSL Recognition"
GREEN, RED, AMBER, CYAN = (0, 200, 0), (0, 0, 255), (0, 165, 255), (255, 255, 0)
GREY, WHITE, DIM = (190, 190, 190), (255, 255, 255), (120, 120, 120)
FONT = cv2.FONT_HERSHEY_SIMPLEX

# OSD checklist rows, in pipeline order.
CHECK_ROWS = ["Raw frames", "Duration", "Motion energy", "Phase balance", "Inflection",
              "INVALID prob", "Confidence", "Margin", "Entropy", "Phrase duration"]


class Recognizer:
    def __init__(self, model_path, overrides, tta=True):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model, ckpt = lc.load_model(model_path, self.device)
        self.class_names = ckpt["class_names"]
        self.tta = tta
        metrics = ckpt.get("metrics", {})
        stored = metrics.get("gate", {})
        self.gate = dict(lc.GATE_DEFAULTS)
        self.gate.update({k: v for k, v in stored.items() if k in lc.GATE_DEFAULTS})
        self.gate.update({k: v for k, v in overrides.items() if v is not None})
        # Per-phrase duration overrides (lupang_common.CLASS_DURATION_OVERRIDES) apply to any checkpoint.
        self.gate["class_min_duration"] = lc.apply_class_duration_overrides(self.gate["class_min_duration"])
        print(f"Loaded {model_path} (epoch {metrics.get('epoch', '?')}, "
              f"val acc {metrics.get('acc', float('nan')):.3f})")
        missing = [k for k in ("min_energy", "min_phase_frac", "min_tortuosity") if k not in stored]
        if missing:
            print(f"  NOTE: checkpoint lacks calibrated {missing}; using defaults. Run "
                  f"'python train_lupang_model.py --calibrate-only' to calibrate.")
        print("Rejection gate: " + lc.format_gate(self.gate))

    @torch.no_grad()
    def _batch_probs(self, batch):
        """(B, T, F) -> (B, C) softmax. With --no-tta only the unmirrored sequence counts."""
        if not self.tta:
            batch = np.repeat(batch[:1], len(batch), axis=0)
        x = torch.from_numpy(np.ascontiguousarray(batch, dtype=np.float32)).to(self.device)
        return torch.softmax(self.model(x), dim=1).cpu().numpy()

    def evaluate(self, raw, ts):
        """Full decision. Returns a result dict for the UI / console."""
        # Shared decision (identical in the inference service): lupang_common.evaluate_capture.
        out = lc.evaluate_capture(raw, ts, self._batch_probs, self.gate)
        res = {"accepted": out["accepted"], "failed": out["failed"], "checks": out["checks"],
               "top3": [], "info": out["info"], "buffer": buffer_stats(raw, ts), "entropy": None}
        probs = out["probs"]
        if probs is not None:
            order = np.argsort(probs)[::-1][:3]
            res["entropy"] = lc.normalized_entropy(probs)
            res["top3"] = [(self.class_names[i], float(probs[i]), int(i)) for i in order]
        return res


def buffer_stats(raw, ts):
    """Whole-recording statistics (before idle trimming) for diagnostics."""
    raw = np.asarray(raw)
    n = len(raw)
    if n == 0:
        return {"frames": 0, "duration_s": 0.0, "fps": 0.0, "left": 0.0, "right": 0.0, "any": 0.0}
    lh = raw[:, lc.RAW_FLAG_LH] > 0.5
    rh = raw[:, lc.RAW_FLAG_RH] > 0.5
    dur = float(ts[-1] - ts[0]) if n > 1 else 0.0
    return {"frames": n, "duration_s": dur, "fps": (n - 1) / dur if dur > 0 else 0.0,
            "left": float(lh.mean()), "right": float(rh.mean()), "any": float((lh | rh).mean())}


# ---------------------------------------------------------------------------
# Drawing
# ---------------------------------------------------------------------------
def draw_landmarks(frame, results, mp_holistic, drawing, styles):
    if results.pose_landmarks:
        drawing.draw_landmarks(frame, results.pose_landmarks, mp_holistic.POSE_CONNECTIONS,
                               landmark_drawing_spec=styles.get_default_pose_landmarks_style())
    for hand in (results.left_hand_landmarks, results.right_hand_landmarks):
        if hand:
            drawing.draw_landmarks(frame, hand, mp_holistic.HAND_CONNECTIONS,
                                   styles.get_default_hand_landmarks_style(),
                                   styles.get_default_hand_connections_style())


def verdict_text(result):
    if result["accepted"]:
        name, p, _ = result["top3"][0]
        return f"ACCEPTED: {name} ({p:.0%})", GREEN
    codes = result["failed"]
    main = lc.REJECT_TEXT.get(codes[0], codes[0]) if codes else "Rejected"
    extra = f" (+{len(codes) - 1} more)" if len(codes) > 1 else ""
    return f"REJECTED: {main}{extra}", RED


def draw_ui(disp, state):
    h, w = disp.shape[:2]
    cv2.rectangle(disp, (0, 0), (w, 44), (20, 20, 20), -1)
    if state["recording"]:
        cv2.circle(disp, (22, 22), 9, RED, -1)
        elapsed = time.perf_counter() - state["t0"]
        hands = state["hand_frames"] / max(1, state["frames"])
        cv2.putText(disp, f"REC {state['frames']} frames  {elapsed:.1f}s  hands {hands:.0%}  [SPACE] stop",
                    (40, 29), FONT, 0.55, RED, 2)
    else:
        cv2.putText(disp, "IDLE  [SPACE] start recording   [Q] quit", (14, 29), FONT, 0.55, CYAN, 2)

    result = state["result"]
    if result is None:
        return
    row_h = 18
    panel_h = 44 + row_h * len(CHECK_ROWS)
    y0 = h - panel_h
    overlay = disp.copy()
    cv2.rectangle(overlay, (0, y0), (w, h), (15, 15, 15), -1)
    cv2.addWeighted(overlay, 0.82, disp, 0.18, 0, disp)

    text, color = verdict_text(result)
    cv2.putText(disp, text[:72], (12, y0 + 26), FONT, 0.6, color, 2)

    # Left column: top-3 ranked phrases.
    col_w = int(w * 0.42)
    if result["top3"]:
        for r, (name, p, idx) in enumerate(result["top3"]):
            y = y0 + 58 + r * 30
            bar_x0, bar_x1 = 12, col_w - 62
            bar_col = AMBER if idx == lc.INVALID_IDX else (
                GREEN if r == 0 and result["accepted"] else GREY)
            cv2.rectangle(disp, (bar_x0, y + 4),
                          (bar_x0 + max(2, int((bar_x1 - bar_x0) * p)), y + 9), bar_col, -1)
            cv2.putText(disp, f"{r + 1}. {name[:22]}", (bar_x0, y), FONT, 0.45, WHITE, 1)
            cv2.putText(disp, f"{p * 100:5.1f}%", (col_w - 58, y), FONT, 0.45, WHITE, 1)
    else:
        msg = "classifier skipped (failed pre-checks)" if result["checks"] else "no usable sequence"
        cv2.putText(disp, msg, (12, y0 + 58), FONT, 0.45, DIM, 1)
    info = result.get("info")
    if info and info["active_frames"]:
        cv2.putText(disp, f"active {info['active_frames']} frames / {info['duration_s']:.2f}s "
                          f"@ {info['fps']:.0f} fps", (12, h - 10), FONT, 0.4, DIM, 1)

    # Right column: every gate condition, PASS/FAIL, value and threshold.
    checks = {c.label: c for c in result["checks"]}
    x = col_w + 6
    for r, label in enumerate(CHECK_ROWS):
        y = y0 + 48 + r * row_h
        c = checks.get(label)
        if c is None:
            cv2.putText(disp, f"--   {label}: skipped", (x, y), FONT, 0.4, DIM, 1)
            continue
        tag, col = ("OK", GREEN) if c.passed else ("FAIL", RED)
        cv2.putText(disp, tag, (x, y), FONT, 0.4, col, 1)
        cv2.putText(disp, f"{label}: {c.text}", (x + 38, y), FONT, 0.4,
                    WHITE if c.passed else AMBER, 1)
    if state["note"]:
        cv2.putText(disp, state["note"][:80], (12, y0 - 8), FONT, 0.45, AMBER, 1)


def print_debug(attempt, result, gate):
    """Full post-inference breakdown (--debug)."""
    b, info = result["buffer"], result["info"] or {}
    print(f"\n================ Attempt #{attempt} diagnostics ================")
    print(f"Recording    : {b['frames']} frames, {b['duration_s']:.2f} s (camera {b['fps']:.1f} fps)")
    print(f"Hand detect  : left {b['left']:.0%}  right {b['right']:.0%}  either {b['any']:.0%}")
    if info.get("active_frames"):
        print(f"Active part  : {info['active_frames']} frames, {info['duration_s']:.2f} s "
              f"(idle frames without hands trimmed from both ends)")
    rep = info.get("repairs") or {}
    fixes = [f"{k} {v}f" for k, v in (rep.get("pose_points_repaired") or {}).items()]
    for key, label in (("pose_frames_filled", "whole pose"), ("left_hand_frames_filled", "left hand"),
                       ("right_hand_frames_filled", "right hand")):
        if rep.get(key):
            fixes.append(f"{label} {rep[key]}f")
    print(f"Occlusion fix: {', '.join(fixes) if fixes else 'none needed'}")
    print("Gates (in pipeline order):")
    for c in result["checks"]:
        print(f"  [{'OK  ' if c.passed else 'FAIL'}] {c.label:<15} {c.text}")
    if result["top3"]:
        (n1, p1, _), (n2, p2, _) = result["top3"][0], result["top3"][1]
        print(f"Top-1        : {n1}  p={p1:.3f}  (need >= {gate['min_conf']:.2f})")
        print(f"Top-2        : {n2}  p={p2:.3f}  -> margin {p1 - p2:.3f} (need >= {gate['min_margin']:.2f})")
        print(f"Entropy      : {result['entropy']:.3f} (max {gate['max_entropy']:.2f})")
    else:
        print("Classifier   : skipped (failed a pre-check)")
    first = next((c for c in result["checks"] if not c.passed), None)
    if result["accepted"]:
        print(f"Decision     : ACCEPTED -> {result['top3'][0][0]}")
    elif first is not None:
        print(f"Decision     : REJECTED - first failed gate: {first.label} ({first.code}: "
              f"{lc.REJECT_TEXT.get(first.code, '')})")
    else:
        print(f"Decision     : REJECTED - {', '.join(result['failed'])}")


def report_attempt(attempt, n_frames, result, gate, debug):
    if debug:
        print_debug(attempt, result, gate)
    else:
        print_result(attempt, n_frames, result)


def print_result(attempt, n_frames, result):
    print(f"\n--- Attempt #{attempt} ({n_frames} recorded frames) ---")
    for r, (name, p, _) in enumerate(result["top3"]):
        print(f"  Top {r + 1}: {name:<40} {p * 100:6.2f}%")
    for c in result["checks"]:
        print(f"  [{'OK ' if c.passed else 'FAIL'}] {c.label:<14} {c.text}")
    print(f"  => {verdict_text(result)[0]}")


# ---------------------------------------------------------------------------
# Modes
# ---------------------------------------------------------------------------
def run_video(rec, path, debug=False):
    raw, ts = lc.extract_raw_from_video(path)
    report_attempt(1, len(raw), rec.evaluate(raw, ts), rec.gate, debug)
    return 0


def open_camera(index):
    cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)
    if not cap.isOpened():
        cap.release()
        cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        raise SystemExit(f"Cannot open camera {index}")
    return cap


def finish_recording(rec, buffer, stamps, state):
    n = len(buffer)
    if n < 2:
        return {"accepted": False, "failed": ["TOO_SHORT"], "checks": [], "top3": [], "info": None,
                "buffer": buffer_stats(np.zeros((n, lc.RAW_DIM)), np.zeros(n)), "entropy": None}, ""
    result = rec.evaluate(np.stack(buffer), np.array(stamps) - stamps[0])
    hand_rate = state["hand_frames"] / n
    note = state["note"]
    if hand_rate < 0.5:
        note = f"hands visible in only {hand_rate:.0%} of frames - check lighting / framing"
    return result, note


def run_live(rec, args):
    import mediapipe as mp
    mp_holistic = mp.solutions.holistic
    drawing, styles = mp.solutions.drawing_utils, mp.solutions.drawing_styles

    cap = open_camera(args.camera)
    holistic = mp_holistic.Holistic(**lc.HOLISTIC_KWARGS)
    state = {"recording": False, "frames": 0, "hand_frames": 0, "result": None, "note": "", "t0": 0.0}
    buffer, stamps = [], []
    attempt = 1
    print("\n=== LUPANG HINIRANG ENGINE READY ===  SPACE: record/predict   Q: quit\n")
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                print("Camera frame grab failed; exiting.")
                break
            rgb, aspect = lc.prepare_frame(frame)          # unflipped, as in training
            results = holistic.process(rgb)
            auto_stop = False
            if state["recording"]:
                raw = lc.raw_from_results(results, aspect)
                buffer.append(raw)
                stamps.append(time.perf_counter())
                state["frames"] = len(buffer)
                state["hand_frames"] += int(raw[lc.RAW_FLAG_LH] > 0.5 or raw[lc.RAW_FLAG_RH] > 0.5)
                if stamps[-1] - stamps[0] > args.max_seconds:
                    state["note"] = f"auto-stopped after {args.max_seconds:.0f}s"
                    auto_stop = True

            draw_landmarks(frame, results, mp_holistic, drawing, styles)
            disp = cv2.flip(frame, 1)                       # mirror for display only
            draw_ui(disp, state)
            cv2.imshow(WINDOW, disp)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), ord("Q"), 27):
                break
            if cv2.getWindowProperty(WINDOW, cv2.WND_PROP_VISIBLE) < 1:
                break

            if key == ord(" ") and not state["recording"]:
                buffer, stamps = [], []
                state.update(recording=True, frames=0, hand_frames=0, result=None, note="",
                             t0=time.perf_counter())
            elif (key == ord(" ") or auto_stop) and state["recording"]:
                state["recording"] = False
                result, note = finish_recording(rec, buffer, stamps, state)
                state.update(result=result, note=note)
                report_attempt(attempt, len(buffer), result, rec.gate, args.debug)
                attempt += 1
    finally:
        cap.release()
        holistic.close()
        cv2.destroyAllWindows()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    d = lc.GATE_DEFAULTS
    ap.add_argument("--model", default="palm_lupang_best.pt")
    ap.add_argument("--camera", type=int, default=0)
    ap.add_argument("--min-raw-frames", type=int, help=f"default {d['min_raw_frames']}")
    ap.add_argument("--min-duration", type=float, help=f"seconds, default {d['min_duration_s']}")
    ap.add_argument("--min-energy", type=float, help="default: calibrated value in checkpoint")
    ap.add_argument("--min-phase-frac", type=float,
                    help="per-phase motion share, e.g. 0.18; default: calibrated value in checkpoint")
    ap.add_argument("--min-tortuosity", type=float, help="default: calibrated value in checkpoint")
    ap.add_argument("--min-conf", type=float, help=f"default {d['min_conf']}")
    ap.add_argument("--min-margin", type=float, help=f"default {d['min_margin']}")
    ap.add_argument("--max-entropy", type=float, help=f"default {d['max_entropy']}")
    ap.add_argument("--max-seconds", type=float, default=12.0, help="auto-stop long recordings")
    ap.add_argument("--no-tta", action="store_true", help="disable mirror test-time averaging")
    ap.add_argument("--video", help="classify a single video file instead of the webcam")
    ap.add_argument("--debug", action="store_true",
                    help="print a full diagnostic breakdown after every prediction")
    args = ap.parse_args()

    overrides = {"min_raw_frames": args.min_raw_frames, "min_duration_s": args.min_duration,
                 "min_energy": args.min_energy, "min_phase_frac": args.min_phase_frac,
                 "min_tortuosity": args.min_tortuosity, "min_conf": args.min_conf,
                 "min_margin": args.min_margin, "max_entropy": args.max_entropy}
    try:
        rec = Recognizer(args.model, overrides, tta=not args.no_tta)
    except (FileNotFoundError, ValueError) as exc:
        raise SystemExit(f"Cannot load model: {exc}")
    if args.video:
        return run_video(rec, args.video, args.debug)
    run_live(rec, args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
