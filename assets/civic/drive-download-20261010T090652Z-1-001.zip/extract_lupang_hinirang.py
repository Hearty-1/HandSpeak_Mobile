import cv2
import mediapipe as mp
import numpy as np
from pathlib import Path

RAW_DIR = Path("specialists/civic_observances/raw/lupang_hinirang")
OUT_DIR = Path("specialists/civic_observances/landmarks_lupang_hinirang")
TARGET_FRAMES = 32

mp_holistic = mp.solutions.holistic

# 12 Landmark sa Mukha para sa Head Tilt, Tingin, at Hugis ng Bibig
FACE_INDICES = [1, 33, 61, 199, 263, 291, 0, 17, 10, 152, 234, 454]

def extract_frame_landmarks(results):
    # 1. Upper Body Pose (14 points: Shoulders, Elbows, Wrists, Hips mula index 11 hanggang 24)
    if results.pose_landmarks:
        pose = [[results.pose_landmarks.landmark[i].x,
                 results.pose_landmarks.landmark[i].y,
                 results.pose_landmarks.landmark[i].z] for i in range(11, 25)]
    else:
        pose = [[0.0, 0.0, 0.0]] * 14

    # 2. Kaliwang Kamay (21 points)
    if results.left_hand_landmarks:
        lh = [[lm.x, lm.y, lm.z] for lm in results.left_hand_landmarks.landmark]
    else:
        lh = [[0.0, 0.0, 0.0]] * 21

    # 3. Kanang Kamay (21 points)
    if results.right_hand_landmarks:
        rh = [[lm.x, lm.y, lm.z] for lm in results.right_hand_landmarks.landmark]
    else:
        rh = [[0.0, 0.0, 0.0]] * 21

    # 4. Facial Keypoints (12 points)
    if results.face_landmarks:
        face = [[results.face_landmarks.landmark[i].x,
                 results.face_landmarks.landmark[i].y,
                 results.face_landmarks.landmark[i].z] for i in FACE_INDICES]
    else:
        face = [[0.0, 0.0, 0.0]] * 12

    # Kabuuan: 14 + 21 + 21 + 12 = 68 keypoints (204 values bawat frame)
    return np.array(pose + lh + rh + face, dtype=np.float32)

def process_clip(video_path, holistic):
    cap = cv2.VideoCapture(str(video_path))
    sequence = []

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = holistic.process(rgb)

        if results.pose_landmarks or results.right_hand_landmarks or results.left_hand_landmarks:
            sequence.append(extract_frame_landmarks(results))

    cap.release()

    if len(sequence) < 8:
        return None

    # I-resample ang video patungo sa eksaktong 32 frames para sa temporal consistency
    arr = np.array(sequence, dtype=np.float32)
    indices = np.linspace(0, arr.shape[0] - 1, TARGET_FRAMES).astype(int)
    return arr[indices]

def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    folders = sorted([d for d in RAW_DIR.iterdir() if d.is_dir()])

    if not folders:
        print(f"[ERROR] Walang nahanap na folder sa {RAW_DIR}.")
        return

    print(f"Natagpuan ang {len(folders)} mga folder ng parirala. Sinasimulan ang MediaPipe Holistic Extraction...")

    with mp_holistic.Holistic(
        static_image_mode=False,
        model_complexity=1,
        smooth_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    ) as holistic:
        for folder in folders:
            dest_folder = OUT_DIR / folder.name
            dest_folder.mkdir(parents=True, exist_ok=True)

            video_files = list(folder.glob("*.mp4")) + list(folder.glob("*.mov")) + list(folder.glob("*.avi"))
            count = 0
            for idx, vpath in enumerate(video_files):
                data32 = process_clip(vpath, holistic)
                if data32 is not None:
                    np.save(dest_folder / f"sample_{idx:03d}.npy", data32)
                    count += 1
            print(f"[TAPOS] {folder.name}: matagumpay na na-extract ang {count}/{len(video_files)} video clips.")

if __name__ == "__main__":
    main()
